# AgentiQ — Agentic RAG Support System with Guardrails, Evaluation & Observability

An **AI-native, full-stack** customer-support assistant that combines:

- 🧠 **Multi-agent orchestration** with LangGraph (router → retriever → generator → validator)
- 📚 **RAG pipeline** with ChromaDB vector store + LangChain
- 🛠️ **Tool calling** (knowledge-base search, order lookup, human escalation)
- 🛡️ **Guardrails** — PII redaction, prompt-injection detection, output moderation
- 📊 **RAGAS-style evaluation** — faithfulness, answer relevance, context precision
- 📈 **Observability** — structured logging, cost & latency tracking, request tracing
- 🔄 **Fallback strategies** — model fallback, cached responses, graceful degradation
- ⚡ **FastAPI** REST backend + **Streamlit** UI
- 🐳 **Docker** + GitHub Actions **CI/CD**

Built to map 1:1 against the Cognizant Ace — Full Stack AI Engineer role.

---

## Architecture

```
                  ┌─────────────┐
   User ───────►  │  Streamlit  │
                  │     UI      │
                  └──────┬──────┘
                         │  HTTPS / JSON
                         ▼
                  ┌─────────────┐
                  │   FastAPI   │
                  │   Gateway   │
                  └──────┬──────┘
                         │
              ┌──────────┴──────────┐
              ▼                     ▼
      ┌──────────────┐      ┌──────────────┐
      │  Guardrails  │      │ Observability│
      │ (in / out)   │      │ (logs/cost)  │
      └──────┬───────┘      └──────────────┘
             │
             ▼
      ┌──────────────────────────────────────┐
      │       LangGraph Agent Workflow       │
      │                                      │
      │  Router ─► Retriever ─► Generator    │
      │     │           │            │       │
      │     ▼           ▼            ▼       │
      │  Tools     ChromaDB     Validator    │
      │                              │       │
      │                              ▼       │
      │                         Fallback?    │
      └──────────────────────────────────────┘
```

See `docs/ARCHITECTURE.md` for full detail and `docs/PROJECT_EXPLANATION.docx` for the per-component rationale and JD mapping.

---

## Quick start

```bash
# 1. Clone & install
git clone https://github.com/<you>/agentiq.git
cd agentiq
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2. Configure
cp .env.example .env
# Open .env and set GOOGLE_API_KEY (or OPENAI_API_KEY)

# 3. Ingest the sample knowledge base
python -m app.rag.ingest --source data/sample_kb/

# 4. Run the API
uvicorn app.main:app --reload --port 8000

# 5. Run the UI (in a second terminal)
streamlit run ui/streamlit_app.py

# 6. (Optional) Run the evaluation harness
python -m app.evaluation.harness
```

Open <http://localhost:8501> for the UI and <http://localhost:8000/docs> for the OpenAPI spec.

---

## Docker

```bash
docker compose up --build
```

---

## Tests

```bash
pytest -v
```

---

## Project structure

```
agentiq/
├── app/
│   ├── main.py              # FastAPI gateway
│   ├── config.py            # Pydantic settings
│   ├── schemas.py           # Structured I/O models
│   ├── agents/              # LangGraph workflow + tools
│   ├── rag/                 # Ingestion, retrieval, embeddings
│   ├── guardrails/          # PII, injection, moderation
│   ├── evaluation/          # RAGAS-style metrics + harness
│   ├── observability/       # Logging, cost/latency, tracing
│   └── fallback/            # Degradation strategies
├── ui/streamlit_app.py
├── tests/
├── data/sample_kb/
├── docs/
├── Dockerfile
├── docker-compose.yml
└── .github/workflows/ci.yml
```

---

## License

MIT
