# AgentiQ — Architecture

## High-level request flow

```
1. UI (Streamlit) ── HTTP POST /chat ──► FastAPI gateway
2. FastAPI:
     a. new_trace_id() + bind to log context
     b. injection guardrail   (detect)
     c. PII guardrail         (redact)
     d. cache lookup          (fast path)
3. LangGraph agent workflow:
     router ─┬─► retriever ─► generator ─► validator ─► [fallback?]
             ├─► tool
             ├─► smalltalk
             └─► escalate
4. FastAPI:
     a. output moderation guardrail
     b. budget accounting
     c. cache population (if confident answer)
     d. return ChatResponse
```

## Layered design

| Layer | Responsibility | Files |
|------|---------------|-------|
| **Gateway** | HTTP, request validation, orchestration | `app/main.py` |
| **Guardrails** | Input/output safety | `app/guardrails/` |
| **Agents** | LangGraph workflow + nodes + tools | `app/agents/` |
| **RAG** | Ingestion, embeddings, retrieval | `app/rag/` |
| **Evaluation** | RAGAS-style metrics + harness | `app/evaluation/` |
| **Observability** | Logs, cost, latency, tracing | `app/observability/` |
| **Fallback** | Degradation, retries, cached responses | `app/fallback/` |
| **Schemas** | Pydantic models — the contract layer | `app/schemas.py` |
| **Config** | Settings via pydantic-settings | `app/config.py` |

## Why LangGraph (vs a plain LangChain chain)?

A linear chain works fine for a single-shot question. The moment you need:
- Conditional routing ("if smalltalk, skip retrieval entirely").
- Loops ("if the answer fails validation, retry with stricter prompt").
- Multi-step tool use.

…you have re-invented a state machine. LangGraph is that state machine,
already debugged.

## Why structured Pydantic outputs everywhere?

LLMs hallucinate format almost as often as facts. Forcing every response
through a Pydantic schema:
- Guarantees the downstream code can rely on field types.
- Lets the validator node compare `cited_doc_ids` against retrieved IDs.
- Makes the API contract Swagger-auto-documented.

## Observability story

Three signals, all routed through `structlog`:
1. **Logs**  — JSON, with `trace_id` bound per request.
2. **Cost** — every LLM call estimates tokens, computes USD, increments
   the daily budget counter.
3. **Latency** — measured per request and per node.

This is enough to build a Grafana dashboard or pipe into Cloud Logging
without changing any application code.

## Fallback strategy

```
primary model (Gemini 1.5 Flash)
    │
    │ ── on 5xx / timeout (with exponential backoff) ──►
    ▼
fallback model (Gemini 1.5 Flash 8B — cheaper)
    │
    │ ── on second failure ──►
    ▼
canned response (cache or default text)
    │
    │ ── if confidence still low ──►
    ▼
escalate to human (creates ticket)
```

## Scaling notes

| Bottleneck | Mitigation |
|---|---|
| ChromaDB single-node | Migrate to Pinecone / pgvector for multi-replica. |
| LLM rate limits | Per-tenant budget + queue with priority. |
| Cold start | Warm pool of FastAPI workers behind a load balancer. |
| Embedding latency | Batch ingestion; move embeddings to GPU node. |

## Security checklist

- [x] PII redacted before logging.
- [x] PII redacted before LLM call.
- [x] Prompt injection detected.
- [x] Output moderation.
- [x] Non-root user inside Docker.
- [x] Settings loaded from env (never in git).
- [ ] mTLS between UI and API (deployment-time).
- [ ] IAM roles for cloud secrets (deployment-time).
