import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'core/config/app_config.dart';
import 'core/services/auth_service.dart';
import 'core/services/local_cache.dart';
import 'core/theme/app_theme.dart';
import 'features/auth/login_screen.dart';
import 'features/home/shell_screen.dart';
import 'features/onboarding/onboarding_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Required by just_audio_background for media notifications + lock screen.
  // Must run before runApp.
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.pulse.music.channel.audio',
    androidNotificationChannelName: 'Pulse Music',
    androidNotificationOngoing: true,
    androidStopForegroundOnPause: true,
  );

  // Init Supabase only if configured — app should still run for demos.
  if (AppConfig.supabaseConfigured) {
    await Supabase.initialize(
      url: AppConfig.supabaseUrl,
      anonKey: AppConfig.supabaseAnonKey,
    );
  }

  final seenOnboarding = await LocalCache.instance.hasSeenOnboarding();

  runApp(ProviderScope(
    child: PulseApp(seenOnboarding: seenOnboarding),
  ));
}

class PulseApp extends StatelessWidget {
  const PulseApp({super.key, required this.seenOnboarding});

  final bool seenOnboarding;

  @override
  Widget build(BuildContext context) {
    Widget home;
    if (!seenOnboarding) {
      home = const OnboardingScreen();
    } else if (AppConfig.supabaseConfigured && AuthService.instance.isSignedIn) {
      home = const ShellScreen();
    } else {
      home = const LoginScreen();
    }

    return MaterialApp(
      title: 'Pulse Music',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      home: home,
    );
  }
}
