import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';
import '../models/track.dart';
import 'local_cache.dart';

/// Manages favorites, playlists, and recently-played.
///
/// Strategy: local cache is always the read source (instant, offline-safe).
/// Writes go to local cache immediately, then sync to Supabase if configured.
/// This means the app remains fully usable when:
///   - Supabase is not configured at all
///   - The user is signed out
///   - Supabase free tier is paused
///   - The device is offline
class LibraryService {
  LibraryService._();
  static final LibraryService instance = LibraryService._();

  final _cache = LocalCache.instance;

  SupabaseClient? get _client {
    if (!AppConfig.supabaseConfigured) return null;
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return null;
    return Supabase.instance.client;
  }

  String? get _userId => _client?.auth.currentUser?.id;

  // ============== Favorites ==============

  Future<List<Track>> loadFavorites() async {
    // Try remote first if signed in, fall back to cache.
    final c = _client;
    if (c != null) {
      try {
        final rows = await c
            .from('favorites')
            .select()
            .eq('user_id', _userId!)
            .order('created_at', ascending: false);
        final tracks = (rows as List)
            .whereType<Map<String, dynamic>>()
            .map(_trackFromFavoriteRow)
            .toList();
        await _cache.saveFavorites(tracks);
        return tracks;
      } catch (_) {
        // Remote failed — fall through to cache.
      }
    }
    return _cache.loadFavorites();
  }

  Future<void> addFavorite(Track t) async {
    final current = await _cache.loadFavorites();
    if (!current.any((e) => e.id == t.id)) {
      current.insert(0, t);
      await _cache.saveFavorites(current);
    }
    final c = _client;
    if (c != null) {
      try {
        await c.from('favorites').upsert({
          'user_id': _userId,
          'track_id': t.id,
          'track_title': t.title,
          'track_artist': t.artist,
          'track_image': t.imageUrl,
          'track_audio': t.audioUrl,
          'track_duration': t.durationSeconds,
        });
      } catch (_) {
        // Cached locally already; will resync next load.
      }
    }
  }

  Future<void> removeFavorite(String trackId) async {
    final current = await _cache.loadFavorites();
    current.removeWhere((e) => e.id == trackId);
    await _cache.saveFavorites(current);
    final c = _client;
    if (c != null) {
      try {
        await c
            .from('favorites')
            .delete()
            .eq('user_id', _userId!)
            .eq('track_id', trackId);
      } catch (_) {}
    }
  }

  // ============== Recently played ==============

  Future<List<Track>> loadRecentlyPlayed() => _cache.loadRecentlyPlayed();

  Future<void> logPlay(Track t) async {
    final current = await _cache.loadRecentlyPlayed();
    current.removeWhere((e) => e.id == t.id);
    current.insert(0, t);
    // Keep last 50.
    if (current.length > 50) current.removeRange(50, current.length);
    await _cache.saveRecentlyPlayed(current);

    final c = _client;
    if (c != null) {
      try {
        await c.from('recently_played').insert({
          'user_id': _userId,
          'track_id': t.id,
        });
      } catch (_) {}
    }
  }

  // ============== Playlists ==============

  /// Returns a map of playlistId -> [name, tracks].
  /// We store playlist metadata locally in a separate prefs key by encoding
  /// "name" as the first synthetic track with id "__meta__".
  Future<List<PlaylistData>> loadPlaylists() async {
    final c = _client;
    if (c != null) {
      try {
        final playlists = await c
            .from('playlists')
            .select('id, name')
            .eq('user_id', _userId!)
            .order('created_at', ascending: false);
        final result = <PlaylistData>[];
        for (final row in (playlists as List)) {
          final m = row as Map<String, dynamic>;
          final id = m['id']?.toString() ?? '';
          final name = m['name'] as String? ?? 'Untitled';
          final tracksRows = await c
              .from('playlist_tracks')
              .select()
              .eq('playlist_id', id)
              .order('position');
          final tracks = (tracksRows as List)
              .whereType<Map<String, dynamic>>()
              .map(_trackFromPlaylistRow)
              .toList();
          result.add(PlaylistData(id: id, name: name, tracks: tracks));
        }
        // Mirror to cache.
        final cached = {for (final p in result) p.id: _withMeta(p)};
        await _cache.savePlaylists(cached);
        return result;
      } catch (_) {
        // Fall through.
      }
    }
    final cached = await _cache.loadPlaylists();
    return cached.entries.map((e) {
      final tracks = e.value.where((t) => t.id != '__meta__').toList();
      final meta =
          e.value.firstWhere((t) => t.id == '__meta__', orElse: () => _emptyMeta());
      return PlaylistData(id: e.key, name: meta.title, tracks: tracks);
    }).toList();
  }

  Future<String> createPlaylist(String name) async {
    final c = _client;
    String id;
    if (c != null) {
      try {
        final row = await c
            .from('playlists')
            .insert({'user_id': _userId, 'name': name})
            .select('id')
            .single();
        id = row['id'].toString();
      } catch (_) {
        id = 'local_${DateTime.now().millisecondsSinceEpoch}';
      }
    } else {
      id = 'local_${DateTime.now().millisecondsSinceEpoch}';
    }
    final all = await _cache.loadPlaylists();
    all[id] = [
      Track(
        id: '__meta__',
        title: name,
        artist: '',
        audioUrl: '',
        imageUrl: '',
        durationSeconds: 0,
      ),
    ];
    await _cache.savePlaylists(all);
    return id;
  }

  Future<void> renamePlaylist(String id, String name) async {
    final all = await _cache.loadPlaylists();
    final list = all[id] ?? [];
    final tracksOnly = list.where((t) => t.id != '__meta__').toList();
    all[id] = [
      Track(
          id: '__meta__',
          title: name,
          artist: '',
          audioUrl: '',
          imageUrl: '',
          durationSeconds: 0),
      ...tracksOnly,
    ];
    await _cache.savePlaylists(all);
    final c = _client;
    if (c != null) {
      try {
        await c.from('playlists').update({'name': name}).eq('id', id);
      } catch (_) {}
    }
  }

  Future<void> deletePlaylist(String id) async {
    final all = await _cache.loadPlaylists();
    all.remove(id);
    await _cache.savePlaylists(all);
    final c = _client;
    if (c != null) {
      try {
        await c.from('playlists').delete().eq('id', id);
      } catch (_) {}
    }
  }

  Future<void> addTrackToPlaylist(String playlistId, Track t) async {
    final all = await _cache.loadPlaylists();
    final list = all[playlistId] ?? [];
    if (!list.any((e) => e.id == t.id)) {
      list.add(t);
      all[playlistId] = list;
      await _cache.savePlaylists(all);
    }
    final c = _client;
    if (c != null) {
      try {
        await c.from('playlist_tracks').upsert({
          'playlist_id': playlistId,
          'track_id': t.id,
          'position': list.length,
          'track_title': t.title,
          'track_artist': t.artist,
          'track_image': t.imageUrl,
          'track_audio': t.audioUrl,
          'track_duration': t.durationSeconds,
        });
      } catch (_) {}
    }
  }

  Future<void> removeTrackFromPlaylist(String playlistId, String trackId) async {
    final all = await _cache.loadPlaylists();
    final list = all[playlistId] ?? [];
    list.removeWhere((e) => e.id == trackId);
    all[playlistId] = list;
    await _cache.savePlaylists(all);
    final c = _client;
    if (c != null) {
      try {
        await c
            .from('playlist_tracks')
            .delete()
            .eq('playlist_id', playlistId)
            .eq('track_id', trackId);
      } catch (_) {}
    }
  }

  // ============== Mapping helpers ==============

  Track _trackFromFavoriteRow(Map<String, dynamic> r) => Track(
        id: r['track_id']?.toString() ?? '',
        title: r['track_title'] as String? ?? '',
        artist: r['track_artist'] as String? ?? '',
        imageUrl: r['track_image'] as String? ?? '',
        audioUrl: r['track_audio'] as String? ?? '',
        durationSeconds: (r['track_duration'] as num?)?.toInt() ?? 0,
      );

  Track _trackFromPlaylistRow(Map<String, dynamic> r) => Track(
        id: r['track_id']?.toString() ?? '',
        title: r['track_title'] as String? ?? '',
        artist: r['track_artist'] as String? ?? '',
        imageUrl: r['track_image'] as String? ?? '',
        audioUrl: r['track_audio'] as String? ?? '',
        durationSeconds: (r['track_duration'] as num?)?.toInt() ?? 0,
      );

  List<Track> _withMeta(PlaylistData p) => [
        Track(
          id: '__meta__',
          title: p.name,
          artist: '',
          audioUrl: '',
          imageUrl: '',
          durationSeconds: 0,
        ),
        ...p.tracks,
      ];

  Track _emptyMeta() => const Track(
        id: '__meta__',
        title: 'Untitled',
        artist: '',
        audioUrl: '',
        imageUrl: '',
        durationSeconds: 0,
      );
}

class PlaylistData {
  const PlaylistData({
    required this.id,
    required this.name,
    required this.tracks,
  });
  final String id;
  final String name;
  final List<Track> tracks;
}
