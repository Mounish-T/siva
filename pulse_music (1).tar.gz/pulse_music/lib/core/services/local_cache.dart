import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/track.dart';

/// Persistent local cache. Used as both the source of truth when Supabase
/// isn't configured AND as an offline-resilient cache when it is.
class LocalCache {
  LocalCache._();
  static final LocalCache instance = LocalCache._();

  static const _kFavorites = 'pulse.favorites.v1';
  static const _kRecentlyPlayed = 'pulse.recently_played.v1';
  static const _kPlaylists = 'pulse.playlists.v1';
  static const _kSeenOnboarding = 'pulse.onboarding.v1';

  SharedPreferences? _prefs;
  Future<SharedPreferences> _p() async =>
      _prefs ??= await SharedPreferences.getInstance();

  // ---------- Favorites ----------
  Future<List<Track>> loadFavorites() async {
    final raw = (await _p()).getString(_kFavorites);
    return _decodeTrackList(raw);
  }

  Future<void> saveFavorites(List<Track> tracks) async {
    await (await _p()).setString(_kFavorites, _encodeTrackList(tracks));
  }

  // ---------- Recently played ----------
  Future<List<Track>> loadRecentlyPlayed() async {
    final raw = (await _p()).getString(_kRecentlyPlayed);
    return _decodeTrackList(raw);
  }

  Future<void> saveRecentlyPlayed(List<Track> tracks) async {
    await (await _p()).setString(_kRecentlyPlayed, _encodeTrackList(tracks));
  }

  // ---------- Playlists (offline copy) ----------
  Future<Map<String, List<Track>>> loadPlaylists() async {
    final raw = (await _p()).getString(_kPlaylists);
    if (raw == null || raw.isEmpty) return {};
    try {
      final json = jsonDecode(raw) as Map<String, dynamic>;
      return json.map(
        (k, v) => MapEntry(k, _decodeTrackList(jsonEncode(v))),
      );
    } catch (_) {
      return {};
    }
  }

  Future<void> savePlaylists(Map<String, List<Track>> playlists) async {
    final encoded = playlists.map(
      (k, v) => MapEntry(k, v.map(_trackToJson).toList()),
    );
    await (await _p()).setString(_kPlaylists, jsonEncode(encoded));
  }

  // ---------- Onboarding ----------
  Future<bool> hasSeenOnboarding() async =>
      (await _p()).getBool(_kSeenOnboarding) ?? false;

  Future<void> markOnboardingSeen() async {
    await (await _p()).setBool(_kSeenOnboarding, true);
  }

  // ---------- Helpers ----------
  String _encodeTrackList(List<Track> tracks) {
    return jsonEncode(tracks.map(_trackToJson).toList());
  }

  List<Track> _decodeTrackList(String? raw) {
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List;
      return list
          .whereType<Map<String, dynamic>>()
          .map(_trackFromJson)
          .toList();
    } catch (_) {
      return [];
    }
  }

  Map<String, dynamic> _trackToJson(Track t) => {
        'id': t.id,
        'title': t.title,
        'artist': t.artist,
        'album': t.album,
        'audioUrl': t.audioUrl,
        'imageUrl': t.imageUrl,
        'durationSeconds': t.durationSeconds,
      };

  Track _trackFromJson(Map<String, dynamic> json) => Track(
        id: json['id'] as String? ?? '',
        title: json['title'] as String? ?? '',
        artist: json['artist'] as String? ?? '',
        album: json['album'] as String?,
        audioUrl: json['audioUrl'] as String? ?? '',
        imageUrl: json['imageUrl'] as String? ?? '',
        durationSeconds: (json['durationSeconds'] as num?)?.toInt() ?? 0,
      );
}
