# Play Store Listing — Blocko

Copy/paste these into the Google Play Console. Tweak to taste.

---

## App name (30 char max)
```
Blocko: Block Puzzle
```

## Short description (80 char max)
```
Fit blocks, clear lines, chain combos. Relaxing offline puzzle. No wifi needed.
```

## Full description (4000 char max)
```
Blocko is a clean, satisfying block puzzle you can pick up in seconds and play
anywhere — no internet, no account, no pressure.

Drag blocks onto the grid. Fill a complete row or column to clear it. Line up
several clears at once to trigger big COMBOS and watch your score explode. Easy
to learn, endlessly replayable — one more go always turns into ten.

🧩 SIMPLE TO PLAY
Drag a block from the tray onto the 8×8 board. A preview shows exactly where it
will land. Complete any full row or column to clear it and score.

🔥 CHASE COMBOS
Clear multiple lines with a single placement — or on back-to-back moves — to stack
up combo and streak bonuses. The more you clear at once, the bigger the payoff.

✨ FEELS GREAT
Glossy blocks, snappy particle bursts, line-clear flashes, gentle haptics, and a
soft ambient soundtrack make every move satisfying.

📴 PLAY ANYWHERE, OFFLINE
No internet connection required. No sign-in. Perfect for flights, commutes, waiting
rooms, or winding down before bed.

🔒 PRIVACY-FIRST
No ads. No tracking. No data collection. No permissions. Your best score is saved
right on your device and never leaves it.

📱 FITS YOUR PHONE
Designed to scale beautifully on any Android phone or tablet.

How long can your run last before the board fills up? Drop a block and find out.

fit · clear · combo
```

## Category
- **Application type:** Games
- **Category:** Puzzle
- (Secondary, if asked: Casual / Brain Games)

## Tags / keywords (for ASO — work into the text, Play has no separate field)
```
block puzzle, blocks, fit, line clear, combo, brain, casual, offline, relaxing,
1010, grid puzzle, wood block, puzzle game
```

## Contact details
- **Email:** [YOUR EMAIL]
- **Website (optional):** [YOUR URL]
- **Privacy policy URL:** [HOSTED PRIVACY_POLICY.md URL]

## Content rating
- Expected: **Everyone / PEGI 3** (no objectionable content).

## Data safety
- **Data collected:** None
- **Data shared:** None
- **Permissions:** None
- **Offline:** Yes — app works without a network connection.

## Pricing & distribution
- **Free**
- No in-app purchases (current build)
- **Contains ads:** No

---

## Graphics checklist
- [x] **App icon (512×512):** `store_assets/play_store_icon_512.png`
- [x] **Feature graphic (1024×500):** `store_assets/feature_graphic_1024x500.png`
- [ ] **Phone screenshots (2–8):** capture from a device/emulator (Power + Volume‑Down).
      Grab the start screen, a mid-game board, a combo moment, and the game-over screen.
- [ ] (Optional) **Tablet screenshots** for better tablet placement.

## What's new (release notes — first version)
```
First release of Blocko! Fit blocks, clear lines, chain combos. 100% offline,
no ads, no tracking. Have fun and beat your best score!
```
