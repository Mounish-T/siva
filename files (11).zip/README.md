# Blocko 🧩

**fit · clear · combo** — a fast, satisfying block‑fit puzzle for Android.

Drag blocks from the tray onto the 8×8 grid. Fill any complete **row or column** to
clear it, and clear several lines at once to rack up **combos**. Simple to learn,
endless to play — the format that topped the mobile charts in 2025.

This repository is a **complete, ready‑to‑build Android Studio project**. Everything
is included: source, generated sound effects, app icons, and Play Store graphics.

---

## ✨ Highlights

- **100% offline** — no internet permission, no accounts, no ads, no tracking.
- **Runs on virtually any Android device** — Android 7.0 (API 24) and up; the board
  scales to any screen size and density (phones and tablets).
- **Juicy feel** — glossy candy blocks, particle bursts and flashes on every clear,
  combo banners, and light haptics.
- **Procedural sound** — all effects and the ambient pad were generated and bundled,
  so the game makes sound with zero external assets.
- **Persistent best score** — saved locally with `SharedPreferences`.
- **Modern stack** — 100% Kotlin + Jetpack Compose, custom `Canvas` board with
  drag‑and‑drop.

---

## 📁 What's inside

```
Blocko/
├─ app/
│  ├─ build.gradle.kts
│  └─ src/main/
│     ├─ AndroidManifest.xml
│     ├─ java/com/blocko/puzzle/
│     │  ├─ MainActivity.kt           # Compose host + lifecycle
│     │  ├─ ScorePrefs.kt             # best-score persistence
│     │  ├─ game/
│     │  │  ├─ Pieces.kt              # polyomino shapes
│     │  │  └─ GameEngine.kt          # board, placement, line clears, scoring
│     │  ├─ audio/GameAudio.kt        # SoundPool SFX + ambient loop
│     │  └─ ui/
│     │     ├─ GameScreen.kt          # board, tray, drag/drop, FX, overlays
│     │     └─ theme/                 # colors, type, theme
│     └─ res/
│        ├─ raw/                      # generated .wav sound effects
│        ├─ mipmap-*/                 # app icons (all densities + adaptive)
│        ├─ drawable/, values/, xml/
├─ store_assets/
│  ├─ play_store_icon_512.png         # 512×512 Play listing icon
│  └─ feature_graphic_1024x500.png    # 1024×500 feature graphic
├─ PLAY_STORE_LISTING.md              # ready-to-paste store copy
├─ PRIVACY_POLICY.md                  # host this and link it in Play Console
└─ README.md                          # you are here
```

---

## ▶️ Open & run

1. Install the latest **Android Studio** (it bundles the right JDK 17 and Android SDK).
2. **File ▸ Open** and select this `Blocko` folder.
3. Let **Gradle sync** finish. On first sync Android Studio downloads Gradle 8.9 and
   **regenerates the Gradle wrapper JAR** automatically — that file is intentionally
   not shipped, so this is expected.
4. Pick a device (a physical phone with USB debugging, or an emulator) and press
   **Run ▶**. That's it — you're playing.

> Requires internet **only** the first time, to download Gradle and the Android
> dependencies. The app itself never uses the network.

---

## 🎮 How to play

- Three blocks sit in the tray at the bottom. **Drag** one onto the grid; a preview
  shows where it will land (white outline = fits, red = blocked).
- Completing a full **row or column** clears it and scores points.
- Clear **multiple lines with one placement** (or clear on consecutive moves) for
  **combo/streak bonuses**.
- When all three tray blocks are used, three new ones appear.
- The game ends when **none** of the tray blocks can fit anywhere. Beat your best!

---

## 🔧 Easy customization

| Want to change… | Edit |
| --- | --- |
| App display name | `app/src/main/res/values/strings.xml` |
| Package / app id | `applicationId` and `namespace` in `app/build.gradle.kts` (and the `package` folders) |
| Colors / block palette | `app/src/main/java/com/blocko/puzzle/ui/theme/Color.kt` |
| Board size (e.g. 9×9) | `GameEngine(size = 8)` in `GameScreen.kt` *(also update the hard‑coded `8` in the board canvas)* |
| Available block shapes | `app/src/main/java/com/blocko/puzzle/game/Pieces.kt` |
| Sounds | replace the `.wav` files in `app/src/main/res/raw/` |
| App icon | replace the `ic_launcher*` images in `mipmap-*` (or regenerate) |

---

## 🔐 Build a signed release (AAB for Play Store)

Google Play requires a signed **Android App Bundle (`.aab`)**.

1. In Android Studio: **Build ▸ Generate Signed App Bundle / APK… ▸ Android App Bundle**.
2. **Create new…** a keystore (or reuse one). Pick a strong password.
   - **Back this keystore up and never lose it.** You must sign every future update
     with the same key, or Play will reject the upload.
3. Choose the **release** build variant and finish.
4. The bundle is written to:
   `app/release/app-release.aab`

> Tip: enable **Play App Signing** in the Console (recommended). You upload your
> bundle signed with your upload key, and Google manages the final app‑signing key.

---

## 🚀 Publish to Google Play (first‑timer walkthrough)

1. **Create a Play Console account** (one‑time US$25 fee) at
   https://play.google.com/console and complete identity verification.
2. **Create app** → name **Blocko**, type **Game**, **Free**.
3. **Store listing** — paste the text from `PLAY_STORE_LISTING.md`. Upload:
   - **App icon**: `store_assets/play_store_icon_512.png`
   - **Feature graphic**: `store_assets/feature_graphic_1024x500.png`
   - **Screenshots**: run the app and capture 2–8 phone screenshots (required).
4. **Content rating** — fill the questionnaire. Blocko has no objectionable content,
   so it rates **Everyone / PEGI 3**.
5. **Data safety** — declare **no data collected and no data shared** (the only stored
   value is the best score, kept on‑device). The app uses no permissions and is offline.
6. **App content** — privacy policy URL (host `PRIVACY_POLICY.md`, e.g. on GitHub Pages),
   ads declaration = **No ads**, target audience, etc.
7. **Create a release** → start with **Internal testing** to try it on your own device,
   then promote to **Production**. Upload your `app-release.aab`.
8. Set **countries/regions** and **pricing** (Free), then **Send for review**.
   First reviews typically take a couple of days.

The whole process is roughly **30–45 minutes of clicking**, most of it account setup
and the listing — the app is build‑ready as‑is.

---

## 💰 Optional: adding ads later

Blocko ships **ad‑free** on purpose (it feels better and reviews better). If you later
want to monetize, the cleanest add is a single occasional **interstitial** on game over
via Google **AdMob**:

1. Add `implementation("com.google.android.gms:play-services-ads:23.x.x")`.
2. Add your AdMob **App ID** to the manifest and the **INTERNET** permission.
3. Load an interstitial and show it every few game‑overs (don't over‑show — Play
   penalizes intrusive ads).
4. Update **Data safety** and the **ads declaration** accordingly.

Keep the cadence gentle: casual players churn fast on aggressive ads.

---

## 🛠 Troubleshooting

- **"gradle-wrapper.jar missing"** → just let Android Studio sync; it regenerates it.
  (Or run `gradle wrapper` if you have Gradle installed.)
- **Min SDK** is 24 (Android 7.0). Lower it in `app/build.gradle.kts` if you really
  need older devices.
- The app is **portrait‑locked** by design. Remove `android:screenOrientation` in the
  manifest to allow rotation.

---

## 📜 License

You own this code — ship it, modify it, rebrand it. The bundled fonts are the Android
system fonts; the sounds and icons in this project were generated for it and are yours
to use.
