# Privacy Policy for Blocko

_Last updated: [DATE]_

Thank you for playing **Blocko** (the "Game"). This Privacy Policy explains how the
Game handles information. **Blocko is designed to respect your privacy completely.**

## The short version

**Blocko does not collect, store, transmit, or share any personal data.** The Game
works fully offline and requests **no permissions**.

## Information we collect

**None.** The Game does not collect any personal or sensitive user data. Specifically,
the Game does **not**:

- Collect your name, email, phone number, or any identifiers.
- Request access to your location, contacts, camera, microphone, photos, or files.
- Use any analytics, advertising, or tracking SDKs.
- Require an account or login.
- Connect to the internet (it has no internet permission).

## Data stored on your device

The Game saves a single value — **your best score** — locally on your device using
Android's standard app‑preferences storage. This information:

- Never leaves your device.
- Is not accessible to us or any third party.
- Is removed when you uninstall the Game or clear its data.

## Children's privacy

Blocko is suitable for all ages and contains no objectionable content. Because the
Game collects no data whatsoever, it is compliant with children's privacy regulations
such as COPPA and GDPR‑K. We do not knowingly collect information from anyone,
including children under 13.

## Third‑party services

The Game includes **no** third‑party services, advertising networks, or analytics
providers.

## Changes to this policy

If this Game is updated in a way that affects privacy (for example, if optional ads
are added in a future version), this policy will be updated and the "Last updated"
date above will change.

## Contact

If you have any questions about this Privacy Policy, contact:

**[YOUR NAME / COMPANY]**
**[YOUR EMAIL]**

---

_Replace the bracketed placeholders before publishing, and host this file at a public
URL (for example GitHub Pages) so you can link it in the Google Play Console._
