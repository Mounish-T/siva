"""
================================================================================
  COGNIZANT ACE TEAM — INTERVIEW CODING CHEATSHEET (Python)
  For: Sivaraman M  |  Role: Ace – Full Stack AI Engineer (12-18 LPA)
================================================================================

How to use this file:
  - Each problem is a numbered section. Each section has:
      (a) The problem statement (what an interviewer will say)
      (b) The "naive" approach in 1 line
      (c) The optimal solution with comments
      (d) Time + space complexity
      (e) A test that runs when you execute this file
  - When you walk into the interview, you should be able to write the OPTIMAL
    version of each of these in under 5 minutes, talking out loud.
  - Run this file: `python interview_coding_cheatsheet.py`
    Every test should print "PASS".

Priority tiers (study in this order):
  TIER 1 (must know cold): #1-#12      Strings/arrays/hashmaps/two-pointers
  TIER 2 (very likely):    #13-#22     Recursion/trees/linked lists/stack
  TIER 3 (nice to have):   #23-#28     Sliding window, sorting, basic DP
  TIER 4 (AI-flavored):    #29-#32     RAG-style problems Ace might ask

================================================================================
"""


# ============================================================================
# TIER 1 — Strings, Arrays, HashMaps, Two-Pointers
# ============================================================================


# ----------------------------------------------------------------------------
# 1. REVERSE A STRING
# ----------------------------------------------------------------------------
# Interviewer: "Reverse a string without using built-in reverse()."
# Naive: slicing s[::-1] (works but doesn't show thinking)
# Optimal: two-pointer swap in-place (when given a list of chars).
# Talk track: "I'll use two pointers — one at the start, one at the end —
#              and swap until they meet. O(n) time, O(1) extra space."

def reverse_string(s: str) -> str:
    chars = list(s)
    left, right = 0, len(chars) - 1
    while left < right:
        chars[left], chars[right] = chars[right], chars[left]
        left += 1
        right -= 1
    return "".join(chars)

# Time: O(n)   Space: O(n) for output (O(1) if mutating list in place)


# ----------------------------------------------------------------------------
# 2. CHECK PALINDROME
# ----------------------------------------------------------------------------
# Interviewer: "Check whether a string is a palindrome (ignore case + spaces)."
# Talk track: "Normalize the string — lowercase, alphanumeric only — then
#              two pointers from both ends."

def is_palindrome(s: str) -> bool:
    cleaned = [c.lower() for c in s if c.isalnum()]
    left, right = 0, len(cleaned) - 1
    while left < right:
        if cleaned[left] != cleaned[right]:
            return False
        left += 1
        right -= 1
    return True

# Time: O(n)   Space: O(n)


# ----------------------------------------------------------------------------
# 3. CHECK PRIME NUMBER
# ----------------------------------------------------------------------------
# Interviewer: "Check if a number is prime."
# Naive: loop from 2 to n-1 — O(n).
# Optimal: loop only to sqrt(n). Even numbers > 2 short-circuit.
# Talk track: "A factor larger than sqrt(n) would pair with a smaller one
#              we've already checked, so sqrt(n) is enough."

def is_prime(n: int) -> bool:
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True

# Time: O(sqrt(n))   Space: O(1)


# ----------------------------------------------------------------------------
# 4. FACTORIAL (iterative + recursive)
# ----------------------------------------------------------------------------
# Talk track: "I'll show both. Recursive is elegant but stack-limited;
#              iterative is what I'd ship to production."

def factorial_iterative(n: int) -> int:
    if n < 0:
        raise ValueError("factorial undefined for negatives")
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

def factorial_recursive(n: int) -> int:
    if n < 0:
        raise ValueError("factorial undefined for negatives")
    if n <= 1:
        return 1
    return n * factorial_recursive(n - 1)

# Time: O(n)   Space: O(1) iterative, O(n) recursive (call stack)


# ----------------------------------------------------------------------------
# 5. FIBONACCI (n-th term, iterative)
# ----------------------------------------------------------------------------
# Talk track: "Recursion gives O(2^n) — too slow. Iterative bottom-up uses
#              two variables and runs in O(n) time, O(1) space."

def fibonacci(n: int) -> int:
    if n < 0:
        raise ValueError("fib undefined for negatives")
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

# Time: O(n)   Space: O(1)


# ----------------------------------------------------------------------------
# 6. FIND DUPLICATES IN ARRAY
# ----------------------------------------------------------------------------
# Talk track: "Hash set — single pass. O(n) time, O(n) space."

def find_duplicates(arr: list[int]) -> list[int]:
    seen, dupes = set(), set()
    for x in arr:
        if x in seen:
            dupes.add(x)
        else:
            seen.add(x)
    return sorted(dupes)

# Time: O(n)   Space: O(n)


# ----------------------------------------------------------------------------
# 7. TWO SUM (classic — appears constantly)
# ----------------------------------------------------------------------------
# Interviewer: "Given an array and a target, return the two indices whose
#              values sum to the target."
# Talk track: "Brute force is O(n^2). HashMap lets us do it in one pass:
#              for each element, check if (target - element) was already seen."

def two_sum(nums: list[int], target: int) -> list[int]:
    seen = {}  # value -> index
    for i, x in enumerate(nums):
        complement = target - x
        if complement in seen:
            return [seen[complement], i]
        seen[x] = i
    return []  # no answer

# Time: O(n)   Space: O(n)


# ----------------------------------------------------------------------------
# 8. FIND MISSING NUMBER (1..n)
# ----------------------------------------------------------------------------
# Talk track: "Sum formula: n*(n+1)/2 minus actual sum gives the missing one.
#              Avoids extra space; one pass; arithmetic only."

def find_missing(nums: list[int], n: int) -> int:
    expected = n * (n + 1) // 2
    actual = sum(nums)
    return expected - actual

# Time: O(n)   Space: O(1)


# ----------------------------------------------------------------------------
# 9. ANAGRAM CHECK
# ----------------------------------------------------------------------------
# Talk track: "Two ways: sort both — O(n log n); or count chars in a dict —
#              O(n). I prefer counting because it scales better."

def is_anagram(a: str, b: str) -> bool:
    if len(a) != len(b):
        return False
    counts: dict[str, int] = {}
    for c in a:
        counts[c] = counts.get(c, 0) + 1
    for c in b:
        if c not in counts or counts[c] == 0:
            return False
        counts[c] -= 1
    return True

# Time: O(n)   Space: O(k) where k is alphabet size


# ----------------------------------------------------------------------------
# 10. FIRST NON-REPEATING CHARACTER
# ----------------------------------------------------------------------------
# Talk track: "Two passes: count frequencies, then walk the string and return
#              the first char whose count is 1. Dict order is insertion order
#              in Python 3.7+ so even one pass works if you're careful."

def first_non_repeating(s: str) -> str | None:
    counts = {}
    for c in s:
        counts[c] = counts.get(c, 0) + 1
    for c in s:
        if counts[c] == 1:
            return c
    return None

# Time: O(n)   Space: O(k)


# ----------------------------------------------------------------------------
# 11. SORT 0s, 1s, AND 2s (Dutch National Flag)
# ----------------------------------------------------------------------------
# Talk track: "Could sort — O(n log n). But there are only 3 distinct values,
#              so three pointers (low, mid, high) does it in O(n), O(1)."

def sort_012(nums: list[int]) -> list[int]:
    low, mid, high = 0, 0, len(nums) - 1
    while mid <= high:
        if nums[mid] == 0:
            nums[low], nums[mid] = nums[mid], nums[low]
            low += 1
            mid += 1
        elif nums[mid] == 1:
            mid += 1
        else:  # nums[mid] == 2
            nums[mid], nums[high] = nums[high], nums[mid]
            high -= 1
    return nums

# Time: O(n)   Space: O(1)


# ----------------------------------------------------------------------------
# 12. MOVE ZEROES TO END (preserve order of non-zeros)
# ----------------------------------------------------------------------------
# Talk track: "One pointer for where the next non-zero goes. Single pass,
#              in place, preserves order."

def move_zeros(nums: list[int]) -> list[int]:
    write = 0
    for read in range(len(nums)):
        if nums[read] != 0:
            nums[write], nums[read] = nums[read], nums[write]
            write += 1
    return nums

# Time: O(n)   Space: O(1)


# ============================================================================
# TIER 2 — Recursion, Trees, Linked Lists, Stack
# ============================================================================


# ----------------------------------------------------------------------------
# 13. REVERSE A LINKED LIST
# ----------------------------------------------------------------------------
# Talk track: "Iterative: keep three pointers — prev, curr, next. Flip the
#              link, advance. Single pass, O(1) space."

class ListNode:
    def __init__(self, val: int = 0, next_: "ListNode | None" = None):
        self.val = val
        self.next = next_

def reverse_linked_list(head: ListNode | None) -> ListNode | None:
    prev, curr = None, head
    while curr:
        nxt = curr.next
        curr.next = prev
        prev = curr
        curr = nxt
    return prev

# Helpers to build/print linked lists for tests:
def to_linked_list(values: list[int]) -> ListNode | None:
    dummy = ListNode()
    tail = dummy
    for v in values:
        tail.next = ListNode(v)
        tail = tail.next
    return dummy.next

def from_linked_list(head: ListNode | None) -> list[int]:
    out = []
    while head:
        out.append(head.val)
        head = head.next
    return out


# ----------------------------------------------------------------------------
# 14. BALANCED PARENTHESES (using stack)
# ----------------------------------------------------------------------------
# Talk track: "Push openers onto a stack; for each closer, check the top
#              matches. Empty stack at end = balanced."

def is_balanced(s: str) -> bool:
    pairs = {")": "(", "]": "[", "}": "{"}
    stack: list[str] = []
    for c in s:
        if c in "([{":
            stack.append(c)
        elif c in ")]}":
            if not stack or stack[-1] != pairs[c]:
                return False
            stack.pop()
    return not stack

# Time: O(n)   Space: O(n)


# ----------------------------------------------------------------------------
# 15. BINARY SEARCH (iterative)
# ----------------------------------------------------------------------------
# Talk track: "Sorted input required. Two pointers (low, high). Halve the
#              search space each step — O(log n)."

def binary_search(arr: list[int], target: int) -> int:
    low, high = 0, len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1

# Time: O(log n)   Space: O(1)


# ----------------------------------------------------------------------------
# 16. BINARY TREE — INORDER TRAVERSAL (recursive)
# ----------------------------------------------------------------------------
# Talk track: "Inorder = left, root, right. For BSTs this gives sorted order."

class TreeNode:
    def __init__(self, val: int = 0,
                 left: "TreeNode | None" = None,
                 right: "TreeNode | None" = None):
        self.val = val
        self.left = left
        self.right = right

def inorder(root: TreeNode | None) -> list[int]:
    out: list[int] = []
    def walk(node: TreeNode | None) -> None:
        if not node:
            return
        walk(node.left)
        out.append(node.val)
        walk(node.right)
    walk(root)
    return out

# Time: O(n)   Space: O(h) where h is tree height


# ----------------------------------------------------------------------------
# 17. BINARY TREE — HEIGHT / MAX DEPTH
# ----------------------------------------------------------------------------
# Talk track: "Recursive: height = 1 + max(left subtree, right subtree)."

def tree_height(root: TreeNode | None) -> int:
    if not root:
        return 0
    return 1 + max(tree_height(root.left), tree_height(root.right))

# Time: O(n)   Space: O(h)


# ----------------------------------------------------------------------------
# 18. GCD (Euclidean algorithm)
# ----------------------------------------------------------------------------
# Talk track: "Euclid's algorithm: gcd(a, b) = gcd(b, a mod b). Converges
#              in O(log(min(a,b))) steps."

def gcd(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return a


# ----------------------------------------------------------------------------
# 19. REVERSE A NUMBER
# ----------------------------------------------------------------------------
# Talk track: "Extract digits with mod 10, build result with multiply by 10."

def reverse_number(n: int) -> int:
    sign = -1 if n < 0 else 1
    n = abs(n)
    result = 0
    while n > 0:
        result = result * 10 + n % 10
        n //= 10
    return sign * result


# ----------------------------------------------------------------------------
# 20. ARMSTRONG NUMBER
# ----------------------------------------------------------------------------
# An n-digit number that equals the sum of its digits each raised to n.
# E.g., 153 = 1^3 + 5^3 + 3^3.

def is_armstrong(n: int) -> bool:
    digits = str(n)
    power = len(digits)
    return sum(int(d) ** power for d in digits) == n


# ----------------------------------------------------------------------------
# 21. COUNT VOWELS AND CONSONANTS
# ----------------------------------------------------------------------------

def count_vowels_consonants(s: str) -> tuple[int, int]:
    vowels = set("aeiouAEIOU")
    v_count = c_count = 0
    for ch in s:
        if ch.isalpha():
            if ch in vowels:
                v_count += 1
            else:
                c_count += 1
    return v_count, c_count


# ----------------------------------------------------------------------------
# 22. PRINT PATTERN (right-angled triangle of stars)
# ----------------------------------------------------------------------------
# Cognizant LOVES these. Be ready for 3-4 variations.

def star_triangle(n: int) -> str:
    lines = []
    for i in range(1, n + 1):
        lines.append("*" * i)
    return "\n".join(lines)


# ============================================================================
# TIER 3 — Sliding Window, Sorting, Basic DP
# ============================================================================


# ----------------------------------------------------------------------------
# 23. MAXIMUM SUBARRAY (Kadane's algorithm)
# ----------------------------------------------------------------------------
# Talk track: "At each index, the max subarray ending here is either this
#              element alone, or this element plus the best ending at i-1.
#              One pass, O(n), O(1)."

def max_subarray(nums: list[int]) -> int:
    if not nums:
        return 0
    best = current = nums[0]
    for x in nums[1:]:
        current = max(x, current + x)
        best = max(best, current)
    return best

# Time: O(n)   Space: O(1)


# ----------------------------------------------------------------------------
# 24. LONGEST SUBSTRING WITHOUT REPEATING CHARACTERS
# ----------------------------------------------------------------------------
# Talk track: "Sliding window with a dict tracking the last index of each
#              char. When we see a repeat inside the window, jump the left
#              pointer past its previous position."

def longest_unique_substring(s: str) -> int:
    last_seen: dict[str, int] = {}
    left = 0
    best = 0
    for right, c in enumerate(s):
        if c in last_seen and last_seen[c] >= left:
            left = last_seen[c] + 1
        last_seen[c] = right
        best = max(best, right - left + 1)
    return best

# Time: O(n)   Space: O(k)


# ----------------------------------------------------------------------------
# 25. MERGE TWO SORTED ARRAYS
# ----------------------------------------------------------------------------
# Talk track: "Two pointers, one per array. Pick the smaller, advance."

def merge_sorted(a: list[int], b: list[int]) -> list[int]:
    i = j = 0
    result = []
    while i < len(a) and j < len(b):
        if a[i] <= b[j]:
            result.append(a[i]); i += 1
        else:
            result.append(b[j]); j += 1
    result.extend(a[i:])
    result.extend(b[j:])
    return result

# Time: O(n + m)   Space: O(n + m)


# ----------------------------------------------------------------------------
# 26. BUBBLE SORT
# ----------------------------------------------------------------------------
# They WILL ask. Even if it's not optimal, knowing it shows fundamentals.

def bubble_sort(arr: list[int]) -> list[int]:
    n = len(arr)
    for i in range(n - 1):
        swapped = False
        for j in range(n - 1 - i):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:  # already sorted — early exit
            break
    return arr

# Time: O(n^2) worst, O(n) best   Space: O(1)


# ----------------------------------------------------------------------------
# 27. CLIMB STAIRS (basic DP — counts ways to reach step n)
# ----------------------------------------------------------------------------
# Talk track: "ways(n) = ways(n-1) + ways(n-2). It's Fibonacci in disguise."

def climb_stairs(n: int) -> int:
    if n <= 2:
        return n
    a, b = 1, 2
    for _ in range(3, n + 1):
        a, b = b, a + b
    return b


# ----------------------------------------------------------------------------
# 28. STRING — LONGEST COMMON PREFIX
# ----------------------------------------------------------------------------

def longest_common_prefix(strs: list[str]) -> str:
    if not strs:
        return ""
    prefix = strs[0]
    for s in strs[1:]:
        while not s.startswith(prefix):
            prefix = prefix[:-1]
            if not prefix:
                return ""
    return prefix


# ============================================================================
# TIER 4 — AI/RAG-flavored problems (Ace Team SME round may ask these)
# ============================================================================


# ----------------------------------------------------------------------------
# 29. CHUNK A LONG TEXT FOR RAG (with overlap)
# ----------------------------------------------------------------------------
# Interviewer: "You're building a RAG pipeline. Write a function that
#              splits a long string into chunks of size N with overlap M."
# Talk track: "Overlap matters — it preserves cross-sentence context so
#              we don't lose meaning at chunk boundaries. This is exactly
#              what RecursiveCharacterTextSplitter does under the hood."

def chunk_text(text: str, chunk_size: int = 800, overlap: int = 120) -> list[str]:
    if overlap >= chunk_size:
        raise ValueError("overlap must be smaller than chunk_size")
    chunks = []
    start = 0
    n = len(text)
    while start < n:
        end = min(start + chunk_size, n)
        chunks.append(text[start:end])
        if end == n:
            break
        start = end - overlap  # step forward with overlap
    return chunks


# ----------------------------------------------------------------------------
# 30. COSINE SIMILARITY (the heart of vector retrieval)
# ----------------------------------------------------------------------------
# Interviewer: "Without numpy, compute cosine similarity between two
#              vectors. Why cosine, not Euclidean?"
# Talk track: "Cosine measures *direction* — it's robust to magnitude
#              differences between embeddings. Two semantically similar
#              sentences may produce vectors of different lengths but
#              nearly identical direction. That's why ChromaDB defaults
#              to cosine."

import math

def cosine_similarity(a: list[float], b: list[float]) -> float:
    if len(a) != len(b):
        raise ValueError("vectors must be same length")
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


# ----------------------------------------------------------------------------
# 31. TOP-K RETRIEVAL (mini vector search)
# ----------------------------------------------------------------------------
# Interviewer: "Given a query embedding and a list of document embeddings,
#              return the top-k most similar documents."
# Talk track: "This is the core of any vector DB. In production you'd use
#              an ANN index — HNSW or IVF — for sublinear search. For the
#              naive O(n*d) version, we just compute similarity to every
#              doc and pick the top k."

def top_k_retrieve(
    query: list[float],
    docs: list[tuple[str, list[float]]],
    k: int = 3,
) -> list[tuple[str, float]]:
    scored = [(doc_id, cosine_similarity(query, emb)) for doc_id, emb in docs]
    scored.sort(key=lambda x: x[1], reverse=True)
    return scored[:k]


# ----------------------------------------------------------------------------
# 32. VALIDATE STRUCTURED LLM OUTPUT (JSON shape check)
# ----------------------------------------------------------------------------
# Interviewer: "An LLM is supposed to return JSON with keys 'answer' (str),
#              'sources' (list of str), and 'confidence' (one of high/medium/low).
#              Write a validator that returns True only if the shape is exact."
# Talk track: "This is what Pydantic does for us in real systems — but
#              writing it manually shows I understand the contract."

def validate_llm_output(data: dict) -> bool:
    if not isinstance(data, dict):
        return False
    required = {"answer": str, "sources": list, "confidence": str}
    if set(data.keys()) != set(required.keys()):
        return False
    for key, expected_type in required.items():
        if not isinstance(data[key], expected_type):
            return False
    if data["confidence"] not in {"high", "medium", "low"}:
        return False
    if not all(isinstance(s, str) for s in data["sources"]):
        return False
    return True


# ============================================================================
# SQL CORNER (memorize these patterns — they will ask)
# ============================================================================
SQL_REFERENCE = """
-- 1. SECOND HIGHEST SALARY (classic — appears in every drive)
SELECT MAX(salary) AS second_highest
FROM employees
WHERE salary < (SELECT MAX(salary) FROM employees);

-- Alternative (more general — Nth highest):
SELECT DISTINCT salary FROM employees
ORDER BY salary DESC LIMIT 1 OFFSET 1;

-- 2. EMPLOYEES EARNING MORE THAN THEIR MANAGER (self-join)
SELECT e.name
FROM employees e
JOIN employees m ON e.manager_id = m.id
WHERE e.salary > m.salary;

-- 3. DUPLICATE ROWS
SELECT email, COUNT(*) AS c
FROM users
GROUP BY email
HAVING COUNT(*) > 1;

-- 4. DEPARTMENT-WISE EMPLOYEE COUNT (GROUP BY + JOIN)
SELECT d.name AS department, COUNT(e.id) AS headcount
FROM departments d
LEFT JOIN employees e ON e.dept_id = d.id
GROUP BY d.name
ORDER BY headcount DESC;

-- 5. TOP-N PER GROUP (window function — modern SQL)
SELECT * FROM (
    SELECT name, dept_id, salary,
           RANK() OVER (PARTITION BY dept_id ORDER BY salary DESC) AS rnk
    FROM employees
) ranked
WHERE rnk <= 3;

-- 6. INNER vs LEFT vs RIGHT vs FULL JOIN — know the Venn diagram cold.
--    INNER = intersection only.
--    LEFT  = all of left + matching right (NULL when no match).
--    RIGHT = mirror of LEFT.
--    FULL  = union — everything from both sides.

-- 7. WHERE vs HAVING:
--    WHERE filters rows BEFORE grouping.
--    HAVING filters groups AFTER grouping.
--    Aggregates (SUM, COUNT, AVG) only work inside HAVING.
"""


# ============================================================================
# TESTS — run this file to verify everything works
# ============================================================================

def _run_tests() -> None:
    checks = []

    # Tier 1
    checks.append(("reverse_string",          reverse_string("hello") == "olleh"))
    checks.append(("is_palindrome.true",      is_palindrome("A man, a plan, a canal: Panama") is True))
    checks.append(("is_palindrome.false",     is_palindrome("hello") is False))
    checks.append(("is_prime.7",              is_prime(7) is True))
    checks.append(("is_prime.9",              is_prime(9) is False))
    checks.append(("is_prime.2",              is_prime(2) is True))
    checks.append(("factorial_iter.5",        factorial_iterative(5) == 120))
    checks.append(("factorial_rec.5",         factorial_recursive(5) == 120))
    checks.append(("fibonacci.10",            fibonacci(10) == 55))
    checks.append(("find_duplicates",         find_duplicates([1, 2, 3, 2, 4, 1, 5]) == [1, 2]))
    checks.append(("two_sum",                 two_sum([2, 7, 11, 15], 9) == [0, 1]))
    checks.append(("find_missing",            find_missing([1, 2, 4, 5], 5) == 3))
    checks.append(("is_anagram.true",         is_anagram("listen", "silent") is True))
    checks.append(("is_anagram.false",        is_anagram("hello", "world") is False))
    checks.append(("first_non_repeating",     first_non_repeating("aabbcdc") == "d"))
    checks.append(("sort_012",                sort_012([2, 0, 2, 1, 1, 0]) == [0, 0, 1, 1, 2, 2]))
    checks.append(("move_zeros",              move_zeros([0, 1, 0, 3, 12]) == [1, 3, 12, 0, 0]))

    # Tier 2
    rev = reverse_linked_list(to_linked_list([1, 2, 3, 4, 5]))
    checks.append(("reverse_linked_list",     from_linked_list(rev) == [5, 4, 3, 2, 1]))
    checks.append(("is_balanced.ok",          is_balanced("({[]})") is True))
    checks.append(("is_balanced.bad",         is_balanced("({[})") is False))
    checks.append(("binary_search.found",     binary_search([1, 3, 5, 7, 9, 11], 7) == 3))
    checks.append(("binary_search.miss",      binary_search([1, 3, 5, 7, 9, 11], 4) == -1))
    bst = TreeNode(4, TreeNode(2, TreeNode(1), TreeNode(3)), TreeNode(6, TreeNode(5), TreeNode(7)))
    checks.append(("inorder",                 inorder(bst) == [1, 2, 3, 4, 5, 6, 7]))
    checks.append(("tree_height",             tree_height(bst) == 3))
    checks.append(("gcd",                     gcd(48, 18) == 6))
    checks.append(("reverse_number",          reverse_number(-12345) == -54321))
    checks.append(("armstrong.153",           is_armstrong(153) is True))
    checks.append(("armstrong.154",           is_armstrong(154) is False))
    checks.append(("count_vowels",            count_vowels_consonants("Hello World") == (3, 7)))
    checks.append(("star_triangle",           star_triangle(3) == "*\n**\n***"))

    # Tier 3
    checks.append(("max_subarray",            max_subarray([-2, 1, -3, 4, -1, 2, 1, -5, 4]) == 6))
    checks.append(("longest_unique_substring", longest_unique_substring("abcabcbb") == 3))
    checks.append(("merge_sorted",            merge_sorted([1, 3, 5], [2, 4, 6]) == [1, 2, 3, 4, 5, 6]))
    checks.append(("bubble_sort",             bubble_sort([5, 2, 8, 1, 9, 3]) == [1, 2, 3, 5, 8, 9]))
    checks.append(("climb_stairs.5",          climb_stairs(5) == 8))
    checks.append(("longest_common_prefix",   longest_common_prefix(["flower", "flow", "flight"]) == "fl"))

    # Tier 4 (AI-flavored)
    # 1000 chars, chunk_size=400, overlap=100 → step = 300.
    # Chunks: [0:400], [300:700], [600:1000] → 3 chunks total.
    chunks = chunk_text("a" * 1000, chunk_size=400, overlap=100)
    checks.append(("chunk_text.count",        len(chunks) == 3))
    checks.append(("chunk_text.size",         all(len(c) <= 400 for c in chunks)))
    sim = cosine_similarity([1.0, 0.0, 0.0], [1.0, 0.0, 0.0])
    checks.append(("cosine.identical",        abs(sim - 1.0) < 1e-9))
    sim2 = cosine_similarity([1.0, 0.0], [0.0, 1.0])
    checks.append(("cosine.orthogonal",       abs(sim2 - 0.0) < 1e-9))
    docs = [("d1", [1.0, 0.0]), ("d2", [0.0, 1.0]), ("d3", [0.9, 0.1])]
    top = top_k_retrieve([1.0, 0.0], docs, k=2)
    checks.append(("top_k.first",             top[0][0] == "d1"))
    checks.append(("top_k.second",            top[1][0] == "d3"))
    good = {"answer": "yes", "sources": ["a", "b"], "confidence": "high"}
    bad1 = {"answer": "yes", "sources": ["a"], "confidence": "super"}
    bad2 = {"answer": "yes", "sources": "a", "confidence": "high"}
    checks.append(("validate_llm.good",       validate_llm_output(good) is True))
    checks.append(("validate_llm.bad_enum",   validate_llm_output(bad1) is False))
    checks.append(("validate_llm.bad_type",   validate_llm_output(bad2) is False))

    # report
    total = len(checks)
    passed = sum(1 for _, ok in checks if ok)
    width = max(len(name) for name, _ in checks)
    for name, ok in checks:
        status = "PASS" if ok else "FAIL"
        print(f"  [{status}] {name.ljust(width)}")
    print(f"\n  {passed} / {total} tests passed.\n")
    if passed != total:
        raise SystemExit(1)


if __name__ == "__main__":
    print("Running interview coding cheatsheet tests...\n")
    _run_tests()
    print("All clear. Walk into that interview ready.\n")
