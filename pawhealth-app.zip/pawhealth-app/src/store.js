// src/store.js — single source of truth, persisted to the device with AsyncStorage.
// Privacy-first: everything lives locally on the phone. No servers, no selling data.
import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

const KEY = "pawhealth.state.v1";
const DAY = 24 * 60 * 60 * 1000;
export const TRIAL_DAYS = 15; // first 15 days of Premium are free for everyone

const DEFAULT = {
  pet: null,            // {key, emoji, name, archetype, hello}
  petName: "",
  themeKey: "sakura",
  coins: 120,
  wellness: 58,
  streakDays: 3,
  streakState: "active", // active | resting | recovering
  builtinDone: {},       // { goalId: true }
  customActivities: [],  // [{id,title,pillar,diff,coins,emoji}]
  customDone: {},        // { activityId: true }
  firstLaunch: 0,        // ms — set once, drives the free trial
  purchased: false,      // PawHealth+ lifetime unlock
  shared: false,         // achievement: shared once
  totalDistance: 0,      // km, lifetime (tracker)
  totalSteps: 0,
  totalSessions: 0,
  lastDay: 0,            // ms day-stamp to reset "today" goals
};

const Ctx = createContext(null);

function dayStamp(ms) { const d = new Date(ms); d.setHours(0, 0, 0, 0); return d.getTime(); }

export function AppProvider({ children }) {
  const [state, setState] = useState(DEFAULT);
  const [hydrated, setHydrated] = useState(false);
  const saveTimer = useRef(null);

  // load once
  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(KEY);
        let next = raw ? { ...DEFAULT, ...JSON.parse(raw) } : { ...DEFAULT };
        if (!next.firstLaunch) next.firstLaunch = Date.now(); // start the free trial clock
        // new calendar day → reset today's goal completions (streak logic stays)
        const today = dayStamp(Date.now());
        if (next.lastDay && next.lastDay !== today) {
          next.builtinDone = {};
          next.customDone = {};
        }
        next.lastDay = today;
        setState(next);
      } catch (e) {
        setState({ ...DEFAULT, firstLaunch: Date.now(), lastDay: dayStamp(Date.now()) });
      } finally {
        setHydrated(true);
      }
    })();
  }, []);

  // persist (debounced)
  useEffect(() => {
    if (!hydrated) return;
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      AsyncStorage.setItem(KEY, JSON.stringify(state)).catch(() => {});
    }, 250);
  }, [state, hydrated]);

  const patch = useCallback((p) => setState((s) => ({ ...s, ...(typeof p === "function" ? p(s) : p) })), []);

  // ---- derived premium / trial ----
  const trialMsLeft = Math.max(0, state.firstLaunch + TRIAL_DAYS * DAY - Date.now());
  const trialDaysLeft = Math.ceil(trialMsLeft / DAY);
  const inTrial = trialMsLeft > 0;
  const isPremium = !!state.purchased || inTrial;

  // ---- actions ----
  const choosePet = (pet) => patch({ pet });
  const setName = (petName) => patch({ petName });
  const setThemeKey = (themeKey) => patch({ themeKey });
  const setPurchased = (v) => patch({ purchased: !!v });
  const markShared = () => patch({ shared: true });

  const addCoins = (n) => patch((s) => ({ coins: s.coins + n }));
  const bumpWellness = (n) => patch((s) => ({ wellness: Math.max(0, Math.min(100, s.wellness + n)) }));

  function _afterComplete(s, allDoneNow) {
    let extra = {};
    if (s.streakState === "resting") extra.streakState = "recovering";
    if (allDoneNow) extra.wellness = Math.max(s.wellness, 92);
    return extra;
  }

  const completeBuiltin = (goal, builtinGoals) => {
    setState((s) => {
      if (s.builtinDone[goal.id]) return s;
      const builtinDone = { ...s.builtinDone, [goal.id]: true };
      const allBuiltin = builtinGoals.every((g) => builtinDone[g.id]);
      const allCustom = s.customActivities.every((a) => s.customDone[a.id]);
      const allDoneNow = allBuiltin && allCustom && (builtinGoals.length + s.customActivities.length) > 0;
      return {
        ...s,
        builtinDone,
        coins: s.coins + goal.coins + (allDoneNow ? 30 : 0),
        wellness: Math.max(0, Math.min(100, s.wellness + 9)),
        ..._afterComplete(s, allDoneNow),
      };
    });
  };

  const completeCustom = (act, builtinGoals) => {
    setState((s) => {
      if (s.customDone[act.id]) return s;
      const customDone = { ...s.customDone, [act.id]: true };
      const allBuiltin = builtinGoals.every((g) => s.builtinDone[g.id]);
      const allCustom = s.customActivities.every((a) => customDone[a.id]);
      const allDoneNow = allBuiltin && allCustom && (builtinGoals.length + s.customActivities.length) > 0;
      return {
        ...s,
        customDone,
        coins: s.coins + (act.coins || 5) + (allDoneNow ? 30 : 0),
        wellness: Math.max(0, Math.min(100, s.wellness + 9)),
        ..._afterComplete(s, allDoneNow),
      };
    });
  };

  const addActivity = (a) => patch((s) => ({ customActivities: [...s.customActivities, a] }));
  const deleteActivity = (id) => patch((s) => {
    const customActivities = s.customActivities.filter((x) => x.id !== id);
    const customDone = { ...s.customDone }; delete customDone[id];
    return { customActivities, customDone };
  });

  const skipDay = () => patch((s) => ({
    builtinDone: {}, customDone: {},
    wellness: Math.max(6, s.wellness - 18),
    streakState: "resting",
  }));

  const recordSession = ({ distanceKm = 0, steps = 0, reaction }) => patch((s) => ({
    totalDistance: +(s.totalDistance + distanceKm).toFixed(2),
    totalSteps: s.totalSteps + Math.round(steps),
    totalSessions: s.totalSessions + 1,
    coins: s.coins + 12,
    wellness: Math.max(0, Math.min(100, s.wellness + 8)),
    streakState: s.streakState === "resting" ? "recovering" : s.streakState,
  }));

  const value = {
    ...state, hydrated,
    isPremium, inTrial, trialDaysLeft,
    choosePet, setName, setThemeKey, setPurchased, markShared,
    addCoins, bumpWellness,
    completeBuiltin, completeCustom, addActivity, deleteActivity,
    skipDay, recordSession,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useApp must be used inside <AppProvider>");
  return v;
}
