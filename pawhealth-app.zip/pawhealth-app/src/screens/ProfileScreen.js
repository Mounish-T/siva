// src/screens/ProfileScreen.js — stats, achievements, share-to-social, themes, premium.
import React, { useRef } from "react";
import { View, Text, Pressable, ScrollView, StyleSheet, Share, Platform } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../store";
import { useTheme, THEMES } from "../theme";
import { getMood, moodColor, stageBadge } from "../data";
import { Pet, Card } from "../components";

let ViewShot = null, Sharing = null;
try { ViewShot = require("react-native-view-shot"); } catch (e) {}
try { Sharing = require("expo-sharing"); } catch (e) {}

export function ProfileScreen() {
  const { t, setThemeKey } = useTheme();
  const app = useApp();
  const shotRef = useRef(null);

  const mood = getMood(app.wellness);
  const mColor = moodColor(mood.key, t);
  const name = app.petName || app.pet?.name || "your pet";

  const ach = [
    { icon: "🐣", label: "Hatched a companion", got: true },
    { icon: "✍️", label: "Made an activity", got: app.customActivities.length > 0 },
    { icon: "🏃", label: "Tracked a session", got: app.totalSessions > 0 },
    { icon: "📤", label: "Shared progress", got: app.shared },
    { icon: "🪙", label: "150+ coins", got: app.coins >= 150 },
    { icon: "✨", label: "Reached Radiant", got: app.wellness >= 85 },
    { icon: "😴", label: "Honoured rest", got: app.streakState !== "active" },
    { icon: "💖", label: "PawHealth+ member", got: !!app.purchased },
  ];
  const got = ach.filter((a) => a.got).length;

  async function share() {
    const caption = `${name} is thriving on PawHealth! 🌸 Helping me build gentle, healthy habits — and keeping my little companion happy & well-fed. #PawHealth`;
    try {
      if (ViewShot && Sharing && shotRef.current) {
        const uri = await ViewShot.captureRef(shotRef, { format: "png", quality: 1 });
        const can = await Sharing.isAvailableAsync();
        if (can) { await Sharing.shareAsync(uri, { mimeType: "image/png", dialogTitle: "Share your progress" }); app.markShared(); return; }
      }
      await Share.share({ message: caption });
      app.markShared();
    } catch (e) {
      try { await Share.share({ message: caption }); app.markShared(); } catch (e2) {}
    }
  }

  return (
    <SafeAreaView style={[s.fill, { backgroundColor: t.bg1 }]} edges={["top"]}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 28 }}>
        <Text style={{ fontSize: 22, fontWeight: "800", color: t.ink, marginBottom: 12 }}>You & {name} 👤</Text>

        {/* Shareable achievement card (captured as image) */}
        <View ref={shotRef} collapsable={false} style={{ borderRadius: 26, overflow: "hidden" }}>
          <View style={{ backgroundColor: t.bg2, padding: 22, alignItems: "center" }}>
            <Pet emoji={app.pet?.emoji} size={86} />
            <Text style={{ fontSize: 22, fontWeight: "800", color: t.ink, marginTop: 6 }}>{name}</Text>
            <Text style={{ fontSize: 13, color: t.inkSoft, fontWeight: "700", marginTop: 2 }}>{stageBadge(app.streakDays)} · {mood.badge} {mood.label}</Text>
            <View style={{ flexDirection: "row", gap: 18, marginTop: 14 }}>
              <Mini t={t} v={app.streakDays + "d"} l="streak" />
              <Mini t={t} v={Math.round(app.wellness)} l="wellness" />
              <Mini t={t} v={app.totalSessions} l="sessions" />
            </View>
            <Text style={{ marginTop: 14, fontSize: 12, fontWeight: "800", color: t.accent, letterSpacing: 1 }}>✦ PAWHEALTH ✦</Text>
          </View>
        </View>

        <Pressable onPress={share}
          style={({ pressed }) => [{ marginTop: 12, paddingVertical: 14, borderRadius: 16, alignItems: "center", backgroundColor: t.accent, opacity: pressed ? 0.9 : 1 }]}>
          <Text style={{ color: "#fff", fontWeight: "800", fontSize: 15 }}>📤 Share my progress</Text>
        </Pressable>

        {/* stats */}
        <View style={{ flexDirection: "row", gap: 10, marginTop: 16 }}>
          <Stat t={t} icon="🪙" v={app.coins} l="coins" />
          <Stat t={t} icon="🏃" v={`${app.totalDistance.toFixed(1)}`} l="km total" />
          <Stat t={t} icon="🔥" v={`${app.streakDays}d`} l="streak" />
        </View>

        {/* achievements */}
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 18, marginBottom: 8 }}>
          <Text style={{ fontSize: 11, fontWeight: "800", letterSpacing: 1.1, color: t.inkSoft }}>ACHIEVEMENTS</Text>
          <Text style={{ fontSize: 12, fontWeight: "800", color: t.accent }}>{got}/{ach.length}</Text>
        </View>
        <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" }}>
          {ach.map((a, i) => (
            <View key={i} style={{ width: "48%", marginBottom: 10, flexDirection: "row", alignItems: "center", gap: 10,
              backgroundColor: t.cardSolid, borderRadius: 16, borderWidth: 1, borderColor: t.cardB, padding: 12, opacity: a.got ? 1 : 0.5 }}>
              <View style={{ width: 36, height: 36, borderRadius: 12, alignItems: "center", justifyContent: "center",
                backgroundColor: a.got ? t.accent + "1f" : "transparent", borderWidth: a.got ? 0 : 1.5, borderColor: t.inkSoft + "55", borderStyle: "dashed" }}>
                <Text style={{ fontSize: 18 }}>{a.got ? a.icon : "🔒"}</Text>
              </View>
              <Text style={{ flex: 1, fontSize: 12, fontWeight: "700", color: t.ink }}>{a.label}</Text>
            </View>
          ))}
        </View>

        {/* themes */}
        <Text style={{ fontSize: 11, fontWeight: "800", letterSpacing: 1.1, color: t.inkSoft, marginTop: 14, marginBottom: 8 }}>THEME</Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
          {THEMES.map((th) => (
            <Pressable key={th.key} onPress={() => setThemeKey(th.key)}
              style={{ flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 11, paddingVertical: 8, borderRadius: 14,
                borderWidth: 1.5, borderColor: th.key === t.key ? t.accent : t.cardB, backgroundColor: t.cardSolid }}>
              <View style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: th.accent }} />
              <Text style={{ color: t.ink, fontWeight: "700", fontSize: 12.5 }}>{th.name}</Text>
            </Pressable>
          ))}
        </View>

        {/* premium status */}
        <Card t={t} style={{ marginTop: 18 }}>
          {app.purchased ? (
            <Text style={{ color: t.ink, fontWeight: "700" }}>💖 PawHealth+ active — thank you! Ad-free, unlimited activities.</Text>
          ) : app.inTrial ? (
            <Text style={{ color: t.ink, fontWeight: "700" }}>✦ Free trial: {app.trialDaysLeft} day{app.trialDaysLeft === 1 ? "" : "s"} of PawHealth+ left.</Text>
          ) : (
            <Text style={{ color: t.ink, fontWeight: "700" }}>You're on the free plan (with ads).</Text>
          )}
          <Text style={{ color: t.inkSoft, fontSize: 12, marginTop: 6, lineHeight: 18 }}>
            🔒 Your wellness & cycle data stay on this device. No ads in Premium, and we never sell your data.
          </Text>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

function Mini({ t, v, l }) {
  return (
    <View style={{ alignItems: "center" }}>
      <Text style={{ fontSize: 20, fontWeight: "800", color: t.ink }}>{v}</Text>
      <Text style={{ fontSize: 10.5, fontWeight: "700", color: t.inkSoft, textTransform: "uppercase" }}>{l}</Text>
    </View>
  );
}
function Stat({ t, icon, v, l }) {
  return (
    <View style={{ flex: 1, alignItems: "center", backgroundColor: t.cardSolid, borderRadius: 18, borderWidth: 1, borderColor: t.cardB, paddingVertical: 13 }}>
      <Text style={{ fontSize: 18 }}>{icon}</Text>
      <Text style={{ fontSize: 19, fontWeight: "800", color: t.ink, marginTop: 2 }}>{v}</Text>
      <Text style={{ fontSize: 10.5, fontWeight: "700", color: t.inkSoft, textTransform: "uppercase" }}>{l}</Text>
    </View>
  );
}

const s = StyleSheet.create({ fill: { flex: 1 } });
