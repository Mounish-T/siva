// src/screens/HomeScreen.js — the daily care loop.
import React, { useMemo, useState } from "react";
import { View, Text, Pressable, ScrollView, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../store";
import { useTheme } from "../theme";
import { BASE_GOALS, PILLARS, REACTIONS, getMood, moodColor, stageBadge } from "../data";
import { Pet, Ring, Card, Row, Pill } from "../components";
import { AdBanner } from "../ads";

export function HomeScreen({ navigation }) {
  const { t } = useTheme();
  const app = useApp();
  const [reactionKey, setReactionKey] = useState(0);
  const [bubble, setBubble] = useState(null);

  const mood = getMood(app.wellness);
  const mColor = moodColor(mood.key, t);

  const builtin = BASE_GOALS;
  const customs = app.customActivities;
  const doneCount =
    builtin.filter((g) => app.builtinDone[g.id]).length +
    customs.filter((a) => app.customDone[a.id]).length;
  const total = builtin.length + customs.length;

  const line = useMemo(() => {
    if (bubble) return bubble;
    return mood.lines[Math.floor(Math.random() * mood.lines.length)];
  }, [bubble, mood.key]);

  function react(reaction) {
    setReactionKey((k) => k + 1);
    setBubble(REACTIONS[reaction]?.line || null);
    setTimeout(() => setBubble(null), 2200);
  }
  function doBuiltin(g) { app.completeBuiltin(g, builtin); react(g.reaction); }
  function doCustom(a) { app.completeCustom(a, builtin); react("custom"); }

  return (
    <SafeAreaView style={[s.fill, { backgroundColor: t.bg1 }]} edges={["top"]}>
      {/* app bar */}
      <View style={s.bar}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <View style={[s.avatar, { backgroundColor: t.cardSolid, borderColor: t.cardB }]}>
            <Text style={{ fontSize: 24 }}>{app.pet?.emoji}</Text>
          </View>
          <View>
            <Text style={{ fontSize: 17, fontWeight: "700", color: t.ink }}>{app.petName || app.pet?.name}</Text>
            <Text style={{ fontSize: 11, fontWeight: "700", color: t.inkSoft }}>{stageBadge(app.streakDays)} · Day {app.streakDays}</Text>
          </View>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
          {!app.isPremium ? (
            <Pressable onPress={() => navigation.navigate("Paywall")} style={[s.chip, { backgroundColor: t.accent }]}>
              <Text style={{ color: "#fff", fontWeight: "800", fontSize: 12 }}>Go+ ✦</Text>
            </Pressable>
          ) : app.inTrial ? (
            <Pressable onPress={() => navigation.navigate("Paywall")} style={[s.chip, { backgroundColor: t.accent + "22" }]}>
              <Text style={{ color: t.accent, fontWeight: "800", fontSize: 12 }}>Trial · {app.trialDaysLeft}d</Text>
            </Pressable>
          ) : (
            <View style={[s.chip, { backgroundColor: t.accent + "22" }]}>
              <Text style={{ color: t.accent, fontWeight: "800", fontSize: 12 }}>PawHealth+ ✦</Text>
            </View>
          )}
          <View style={[s.chip, { backgroundColor: t.cardSolid, borderWidth: 1, borderColor: t.cardB }]}>
            <Text style={{ fontWeight: "800", color: t.ink, fontSize: 14 }}>🪙 {app.coins}</Text>
          </View>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 24 }}>
        {/* pet stage */}
        <Card t={t} style={{ alignItems: "center", paddingVertical: 18 }}>
          <View style={{ backgroundColor: t.card, borderRadius: 18, paddingHorizontal: 15, paddingVertical: 10, maxWidth: "88%", borderWidth: 1, borderColor: t.cardB }}>
            <Text style={{ color: t.ink, fontWeight: "600", fontSize: 14.5, textAlign: "center", lineHeight: 20 }}>{line}</Text>
          </View>
          <Pressable onPress={() => react("pet")} style={{ height: 150, justifyContent: "center", alignItems: "center" }}>
            <Pet emoji={app.pet?.emoji} size={108} reactionKey={reactionKey} dim={mood.key === "dormant" || mood.key === "unwell"} />
          </Pressable>
          <Text style={{ fontSize: 11.5, color: t.inkSoft, opacity: 0.75 }}>tap {app.petName || "them"} to say hi 💕</Text>
        </Card>

        {/* wellness */}
        <Card t={t} style={{ flexDirection: "row", alignItems: "center", gap: 14, marginTop: 14 }}>
          <Ring value={app.wellness} color={mColor} badge={mood.badge} label={mood.label} t={t} />
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 12, fontWeight: "700", color: t.inkSoft, letterSpacing: 0.4 }}>WELLNESS SCORE</Text>
            <Text style={{ fontSize: 13.5, color: t.ink, fontWeight: "600", marginVertical: 4 }}>{doneCount}/{total} goals today</Text>
            <View style={{ height: 8, borderRadius: 8, backgroundColor: t.ringTrack, overflow: "hidden" }}>
              <View style={{ height: "100%", width: `${total ? (doneCount / total) * 100 : 0}%`, backgroundColor: t.accent, borderRadius: 8 }} />
            </View>
            <View style={{ marginTop: 11 }}>
              {app.streakState === "active" && <Pill t={t}>🔥 {app.streakDays}-day streak</Pill>}
              {app.streakState === "resting" && <Pill t={t} tone="soft">😴 Resting · never breaks</Pill>}
              {app.streakState === "recovering" && <Pill t={t} tone="soft">🌱 Recovering · welcome back</Pill>}
            </View>
          </View>
        </Card>

        <AdBanner premium={app.isPremium} />

        {/* today */}
        <Text style={{ fontSize: 11, fontWeight: "800", letterSpacing: 1.2, color: t.inkSoft, marginTop: 10, marginBottom: 4 }}>TODAY, GENTLY</Text>
        <Text style={{ fontSize: 19, fontWeight: "700", color: t.ink, marginBottom: 10 }}>A small step is still a step 🌱</Text>

        {builtin.map((g) => {
          const P = PILLARS[g.pillar];
          return (
            <Row key={g.id} t={t} icon={P.icon} tint={P.tint} title={g.title}
              subtitle={`${g.diff} · 🪙 ${g.coins}${g.rest ? " · self-care 🌸" : ""}`}
              done={!!app.builtinDone[g.id]} onPress={() => doBuiltin(g)} />
          );
        })}

        {customs.length > 0 && (
          <Text style={{ fontSize: 11, fontWeight: "800", letterSpacing: 1.1, color: t.inkSoft, marginTop: 6, marginBottom: 8 }}>YOUR ACTIVITIES</Text>
        )}
        {customs.map((a) => {
          const P = PILLARS[a.pillar] || PILLARS.mind;
          return (
            <Row key={a.id} t={t} icon={a.emoji || P.icon} tint={P.tint} title={a.title}
              subtitle={`${a.diff || "Easy"} · 🪙 ${a.coins || 5}`}
              done={!!app.customDone[a.id]} onPress={() => doCustom(a)} />
          );
        })}

        <Pressable onPress={() => navigation.navigate("Activities")}
          style={{ paddingVertical: 13, borderRadius: 16, borderWidth: 1.5, borderColor: t.accent + "66", borderStyle: "dashed", alignItems: "center", marginTop: 2 }}>
          <Text style={{ color: t.accent, fontWeight: "700", fontSize: 13.5 }}>+ Add your own activity</Text>
        </Pressable>

        <Pressable onPress={app.skipDay}
          style={{ paddingVertical: 13, borderRadius: 16, borderWidth: 1.5, borderColor: t.inkSoft + "55", borderStyle: "dashed", alignItems: "center", marginTop: 12 }}>
          <Text style={{ color: t.inkSoft, fontWeight: "700", fontSize: 13.5 }}>🌗 Try it: skip a day</Text>
        </Pressable>
        <Text style={{ textAlign: "center", color: t.inkSoft, opacity: 0.8, fontSize: 12, marginTop: 9, lineHeight: 18 }}>
          Watch the Resilience model: your streak rests instead of breaking, and {app.petName || "your pet"} gets sleepy — never punishing. Complete a goal to come back.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  fill: { flex: 1 },
  bar: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingTop: 6, paddingBottom: 8 },
  avatar: { width: 42, height: 42, borderRadius: 21, alignItems: "center", justifyContent: "center", borderWidth: 1 },
  chip: { paddingHorizontal: 11, paddingVertical: 7, borderRadius: 16 },
});
