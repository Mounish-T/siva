// App.js — providers, AdMob init, onboarding gate, and navigation.
import React, { useEffect } from "react";
import { View, ActivityIndicator } from "react-native";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { NavigationContainer, DefaultTheme, DarkTheme } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Text } from "react-native";

import { AppProvider, useApp } from "./src/store";
import { ThemeProvider, themeByKey } from "./src/theme";
import { initAds } from "./src/ads";

import { ChooseScreen, MeetScreen } from "./src/screens/OnboardingScreens";
import { HomeScreen } from "./src/screens/HomeScreen";
import { TrackerScreen } from "./src/screens/TrackerScreen";
import { ActivitiesScreen } from "./src/screens/ActivitiesScreen";
import { ProfileScreen } from "./src/screens/ProfileScreen";
import { PaywallScreen } from "./src/screens/PaywallScreen";

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function TabIcon({ emoji, color, focused }) {
  return <Text style={{ fontSize: 21, opacity: focused ? 1 : 0.55 }}>{emoji}</Text>;
}

function MainTabs() {
  const app = useApp();
  const t = themeByKey(app.themeKey);
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: t.accent,
        tabBarInactiveTintColor: t.inkSoft,
        tabBarStyle: { backgroundColor: t.cardSolid, borderTopColor: t.cardB, height: 60, paddingBottom: 8, paddingTop: 6 },
        tabBarLabelStyle: { fontSize: 10.5, fontWeight: "800" },
      }}
    >
      <Tab.Screen name="Home" component={HomeScreen} options={{ tabBarIcon: (p) => <TabIcon emoji="🏠" {...p} /> }} />
      <Tab.Screen name="Tracker" component={TrackerScreen} options={{ tabBarIcon: (p) => <TabIcon emoji="🏃" {...p} /> }} />
      <Tab.Screen name="Activities" component={ActivitiesScreen} options={{ tabBarIcon: (p) => <TabIcon emoji="✍️" {...p} /> }} />
      <Tab.Screen name="Profile" component={ProfileScreen} options={{ tabBarIcon: (p) => <TabIcon emoji="👤" {...p} /> }} />
    </Tab.Navigator>
  );
}

function Root() {
  const app = useApp();
  const t = themeByKey(app.themeKey);

  if (!app.hydrated) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: t.bg1 }}>
        <ActivityIndicator color={t.accent} size="large" />
      </View>
    );
  }

  // onboarding (no navigator needed)
  if (!app.pet) return <Onboard t={t}><ChooseScreen /></Onboard>;
  if (!app.petName) return <Onboard t={t}><MeetScreen /></Onboard>;

  const navTheme = {
    ...(t.dark ? DarkTheme : DefaultTheme),
    colors: {
      ...(t.dark ? DarkTheme : DefaultTheme).colors,
      background: t.bg1, card: t.cardSolid, text: t.ink, primary: t.accent, border: t.cardB, notification: t.accent,
    },
  };

  return (
    <Onboard t={t}>
      <NavigationContainer theme={navTheme}>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Tabs" component={MainTabs} />
          <Stack.Screen name="Paywall" component={PaywallScreen} options={{ presentation: "modal" }} />
        </Stack.Navigator>
      </NavigationContainer>
    </Onboard>
  );
}

// wraps children with the live theme context
function Onboard({ t, children }) {
  const { setThemeKey } = useApp();
  return (
    <ThemeProvider value={{ t, setThemeKey }}>
      <StatusBar style={t.dark ? "light" : "dark"} />
      {children}
    </ThemeProvider>
  );
}

export default function App() {
  useEffect(() => { initAds(); }, []);
  return (
    <SafeAreaProvider>
      <AppProvider>
        <Root />
      </AppProvider>
    </SafeAreaProvider>
  );
}
