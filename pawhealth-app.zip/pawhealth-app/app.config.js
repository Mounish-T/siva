// app.config.js — Expo configuration (Continuous Native Generation).
// Replace the placeholder AdMob App IDs and the android.package before you ship.

module.exports = {
  expo: {
    name: "PawHealth",
    slug: "pawhealth",
    version: "1.0.0",
    orientation: "portrait",
    scheme: "pawhealth",
    userInterfaceStyle: "automatic",
    newArchEnabled: true,
    icon: "./assets/icon.png",
    splash: {
      image: "./assets/splash.png",
      resizeMode: "contain",
      backgroundColor: "#FFEAF2",
    },
    assetBundlePatterns: ["**/*"],

    android: {
      package: "com.yourcompany.pawhealth", // <-- CHANGE to your unique package name
      versionCode: 1,
      adaptiveIcon: {
        foregroundImage: "./assets/adaptive-icon.png",
        backgroundColor: "#FFEAF2",
      },
      permissions: [
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.ACCESS_COARSE_LOCATION",
        "android.permission.ACTIVITY_RECOGNITION", // step counter
        "com.google.android.gms.permission.AD_ID",  // AdMob advertising id
      ],
    },

    ios: {
      bundleIdentifier: "com.yourcompany.pawhealth",
      supportsTablet: true,
      infoPlist: {
        NSLocationWhenInUseUsageDescription: "PawHealth uses your location to measure distance and speed while you walk, run, or cycle.",
        NSMotionUsageDescription: "PawHealth uses motion data to count your steps during a session.",
      },
    },

    plugins: [
      [
        "react-native-google-mobile-ads",
        {
          // From AdMob > App settings > App ID  (format: ca-app-pub-XXXXXXXX~XXXXXXXX)
          androidAppId: "ca-app-pub-3940256099942544~3347511713", // <-- TEST id; replace with yours
          iosAppId: "ca-app-pub-3940256099942544~1458002511",      // <-- TEST id; replace with yours
        },
      ],
      [
        "expo-location",
        { locationWhenInUsePermission: "PawHealth uses your location to measure distance and speed during a workout." },
      ],
      [
        "expo-sensors",
        { motionPermission: "PawHealth uses motion data to count your steps." },
      ],
      [
        "expo-build-properties",
        { ios: { useFrameworks: "static" } }, // required by the Google Mobile Ads SDK on iOS
      ],
    ],

    extra: {
      eas: { projectId: "" }, // filled automatically by `eas init`
    },
  },
};
