import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';

import '../models/track.dart';
import 'local_cache.dart';

enum DownloadStatus { queued, downloading, completed, failed, canceled }

class DownloadEntry {
  DownloadEntry({
    required this.track,
    required this.status,
    this.progress = 0,
    this.localPath,
    this.error,
  });

  final Track track;
  DownloadStatus status;
  double progress; // 0.0–1.0
  String? localPath;
  String? error;

  Map<String, dynamic> toJson() => {
        'track': {
          'id': track.id,
          'title': track.title,
          'artist': track.artist,
          'album': track.album,
          'audioUrl': track.audioUrl,
          'imageUrl': track.imageUrl,
          'durationSeconds': track.durationSeconds,
        },
        'status': status.name,
        'localPath': localPath,
      };

  factory DownloadEntry.fromJson(Map<String, dynamic> json) {
    final t = json['track'] as Map<String, dynamic>;
    return DownloadEntry(
      track: Track(
        id: t['id'] as String? ?? '',
        title: t['title'] as String? ?? '',
        artist: t['artist'] as String? ?? '',
        album: t['album'] as String?,
        audioUrl: t['audioUrl'] as String? ?? '',
        imageUrl: t['imageUrl'] as String? ?? '',
        durationSeconds: (t['durationSeconds'] as num?)?.toInt() ?? 0,
      ),
      status: DownloadStatus.values.firstWhere(
        (s) => s.name == (json['status'] as String?),
        orElse: () => DownloadStatus.completed,
      ),
      localPath: json['localPath'] as String?,
      progress: json['localPath'] != null ? 1.0 : 0.0,
    );
  }
}

/// Manages local downloads. Each track is downloaded to:
///   <app docs>/downloads/<trackId>.mp3
///
/// Persistence: completed downloads are recorded in SharedPreferences. The
/// in-flight ones live only in memory — if the app is killed mid-download
/// the partial file is cleaned up on next launch.
class DownloadService {
  DownloadService._() {
    _init();
  }
  static final DownloadService instance = DownloadService._();

  final Dio _dio = Dio();
  final Map<String, DownloadEntry> _entries = {};
  final Map<String, CancelToken> _cancelTokens = {};
  final StreamController<List<DownloadEntry>> _controller =
      StreamController.broadcast();

  bool _initialized = false;
  late final Directory _downloadsDir;

  Stream<List<DownloadEntry>> get stream => _controller.stream;
  List<DownloadEntry> get all => _entries.values.toList()
    ..sort((a, b) => a.track.title.compareTo(b.track.title));

  Future<void> _init() async {
    if (_initialized) return;
    final docs = await getApplicationDocumentsDirectory();
    _downloadsDir = Directory('${docs.path}/downloads');
    if (!await _downloadsDir.exists()) {
      await _downloadsDir.create(recursive: true);
    }
    await _hydrate();
    _initialized = true;
  }

  Future<void> _hydrate() async {
    final prefs = await LocalCache.instance.rawPrefs();
    final raw = prefs.getString(LocalCache.kDownloads);
    if (raw == null || raw.isEmpty) {
      _emit();
      return;
    }
    try {
      final list = jsonDecode(raw) as List;
      for (final item in list) {
        if (item is! Map<String, dynamic>) continue;
        final entry = DownloadEntry.fromJson(item);
        // Sanity check: file must still exist on disk.
        if (entry.localPath != null &&
            await File(entry.localPath!).exists()) {
          _entries[entry.track.id] = entry;
        }
      }
    } catch (_) {
      // Ignore corrupted state.
    }
    _emit();
  }

  void _emit() => _controller.add(all);

  Future<void> _persist() async {
    final prefs = await LocalCache.instance.rawPrefs();
    final completed = _entries.values
        .where((e) => e.status == DownloadStatus.completed)
        .map((e) => e.toJson())
        .toList();
    await prefs.setString(LocalCache.kDownloads, jsonEncode(completed));
  }

  bool isDownloaded(String trackId) {
    final e = _entries[trackId];
    return e != null && e.status == DownloadStatus.completed;
  }

  String? localPathFor(String trackId) {
    final e = _entries[trackId];
    if (e == null || e.status != DownloadStatus.completed) return null;
    return e.localPath;
  }

  Future<void> enqueue(Track track) async {
    await _init();
    if (_entries.containsKey(track.id)) return;
    if (track.audioUrl.isEmpty) return;

    final entry = DownloadEntry(track: track, status: DownloadStatus.queued);
    _entries[track.id] = entry;
    _emit();
    _start(entry);
  }

  Future<void> _start(DownloadEntry entry) async {
    final destination = '${_downloadsDir.path}/${entry.track.id}.mp3';
    final cancelToken = CancelToken();
    _cancelTokens[entry.track.id] = cancelToken;

    entry.status = DownloadStatus.downloading;
    _emit();

    try {
      await _dio.download(
        entry.track.audioUrl,
        destination,
        cancelToken: cancelToken,
        onReceiveProgress: (received, total) {
          if (total > 0) {
            entry.progress = received / total;
            _emit();
          }
        },
      );
      entry.status = DownloadStatus.completed;
      entry.localPath = destination;
      entry.progress = 1.0;
      _cancelTokens.remove(entry.track.id);
      await _persist();
      _emit();
    } catch (e) {
      if (cancelToken.isCancelled) {
        entry.status = DownloadStatus.canceled;
        // Clean up partial.
        final f = File(destination);
        if (await f.exists()) await f.delete();
        _entries.remove(entry.track.id);
      } else {
        entry.status = DownloadStatus.failed;
        entry.error = e.toString();
      }
      _cancelTokens.remove(entry.track.id);
      _emit();
    }
  }

  Future<void> cancel(String trackId) async {
    _cancelTokens[trackId]?.cancel();
  }

  Future<void> remove(String trackId) async {
    final entry = _entries[trackId];
    if (entry?.localPath != null) {
      final f = File(entry!.localPath!);
      if (await f.exists()) {
        try {
          await f.delete();
        } catch (_) {}
      }
    }
    _entries.remove(trackId);
    await _persist();
    _emit();
  }

  Future<void> retry(String trackId) async {
    final entry = _entries[trackId];
    if (entry == null) return;
    entry.progress = 0;
    entry.error = null;
    entry.status = DownloadStatus.queued;
    _emit();
    _start(entry);
  }
}
