/**
 * Pulse Music — Jamendo cache proxy
 *
 * Deploys to Cloudflare Workers (free tier: 100k requests/day).
 *
 * Purpose:
 *   1. Cache responses for 15 minutes — protects against Jamendo rate limits
 *      when many users hit the same endpoints (trending/latest).
 *   2. Hides JAMENDO_CLIENT_ID from the client (set as a Worker env secret).
 *   3. Keeps the app responsive even during brief Jamendo outages.
 *
 * Deploy:
 *   1. Install wrangler: npm i -g wrangler
 *   2. wrangler login
 *   3. wrangler deploy
 *   4. wrangler secret put JAMENDO_CLIENT_ID
 *   5. Point your Flutter app at the Worker URL by changing AppConfig.jamendoBaseUrl
 *      to https://pulse-jamendo-cache.<your-account>.workers.dev/v3.0
 *      (or just leave the original URL if you don't want caching).
 *
 * Routes:
 *   /v3.0/tracks/?...      → cached, 15min
 *   /v3.0/albums/?...      → cached, 1h (album metadata barely changes)
 *   /v3.0/artists/?...     → cached, 1h
 *
 * If JAMENDO_CLIENT_ID isn't injected by this Worker, the original client_id
 * from the request is preserved — meaning you can use the Worker even
 * without setting up the secret.
 */

const JAMENDO_ORIGIN = 'https://api.jamendo.com';

const CACHE_TTLS = {
  '/v3.0/tracks/': 60 * 15, // 15 minutes
  '/v3.0/albums/': 60 * 60, // 1 hour
  '/v3.0/artists/': 60 * 60, // 1 hour
};

function pickTtl(pathname) {
  for (const [prefix, ttl] of Object.entries(CACHE_TTLS)) {
    if (pathname.startsWith(prefix)) return ttl;
  }
  return 60 * 5;
}

export default {
  async fetch(request, env, ctx) {
    if (request.method !== 'GET') {
      return new Response('Only GET supported', { status: 405 });
    }

    const url = new URL(request.url);

    // Inject client_id from secret if available.
    if (env.JAMENDO_CLIENT_ID && !url.searchParams.has('client_id')) {
      url.searchParams.set('client_id', env.JAMENDO_CLIENT_ID);
    }

    const upstreamUrl = JAMENDO_ORIGIN + url.pathname + url.search;
    const cacheKey = new Request(upstreamUrl, { method: 'GET' });
    const cache = caches.default;

    // 1) Try cache first.
    let response = await cache.match(cacheKey);
    if (response) {
      // Clone so we can mutate headers.
      response = new Response(response.body, response);
      response.headers.set('X-Cache', 'HIT');
      return response;
    }

    // 2) Miss — fetch upstream.
    try {
      const upstream = await fetch(upstreamUrl, {
        headers: { Accept: 'application/json' },
      });

      if (!upstream.ok) {
        return new Response(
          JSON.stringify({
            results: [],
            error: `Upstream ${upstream.status}`,
          }),
          {
            status: 200, // Surface as empty result, not a hard error.
            headers: { 'content-type': 'application/json' },
          }
        );
      }

      const body = await upstream.text();
      const ttl = pickTtl(url.pathname);

      response = new Response(body, {
        status: 200,
        headers: {
          'content-type': 'application/json',
          'cache-control': `public, max-age=${ttl}`,
          'X-Cache': 'MISS',
          'Access-Control-Allow-Origin': '*',
        },
      });

      // Persist to edge cache.
      ctx.waitUntil(cache.put(cacheKey, response.clone()));
      return response;
    } catch (e) {
      return new Response(
        JSON.stringify({ results: [], error: e.message }),
        {
          status: 200,
          headers: { 'content-type': 'application/json' },
        }
      );
    }
  },
};
