# Pulse Music — diagnostics mode

The app has two build modes. They produce different APKs from the same source code, controlled by one compile-time flag.

## Normal mode

```bash
flutter build apk --release \
  --dart-define=JAMENDO_CLIENT_ID=xxx \
  --dart-define=SUPABASE_URL=https://yourproject.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=xxx
```

This is the regular APK. What you get:
- Standard features (music streaming, playlists, downloads, etc.)
- **Zero logging overhead** — `DiagnosticsService.log()` calls become no-ops at runtime
- **No Diagnostics screen** — the entry under Settings doesn't appear
- Smaller mental footprint for end users

Use this for daily use and for sharing with others.

## Diagnostics mode

```bash
flutter build apk --release \
  --dart-define=JAMENDO_CLIENT_ID=xxx \
  --dart-define=SUPABASE_URL=https://yourproject.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=xxx \
  --dart-define=PULSE_DIAGNOSTICS=true
```

Same code, but with the diagnostics flag flipped. What you get extra:
- Verbose logging captured in a 500-entry ring buffer
- A **Settings → Developer → Diagnostics** entry
- Two-tab UI inside Diagnostics:
  - **Self-check** — runs 7 real probes (config, network, Jamendo, Supabase, auth session, audio player, downloads dir) and reports pass/fail with specific errors
  - **Logs** — live scrolling view of every event, with copy-to-clipboard and clear buttons

Use this the first time you build the project, to confirm everything is wired up correctly. Once you confirm, rebuild without the flag.

## What gets logged in diagnostics mode

| Service | What's logged |
|---|---|
| Startup | Diagnostics flag, JustAudioBackground init, Supabase init, onboarding flag |
| Jamendo API | Every GET with params (client_id redacted), response track count, request duration in ms, errors |
| Player | setQueue calls, track changes (now playing), state transitions (loading→ready→completed etc., deduplicated) |
| Downloads | Enqueue, completion (with duration in ms), cancel, failure with error message |
| Auth | Sign up attempt + result, sign in attempt + result, failures with error |
| Self-check | Each probe's pass/fail/skip with details |

Position ticks, progress percentages, and other high-frequency events are **not** logged (would flood the buffer).

## What the self-check probes

1. **App configuration** — verifies `JAMENDO_CLIENT_ID` is set; reports optional services (Supabase, Google Sign-In) as info
2. **Network reachable** — DNS lookup of `jamendo.com` with 5-second timeout
3. **Jamendo API** — actual HTTP GET to `/tracks/?limit=1`, expects `status: success`
4. **Supabase backend** — hits `/auth/v1/health` with the anon key (skipped if Supabase isn't configured)
5. **Authenticated session** — reports who's signed in (skipped if signed out)
6. **Audio player** — verifies the player singleton initialized; reports current queue size and track
7. **Downloads directory writable** — creates and deletes a probe file in the app's downloads dir

Each check runs independently. A failure in one doesn't block the others.

## Reading the logs

Each log line looks like:
```
[18:32:47.234] [INFO] [Jamendo] GET /tracks/ → 20 tracks in 287ms
```

- **Timestamp** — local time with millisecond precision
- **Level** — DEBUG / INFO / WARN / ERROR (color-coded in the UI)
- **Tag** — which service emitted it (Jamendo, Player, Auth, Downloads, Startup, SelfCheck)
- **Message** — what happened

Sensitive data (client IDs, tokens, passwords) is never logged.

## Performance impact

When diagnostics is **off**: zero. Every `log()` call short-circuits on the first line.

When diagnostics is **on**: negligible. The ring buffer is bounded; the stream is broadcast (no buffering); `debugPrint` is asynchronous. You're looking at maybe 1-2% overhead during heavy activity. Not noticeable in normal use.

## How to use this in practice

**First-time setup:**
1. Get all your API keys ready
2. Build in diagnostics mode
3. Install on a device
4. Open the app, swipe through onboarding, log in (or skip)
5. Go to Settings → Developer → Diagnostics → Self-check tab
6. Tap "Run self-check"
7. **Everything should be green ✅** (or skipped ⏭ for optional services)
8. If anything is red ❌, fix the underlying issue, rebuild, repeat
9. Once all green, rebuild in normal mode and you're done

**Debugging a specific issue:**
1. Build in diagnostics mode
2. Reproduce the issue in the app
3. Go to Diagnostics → Logs tab
4. Tap the copy icon — full log is on your clipboard
5. Paste somewhere readable, find the ERROR or WARN entries
6. Each error has the failing service and message — usually points directly at the cause

**Sharing logs with someone for help:**
The copy-to-clipboard captures the full ring buffer. Paste into a chat/issue/email. Logs contain no secrets — client IDs are redacted, passwords are never logged.
