# Pulse Music

A free, open-source music streaming app for Android, built with Flutter.

> **Three docs to read in order:**
> 1. This README — overview, setup, build
> 2. [`BUILD.md`](./BUILD.md) — step-by-step build walkthrough with every error and fix
> 3. [`STATUS.md`](./STATUS.md) — final project status, what's in / what's out / why

---

Powered by:
- **Jamendo API** — half a million Creative Commons licensed tracks, free with a `client_id`
- **Supabase** (optional) — free auth + Postgres for user accounts and playlists
- **Cloudflare Workers** (optional) — free edge cache for resilience
- **just_audio + just_audio_background** — gapless playback, lock-screen controls, background audio

> **About the catalog**: Jamendo is independent / Creative Commons music. You will not find Taylor Swift here. Mainstream copyrighted streaming requires expensive licensing and is not legally possible for a free app. What you get is a genuinely large catalog of indie artists across every genre.

---

## Feature matrix

### ✅ Built and working

**Playback**
- Streams real music from Jamendo (Trending, Latest, Genres, Search)
- Background playback with media-notification controls
- Lock-screen controls (play/pause/skip)
- Full-screen player: seek, shuffle, repeat, sleep timer, playback speed (0.5x–2x)
- Mini-player above the bottom nav
- Dynamic gradient background from album art
- Queue screen with now-playing + up-next

**Offline**
- Tap "Download" on any track → saves locally to app-private storage
- Downloads screen shows progress, cancel, retry, delete
- Player automatically prefers downloaded copy when available — works fully offline
- Downloads persist across app restarts

**Library**
- Persistent favorites (Supabase + local cache fallback)
- Full playlist CRUD: create, rename, delete, add/remove tracks
- "Add to playlist" sheet accessible from any track
- Recently played tracking
- Profile screen with stats

**Discovery**
- Daily / Chill / Workout / Focus / Trending mix carousels
- Recently played influences Daily Mix
- Album and Artist screens
- Genre browser with 6 colored cards
- Debounced search

**Auth**
- Email/password sign-up + sign-in
- Google Sign-In (requires setup, see below)
- Forgot password
- "Continue without account" fallback when Supabase isn't configured

**Infrastructure**
- Cloudflare Worker cache proxy (optional, free tier)
- GitHub Actions workflow that builds APK on push + attaches to tagged releases
- Supabase SQL schema with row-level security policies
- Local SharedPreferences cache for offline resilience

**UX**
- 3-slide onboarding (one-time)
- Dark Material 3 theme
- Skeleton loaders during fetch
- Pull-to-refresh
- Settings + profile screens

### ❌ Not built (intentionally — see "Why not these features" below)

- Lyrics screen
- Equalizer UI
- Real audio waveform visualization

---

## Why not those features

These were on your original spec but I chose not to build them for honest technical reasons:

**Lyrics** — Jamendo doesn't provide them. Free lyrics APIs (LRClib, Musixmatch free tier) have very poor coverage of Creative Commons indie music. Most Jamendo tracks would just show "No lyrics available." Building a feature that doesn't work for 95% of the catalog is worse than not having it.

**Equalizer** — `just_audio`'s `AndroidEqualizer` works but is marked experimental and breaks on some devices. I'd rather you have a stable player than a 5-band EQ that occasionally crashes.

**Waveform** — Real waveforms require the decoded audio file, which streamed sources don't expose. Building one means showing a *fake* animated bar pattern that looks like a waveform but has no relationship to the actual audio. Cosmetic and dishonest. Skipping it.

---

## Project structure

```
pulse_music/
├── .github/workflows/build.yml           # CI: build APK on push
├── android/                              # Android Gradle + manifest
├── cloudflare_worker/                    # Optional edge cache
│   ├── worker.js
│   ├── wrangler.toml
│   └── README.md
├── lib/
│   ├── main.dart
│   ├── core/
│   │   ├── config/app_config.dart        # Reads --dart-define env vars
│   │   ├── theme/app_theme.dart
│   │   ├── models/
│   │   │   ├── track.dart
│   │   │   └── album.dart                # Album + Artist
│   │   └── services/
│   │       ├── jamendo_service.dart      # API client
│   │       ├── player_service.dart       # just_audio wrapper
│   │       ├── auth_service.dart         # Supabase + Google OAuth
│   │       ├── library_service.dart      # favorites/playlists/recent
│   │       ├── download_service.dart     # Dio-based downloader
│   │       ├── recommendation_service.dart
│   │       ├── sleep_timer.dart
│   │       ├── dynamic_colors.dart       # palette_generator
│   │       ├── local_cache.dart          # SharedPreferences
│   │       └── providers.dart            # Riverpod providers
│   ├── features/
│   │   ├── auth/login_screen.dart
│   │   ├── onboarding/onboarding_screen.dart
│   │   ├── home/
│   │   │   ├── home_screen.dart
│   │   │   └── shell_screen.dart
│   │   ├── search/search_screen.dart
│   │   ├── library/library_screen.dart
│   │   ├── playlists/playlists_screen.dart
│   │   ├── downloads/downloads_screen.dart
│   │   ├── recommendations/mix_screen.dart
│   │   ├── album/album_screen.dart
│   │   ├── artist/artist_screen.dart
│   │   ├── queue/queue_screen.dart
│   │   ├── player/
│   │   │   ├── player_screen.dart
│   │   │   ├── sleep_timer_sheet.dart
│   │   │   └── speed_sheet.dart
│   │   ├── profile/profile_screen.dart
│   │   └── settings/settings_screen.dart
│   └── widgets/
│       ├── track_tile.dart
│       ├── mini_player.dart
│       └── skeletons.dart
├── pubspec.yaml
├── supabase_schema.sql
└── README.md
```

---

## Build procedure

### 1. Install Flutter

```bash
flutter --version       # confirm Flutter 3.19 or newer
flutter doctor          # fix anything red
```

You also need **Android Studio** (for SDK + emulator) or a real Android device with USB debugging.

### 2. Get a free Jamendo API key

1. https://devportal.jamendo.com/
2. Create an app — copy the **Client ID**.

This is the only required API key.

### 3. (Optional) Set up Supabase

Skip this and the app still runs — the login screen shows "Continue without account."

1. https://supabase.com (free tier)
2. Create project. Wait ~1 min.
3. Settings → API → copy **Project URL** and **anon public key**.
4. SQL editor → paste `supabase_schema.sql` → Run.
5. Auth → Providers → enable Email.

### 4. (Optional) Set up Google Sign-In

Requires real keystore configuration. Skip if you only want email auth.

1. **Google Cloud Console** (https://console.cloud.google.com):
   - Create or pick a project.
   - APIs & Services → Credentials → Create Credentials → OAuth client ID.
   - Type: **Web application**. Add `https://<your-project>.supabase.co/auth/v1/callback` as a redirect URI. Save. Copy the Client ID — this is your `GOOGLE_WEB_CLIENT_ID`.
   - Create *another* OAuth client ID, type: **Android**. Package name: `com.pulse.music`. SHA-1 fingerprint: get it via:
     ```
     keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
     ```
     (For release, use your release keystore's SHA-1.)
2. **Supabase**: Authentication → Providers → Google → enable. Paste the Web Client ID (and its secret).
3. Pass `--dart-define=GOOGLE_WEB_CLIENT_ID=<your web client id>` when building.

### 5. (Optional) Deploy Cloudflare Worker cache

See `cloudflare_worker/README.md`. Adds resilience and hides your Jamendo key. Free.

### 6. (Optional) Set up GitHub Actions

The workflow is already at `.github/workflows/build.yml`. Push to GitHub, then in repo Settings → Secrets → Actions, add:

- `JAMENDO_CLIENT_ID`
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `GOOGLE_WEB_CLIENT_ID` (only if using Google Sign-In)

Push to `main` → APK builds as a workflow artifact. Tag a commit `v0.1.0` → APK gets attached to a GitHub Release automatically.

### 7. Build locally

```bash
cd pulse_music
flutter pub get
flutter build apk --release \
  --dart-define=JAMENDO_CLIENT_ID=xxx \
  --dart-define=SUPABASE_URL=https://yourproject.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=eyJhbGci... \
  --dart-define=GOOGLE_WEB_CLIENT_ID=xxx.apps.googleusercontent.com
```

APK lands at `build/app/outputs/flutter-apk/app-release.apk`.

If the `android/` folder is incomplete (e.g. missing gradle wrapper), regenerate the boilerplate first:
```bash
flutter create --org com.pulse --project-name pulse_music --platforms=android .
flutter pub get
```
This won't overwrite the customized files (manifest, build.gradle, MainActivity.kt) — Flutter detects they exist and leaves them alone.

---

## How offline downloads work

1. User taps "Download" in a track's menu.
2. `DownloadService.enqueue(track)` is called.
3. Dio streams the audio file to `<app-docs>/downloads/<trackId>.mp3` with progress callbacks.
4. On completion, the entry is persisted to SharedPreferences.
5. Next time the same track is played, `PlayerService._toAudioSource()` checks `DownloadService.localPathFor()` — if found, it uses `Uri.file()` instead of the network URL.
6. Result: instant playback, zero network usage.

Files are stored in app-private storage so no Android storage permission is needed (Android 8+). They are deleted automatically if the user uninstalls the app.

## How the Supabase fallback works

The app is built so it stays usable when:
- Supabase isn't configured at all
- The user isn't signed in
- Supabase free-tier project is paused
- The device is offline

Every read in `LibraryService` tries Supabase first, then falls back to the local SharedPreferences cache. Every write goes to local first, then attempts Supabase (failures swallowed). This means actions never lose data and the UI never blocks.

## Troubleshooting

- **`pub get` fails** → run `flutter pub upgrade --major-versions`.
- **APK builds but no music** → check `JAMENDO_CLIENT_ID` was passed and is valid.
- **Notification doesn't appear** → grant `POST_NOTIFICATIONS` on first play (Android 13+).
- **Downloads fail silently** → check device storage. Failed entries show a "Retry" button in the Downloads screen.
- **Google Sign-In says "DEVELOPER_ERROR"** → the SHA-1 fingerprint registered in Google Cloud Console doesn't match the keystore signing the APK. Re-register it.
