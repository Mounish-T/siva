# BedTime — Sleep Cycle Calculator

A complete, production-ready Android app (Kotlin + Jetpack Compose). It calculates the best times to fall asleep or wake up based on 90-minute sleep cycles, with a free tier supported by AdMob banner ads and a one-time **Premium** in-app purchase that removes ads and unlocks extra features.

This document is your full, start-to-finish guide: open the project, make it yours, set up monetization so **purchases are paid to you**, and publish to Google Play.

---

## 1. What's inside

```
BedTime/
├─ app/                       ← the Android app module
│  ├─ src/main/java/...       ← all Kotlin source (UI, billing, logic)
│  ├─ src/main/res/           ← icons, themes, colors
│  └─ build.gradle.kts        ← app dependencies & build config
├─ store_assets/              ← ready-to-use Play Store graphics
│  ├─ play_store_icon_512.png ← 512×512 app icon for the listing
│  └─ feature_graphic_1024x500.png
├─ build.gradle.kts           ← project-level Gradle
├─ settings.gradle.kts
├─ gradle/ , gradlew , gradlew.bat
├─ README.md                  ← you are here
├─ PRIVACY_POLICY.md          ← privacy policy template (you must host this)
└─ PLAY_STORE_LISTING.md      ← copy-paste text for your store listing
```

**Features**
- Three modes: *Wake up at…*, *Sleep now*, *Go to bed at…*
- Animated night-sky UI (twinkling stars + glowing crescent moon)
- One-tap **Set alarm** that hands the time to the phone's clock app
- Free tier with an AdMob **banner** ad
- **Premium** (one-time purchase) that:
  - removes all ads,
  - unlocks 4 extra themes (Aurora, Sunset, Deep Space, Rose Dawn),
  - allows a custom sleep-cycle length,
  - allows fine-tuning of fall-asleep time.

**Tech:** Kotlin 2.0, Jetpack Compose (Material 3), Navigation Compose, DataStore, Google Play Billing 7, Google Mobile Ads (AdMob), min SDK 24, target SDK 35.

---

## 2. Prerequisites

1. **Android Studio** — latest stable (Ladybug 2024.2 or newer recommended). Download: https://developer.android.com/studio
2. **JDK 17** — Android Studio bundles a compatible JDK, so you normally don't need a separate install.
3. A **Google Play Console** account (one-time US$25 registration) — https://play.google.com/console
4. A **Google AdMob** account (free) — https://admob.google.com

> **Note about `gradle-wrapper.jar`:** this project ships without the small Gradle wrapper binary. You don't need to do anything — when you open the project, Android Studio creates it automatically during the first Gradle sync. (If you ever build purely from the command line first, run `gradle wrapper` once in the project folder.)

---

## 3. Open and run the app

1. Open Android Studio → **File ▸ Open** → select the `BedTime` folder.
2. Wait for **Gradle sync** to finish (it downloads dependencies on first run — needs internet).
3. Plug in a device (with USB debugging) or start an emulator.
4. Press **Run ▶**. The app builds and launches.

Out of the box it uses **Google's official AdMob *test* IDs** and works against Play Billing only once the app is uploaded to a test track (see §6). You can develop and click around immediately.

---

## 4. Make it yours (optional but recommended)

**App name** — `app/src/main/res/values/strings.xml` → change `app_name`.

**Package / application ID** — currently `com.bedtime.sleepcalculator`. If you want your own:
- In Android Studio, use the Project view, right-click the package → **Refactor ▸ Rename**, and also change `applicationId` and `namespace` in `app/build.gradle.kts`. Pick something unique like `com.yourname.bedtime`. **This is the permanent identity of your app on Play — choose before publishing.**

**Colors / themes** — `app/src/main/java/com/bedtime/sleepcalculator/ui/theme/AppTheme.kt`.

**App icon** — the launcher icon lives in `res/mipmap-*` (legacy PNGs) and `res/mipmap-anydpi-v26` + `res/drawable/ic_launcher_*` (adaptive). To regenerate from your own art, use Android Studio's **Image Asset** tool (right-click `res` ▸ New ▸ Image Asset).

---

## 5. AdMob setup (so you earn ad revenue)

The project includes Google **test** ad IDs. You must replace them with your own before release, or you risk policy violations and won't get paid.

1. Create/sign in at https://admob.google.com and **add your app**.
2. Copy your **App ID** (looks like `ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY`).
   - Paste it into `app/src/main/AndroidManifest.xml`, replacing the value of
     `com.google.android.gms.ads.APPLICATION_ID`.
3. In AdMob, create a **Banner** ad unit. Copy its **Ad unit ID**
   (`ca-app-pub-XXXX/ZZZZZZ`).
   - Paste it into `app/src/main/java/com/bedtime/sleepcalculator/ui/components/AdIds.kt`
     replacing `BANNER`.
4. Add your bank/tax details in AdMob → **Payments**, so Google can pay you.

> Keep the **test** IDs while developing. Only switch to real IDs for your release build, and never click your own live ads.

---

## 6. In-app purchase setup — **getting paid for Premium**

This is how Premium money reaches **your** bank account. The app already contains all the billing code; you only configure the product in the Play Console.

**A. Set up your payments (merchant) profile**
1. In **Play Console**, go to **Setup ▸ Payments profile** (or **Settings ▸ Payments profile**).
2. Create your payments profile and add your **bank account** and **tax info**. Google collects each purchase and pays out to this account.

**B. Create the Premium product**
1. First upload at least one build to a testing track (see §9) so the app exists in the console.
2. Go to **Monetize ▸ Products ▸ In-app products** → **Create product**.
3. Set the **Product ID** to exactly:

   ```
   premium_unlock
   ```

   ⚠️ It must match this string — the app looks for `premium_unlock`. (If you want a different ID, change `PREMIUM_PRODUCT_ID` in `billing/BillingManager.kt`.)
4. Give it a name (e.g. "BedTime Premium"), a description, and a **price**.
5. **Activate** the product and save.

**C. Test the purchase safely (no real charge)**
1. In **Play Console ▸ Setup ▸ License testing**, add your Google account email as a license tester.
2. Install the app from the **Internal testing** track on a device signed in with that account.
3. Buy Premium — testers see "Test card, always approves" and are **not** charged. Confirm ads disappear and themes unlock.

Once live, every real purchase is processed by Google Play and paid to your payments profile (minus Google's standard fee).

---

## 7. Create your signing key (required to publish)

Play requires a signed **release** build. Easiest path:

1. In Android Studio: **Build ▸ Generate Signed App Bundle / APK…**
2. Choose **Android App Bundle**, click **Create new…** for the keystore.
3. Pick a safe location and strong passwords. Fill in the certificate fields.
4. **Back up this keystore and its passwords somewhere safe.** If you lose it you cannot update your app. (You can opt in to Google Play App Signing as a safety net, recommended.)

---

## 8. Build the release bundle (AAB)

Using the wizard from §7, finish the steps and choose the **release** build variant. Android Studio produces an `.aab` file at:

```
app/release/app-release.aab
```

This `.aab` is what you upload to Google Play.

> Command-line alternative (after the wrapper exists and signing is configured): `./gradlew bundleRelease`.

---

## 9. Publish on Google Play

1. In **Play Console**, **Create app** → set name, default language, type **App**, **Free**.
2. **Store listing** — use `PLAY_STORE_LISTING.md` for the title, descriptions, and required graphics. Upload:
   - **App icon**: `store_assets/play_store_icon_512.png`
   - **Feature graphic**: `store_assets/feature_graphic_1024x500.png`
   - **Phone screenshots**: take 2–8 on a device/emulator (see tips below).
3. **Content rating** — complete the questionnaire (this app is suitable for **Everyone**).
4. **Data safety** — declare that the app uses an **advertising ID** (via AdMob) and stores preferences on-device. It collects no personal data and requires no account.
5. **Privacy policy** — host `PRIVACY_POLICY.md` as a public web page (GitHub Pages, Google Sites, your site) and paste the URL into the listing. *A privacy policy URL is mandatory because the app shows ads.*
6. **Release ▸ Testing ▸ Internal testing** — upload your `.aab`, add testers, and verify everything (especially the Premium purchase) on a real device.
7. When happy: **Release ▸ Production ▸ Create release**, upload the `.aab` (or promote the tested build), complete the rollout, and submit for review.

Google review typically takes from a few hours to a few days for a first submission.

### Taking screenshots
Run the app on an emulator, open each screen (Home, a Results screen, Premium, Settings), and use the emulator's camera button or `Ctrl/Cmd+S`. Play needs phone screenshots between 320 px and 3840 px on each side. 4–6 attractive screenshots convert best.

---

## 10. After launch — growing downloads (ASO)

- Put your strongest keyword in the title: e.g. **"BedTime — Sleep Cycle Calculator"**.
- Front-load the short description with the benefit ("Wake up refreshed…").
- Reply to reviews; ratings drive ranking.
- Ship small updates (bump `versionCode`/`versionName` in `app/build.gradle.kts`) — active apps rank better.
- Consider seasonal screenshots and a short promo video later.

---

## 11. Troubleshooting

| Symptom | Fix |
|---|---|
| Gradle sync fails on first open | Ensure internet access; let it finish downloading. **File ▸ Invalidate Caches / Restart** if stuck. |
| "SDK location not found" | Android Studio ▸ **Tools ▸ SDK Manager**; install an SDK; it writes `local.properties` automatically. |
| App shows test ads, not yours | You're still on the test IDs — complete §5 with your own IDs and rebuild release. |
| Premium button says "Store not ready" | The product isn't active yet, or you're not testing via a Play track. Complete §6 and install from Internal testing. |
| Purchase doesn't unlock | Use a **license-tester** account, installed from the Play track (not a direct `Run`), and the product ID must be `premium_unlock`. |
| Real users can't see ads | Banner needs network; with no fill AdMob may show nothing — normal for brand-new accounts; fill improves over days. |
| Can't update app later | You must sign with the **same keystore** from §7 — keep it safe. |

---

## 12. Quick checklist before you hit publish

- [ ] Unique `applicationId` chosen (if changing from default)
- [ ] Real AdMob **App ID** in `AndroidManifest.xml`
- [ ] Real AdMob **banner unit** in `AdIds.kt`
- [ ] Payments profile set up (bank + tax)
- [ ] `premium_unlock` product created, priced, **activated**
- [ ] Premium purchase tested with a license tester (ads vanish, themes unlock)
- [ ] Release **AAB** built and signed; keystore backed up
- [ ] Store listing text + 512 icon + feature graphic + screenshots uploaded
- [ ] Privacy policy hosted and URL added
- [ ] Content rating + Data safety completed

That's everything. Build it, test the purchase once, and ship. Good luck! 🌙
