# Privacy Policy for BedTime — Sleep Cycle Calculator

_Last updated: [INSERT DATE]_

This Privacy Policy explains how the **BedTime — Sleep Cycle Calculator** app ("the App", "we", "us") handles information. By using the App you agree to this policy.

> **How to use this template:** replace the bracketed placeholders ([INSERT …]), publish the page at a public URL (e.g. GitHub Pages, Google Sites, or your own website), and paste that URL into your Google Play Store listing. A privacy policy URL is required because the App displays ads.

## Summary

- We do **not** collect personal information.
- We do **not** require an account or sign-in.
- Your settings (theme, fall-asleep time, cycle length, premium status) are stored **only on your device**.
- The free version shows ads via Google AdMob, which may use an advertising identifier.
- Purchasing Premium removes ads.

## Information we collect

**Information you provide:** none. The App has no sign-up, login, or forms.

**Information stored on your device:** your in-app preferences and your premium-unlock status are saved locally using Android's on-device storage. This data stays on your device and is not transmitted to us.

**Information collected automatically (ads):** in the free version, we use **Google AdMob** to display advertising. Google and its partners may collect and process certain data — including a device **advertising identifier**, approximate (non-precise) location derived from IP, and ad-interaction data — to deliver and measure ads. This processing is governed by Google's policies.

## Advertising and Premium

The free version is supported by banner ads served by Google AdMob. Ad personalization and the use of advertising identifiers are controlled by your device settings and Google's services. If you purchase **Premium**, ads are removed from the App.

You can reset or limit your advertising identifier in your device settings:
**Settings ▸ Google ▸ Ads** (Android).

## Purchases

Premium is a one-time in-app purchase processed by **Google Play Billing**. We do not receive or store your payment-card details; payments are handled entirely by Google Play. We only receive confirmation of whether the purchase was completed, which is used to unlock Premium features on your device.

## Permissions

- **Internet / Network state** — required to load ads.
- **Set alarm** — used only when you tap a suggested time, to hand it to your device's clock app. The App does not read your existing alarms.

## Children's privacy

The App is intended for a general audience and is not directed at children under 13. We do not knowingly collect personal information from children.

## Third-party services

The App uses the following third-party services, each with its own privacy policy:

- **Google AdMob / Google Mobile Ads** — https://policies.google.com/privacy
- **Google Play Billing / Google Play services** — https://policies.google.com/privacy

## Data retention and deletion

Because preferences are stored only on your device, you can delete all App data at any time by clearing the App's storage (**Settings ▸ Apps ▸ BedTime ▸ Storage ▸ Clear data**) or by uninstalling the App.

## Changes to this policy

We may update this Privacy Policy from time to time. Changes will be posted at this URL with an updated "Last updated" date.

## Contact

If you have questions about this Privacy Policy, contact us at:
**[INSERT YOUR CONTACT EMAIL]**

_Developer: [INSERT YOUR NAME / COMPANY]_
