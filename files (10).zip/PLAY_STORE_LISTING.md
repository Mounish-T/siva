# Play Store Listing — copy & paste

Everything below is ready to paste into the Google Play Console. Adjust wording to taste. Character limits are enforced by Google and noted for each field.

---

## App name (max 30 characters)

```
BedTime: Sleep Cycle Calculator
```

(31 chars if you include the space after the colon — if Play rejects it, use:)

```
BedTime - Sleep Calculator
```

## Short description (max 80 characters)

```
Find the perfect time to sleep or wake up. Wake refreshed with sleep cycles.
```

## Full description (max 4000 characters)

```
Wake up refreshed instead of groggy. BedTime calculates the best times to fall asleep or wake up based on your natural 90-minute sleep cycles.

Waking up in the middle of deep sleep is what leaves you feeling exhausted. BedTime times your sleep so your alarm lands at the END of a cycle — the moment you're closest to naturally waking — so mornings feel easier.

THREE SIMPLE MODES
• Wake up at… — tell BedTime when you need to be up, and it shows you exactly when to fall asleep.
• Sleep now — about to go to bed? Instantly see the best times to set your alarm.
• Go to bed at… — pick a bedtime and see when you'd wake up refreshed.

ONE-TAP ALARMS
Found your time? Tap it and BedTime hands it straight to your phone's clock app. No copying numbers.

BEAUTIFUL & CALM
A soothing animated night sky with a glowing moon and twinkling stars — designed to feel relaxing right before bed.

SMART SLEEP SCIENCE
BedTime uses 90-minute sleep cycles plus a short buffer for the time it takes you to drift off, and recommends 5–6 cycles a night — the sweet spot for most adults.

PREMIUM (one-time purchase — no subscription)
Upgrade once and keep it forever:
• Remove all ads
• 4 extra themes: Aurora, Sunset, Deep Space & Rose Dawn
• Custom sleep-cycle length
• Fine-tune your fall-asleep time

No account needed. No personal data collected. Your settings stay on your device.

Better nights start with better timing. Download BedTime and wake up on the right side of a sleep cycle. 🌙
```

## Category
- **Application type:** App
- **Category:** Health & Fitness  (alternative: Lifestyle)
- **Tags:** sleep, alarm, bedtime, sleep cycle, wake up

## Contact details
- **Email:** [INSERT YOUR SUPPORT EMAIL]
- **Website (optional):** [INSERT IF ANY]
- **Privacy policy URL:** [INSERT HOSTED PRIVACY_POLICY URL]

---

## Graphics checklist

| Asset | Spec | Where |
|---|---|---|
| App icon | 512×512 PNG, 32-bit | `store_assets/play_store_icon_512.png` ✅ included |
| Feature graphic | 1024×500 PNG/JPG | `store_assets/feature_graphic_1024x500.png` ✅ included |
| Phone screenshots | 2–8 images, 16:9 or 9:16, each side 320–3840 px | capture from the running app |
| (Optional) 7" / 10" tablet shots | improves tablet ranking | capture on tablet emulator |

### Suggested screenshots (in order)
1. **Home** screen with the three mode cards and the night sky.
2. A **Results** screen showing bedtimes with the "Recommended" highlight.
3. The **Premium** screen showing the benefits.
4. **Settings** showing the theme picker.
5. (Optional) A second Results screen in a premium theme (e.g. Aurora).

### Screenshot caption ideas (overlay text, optional)
- "Wake up refreshed, every morning"
- "Know exactly when to fall asleep"
- "One tap to set your alarm"
- "Beautiful themes, distraction-free"

---

## "What's new" (release notes for v1.0.0)

```
First release of BedTime 🌙
• Calculate the best times to sleep or wake up
• One-tap alarm setting
• Calming animated night-sky themes
• Premium: remove ads, extra themes, and custom timing
```

---

## Store settings reminders
- **Pricing:** Free (with in-app purchase).
- **In-app products:** "BedTime Premium" — product ID `premium_unlock`.
- **Ads:** mark **"Contains ads" = Yes**.
- **Content rating:** complete the questionnaire → expected rating **Everyone**.
- **Data safety:** advertising ID used (AdMob); no personal data collected; data stored on-device only.
