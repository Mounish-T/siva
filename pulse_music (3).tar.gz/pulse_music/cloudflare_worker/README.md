# Pulse Music — Cloudflare Worker

Caches Jamendo responses at Cloudflare's edge so:
- Many users hitting "Trending" don't all bombard Jamendo individually
- Your Jamendo `client_id` stays server-side (optional)
- The app stays responsive during brief Jamendo outages (serves stale cache for up to 15 min)

## Deploy

```bash
cd cloudflare_worker
npm install -g wrangler
wrangler login
wrangler deploy
```

Wrangler will print a URL like `https://pulse-jamendo-cache.<your-account>.workers.dev`.

## Hide your Jamendo client ID (optional, recommended)

```bash
wrangler secret put JAMENDO_CLIENT_ID
# paste your client_id when prompted
```

Now the Worker injects it for every request and you can ship the APK without embedding the client_id.

## Point the app at the Worker

In `lib/core/config/app_config.dart`, change:

```dart
static const String jamendoBaseUrl = 'https://api.jamendo.com/v3.0';
```

to:

```dart
static const String jamendoBaseUrl =
    'https://pulse-jamendo-cache.<your-account>.workers.dev/v3.0';
```

Rebuild the APK. Cache HITs return in ~20ms instead of 200ms, and your Jamendo quota stops being your bottleneck.

## Free-tier limits

- 100,000 requests/day
- 10ms CPU time per request

For Pulse, each cached response uses <1ms of CPU, so the only real limit is request count. At 100k/day, you can serve a few thousand active users comfortably.
