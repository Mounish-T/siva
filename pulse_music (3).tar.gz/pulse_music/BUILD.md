# Build walkthrough

This document traces what happens when you run `flutter build apk --release`, what can go wrong at each step, and exactly how to fix each error. Written from the perspective of someone who has never built this project before.

---

## Phase 0 — Prerequisites

Before running anything, verify these:

```bash
flutter --version
```

Expected: `Flutter 3.19.0` or newer. If older, run `flutter upgrade`.

```bash
flutter doctor
```

Required green checkmarks:
- ✓ Flutter (Channel stable)
- ✓ Android toolchain - develop for Android devices
- ✓ Android Studio (or VS Code with Flutter extension)

If "Android toolchain" is red, follow https://docs.flutter.dev/get-started/install — you almost certainly need to install Android Studio and accept the Android SDK licenses with:
```bash
flutter doctor --android-licenses
```

```bash
java --version
```

Expected: Java 17 or newer. The included `android/app/build.gradle` sets `sourceCompatibility JavaVersion.VERSION_17`. If your system Java is 11 or older, builds fail with cryptic Gradle errors. Fix: install JDK 17, then:
```bash
flutter config --jdk-dir="/path/to/jdk-17"
```

---

## Phase 1 — Generate platform boilerplate

The project I gave you contains the **customized** Android files (manifest, build.gradle, MainActivity, ProGuard rules) but not the **boilerplate** (`gradle/wrapper/`, `gradlew`, mipmap icon directories, generated `key.properties` templates). You need to regenerate these on first checkout:

```bash
cd pulse_music
flutter create --org com.pulse --project-name pulse_music --platforms=android .
```

Flutter sees that customized files already exist and leaves them alone — it only creates what's missing.

**What can go wrong:**

| Error | Cause | Fix |
|---|---|---|
| `The current Flutter SDK version is X. Because pulse_music requires SDK version >=3.3.0` | Flutter too old | `flutter upgrade` |
| `Could not resolve project ':app'` | Gradle wrapper missing | The `flutter create` above generates it. Run that command. |
| `Permission denied: ./gradlew` | gradlew not executable | `chmod +x android/gradlew` |

---

## Phase 2 — Pub get

```bash
flutter pub get
```

This resolves the 16 packages in `pubspec.yaml` and downloads them to `~/.pub-cache`.

**What can go wrong:**

| Error | Cause | Fix |
|---|---|---|
| `Because every version of X depends on Y...` | Version conflict | Try `flutter pub upgrade --major-versions`. If still broken, edit `pubspec.yaml` to relax the constraint on the conflicting package. |
| `Failed to download package` | Network / pub.dev outage | Retry, or check https://status.dart.dev |
| `path_provider not found` | Old Flutter SDK | `flutter upgrade` |

After pub get, look in the output for any **deprecation warnings** — they're harmless but worth noting. Common one in 2026: `google_sign_in` 6.x may warn about migration to 7.x. The 6.x version is fine for now.

---

## Phase 3 — Static analysis (optional but recommended)

```bash
flutter analyze
```

Expected output: `No issues found!`

If you see warnings, they're likely one of:

| Warning | Meaning | Action |
|---|---|---|
| `Unused import` | An import that's no longer referenced | Delete the line |
| `prefer_const_constructors` | A constructor call that could be `const` | Add `const` |
| `Missing required argument` | Real bug — a field marked `required` isn't being passed | Fix the call site |

The `analysis_options.yaml` in this project enables strict linting. Warnings don't block the build, but errors do.

---

## Phase 4 — The build itself

```bash
flutter build apk --release \
  --dart-define=JAMENDO_CLIENT_ID=your_id \
  --dart-define=SUPABASE_URL=https://yourproject.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=your_anon_key
```

(Add `--dart-define=GOOGLE_WEB_CLIENT_ID=...` only if you set up Google Sign-In.)

What happens internally:
1. Flutter compiles Dart → AOT machine code for ARM64 and ARMv7
2. Gradle assembles Android resources (manifests, drawables, mipmaps)
3. R8 minifies + shrinks the result (configured in `build.gradle`)
4. The APK is signed with the debug key (configured in `build.gradle` — replace for Play Store)
5. Output: `build/app/outputs/flutter-apk/app-release.apk`

Build time: typically 60-120 seconds on a modern laptop.

**What can go wrong (in rough order of frequency):**

| Error | Cause | Fix |
|---|---|---|
| `Execution failed for task ':app:lintVitalAnalyzeRelease'` | Android lint found errors in dependencies | Add `lintOptions { checkReleaseBuilds false }` to `android/app/build.gradle` inside `android { ... }` |
| `Duplicate class found in modules` | Conflicting transitive dep versions | Run `cd android && ./gradlew app:dependencies` to find the conflict, then add an exclusion or version constraint |
| `Manifest merger failed: Attribute application@...` | Conflicting manifest from a plugin | Read the error — it tells you exactly what to add to `AndroidManifest.xml` (usually `tools:replace="..."`) |
| `Error: ProGuard rules don't match` (release only) | A package's classes are getting stripped by R8 | Add a `-keep class com.foo.** { *; }` rule to `android/app/proguard-rules.pro` |
| `D8: Cannot fit requested classes in a single dex file` | Too many methods | The project already has `multiDexEnabled true` set. If you still hit this, you have a runaway dependency — audit `pubspec.yaml`. |
| `> Could not resolve all artifacts for configuration ':classpath'` | Gradle plugin version mismatch | Update Gradle wrapper: `cd android && ./gradlew wrapper --gradle-version 8.4` |
| `Execution failed for task ':app:processReleaseGoogleServices'` | Trying to use Firebase without `google-services.json` | This project doesn't use Firebase. If you see this, you've added a Firebase plugin by accident — remove it. |
| `cannot find symbol: import io.flutter.embedding.engine.plugins.GeneratedPluginRegistrant` | Old project structure (Flutter v1 embedding) | The included `AndroidManifest.xml` already specifies `flutterEmbedding = 2`. Re-run `flutter create .` from Phase 1. |

If the build fails and the error doesn't match any of the above, copy the **last 30 lines of output** — that's where the real error is. Gradle prints a lot of noise above the actual problem.

---

## Phase 5 — Install and test

```bash
# Connect a device via USB (with developer mode + USB debugging on)
flutter install --release
```

Or sideload manually:
```bash
adb install build/app/outputs/flutter-apk/app-release.apk
```

Or copy the APK to your device and tap it from a file manager.

---

## Phase 6 — Runtime checks

After install, open the app. First-launch flow:

1. **Splash screen** (black, with no logo — replace `launch_background.xml` with your own drawable if you want a branded splash)
2. **Onboarding** (3 slides, one-time)
3. **Login** — either sign up, sign in, or tap "Continue without account"
4. **Home feed** loads. If it doesn't, check:

| Symptom | Cause | Fix |
|---|---|---|
| "Network error: SocketException" on home | Device offline, or `JAMENDO_CLIENT_ID` wrong | Verify the client_id is valid via `curl "https://api.jamendo.com/v3.0/tracks/?client_id=YOUR_ID&format=json&limit=1"` |
| "Jamendo client ID not configured" | The `--dart-define` didn't make it into the APK | Rebuild — `--dart-define` is captured at *build* time, not run time |
| Home loads but tracks don't play | Audio URL blocked by upstream | Check device logs: `adb logcat | grep -i pulse` |
| Lock screen has no media notification | First notification permission denied | Settings → Apps → Pulse Music → Notifications → enable |
| Audio cuts off when screen turns off | `FOREGROUND_SERVICE_MEDIA_PLAYBACK` not granted | Reinstall, accept all permission prompts |

---

## Phase 7 — Verifying offline downloads

1. Open any track's three-dot menu → tap "Download"
2. Go to Library → Downloads → see progress
3. Turn the device airplane mode on
4. Tap the downloaded track from anywhere — it should play instantly from the local file

If it doesn't:

```bash
adb shell run-as com.pulse.music ls /data/data/com.pulse.music/app_flutter/downloads/
```

You should see `<trackId>.mp3` files. If the directory is empty, the download silently failed — check the device's storage isn't full.

---

## Quick sanity script

After a fresh build, run this to verify everything compiled into the APK:

```bash
# APK exists and is reasonable size
ls -lh build/app/outputs/flutter-apk/app-release.apk
# Should be 20-35 MB

# Manifest looks right
$ANDROID_HOME/build-tools/34.0.0/aapt dump permissions build/app/outputs/flutter-apk/app-release.apk
# Should list INTERNET, FOREGROUND_SERVICE, FOREGROUND_SERVICE_MEDIA_PLAYBACK, etc.

# Package name correct
$ANDROID_HOME/build-tools/34.0.0/aapt dump badging build/app/outputs/flutter-apk/app-release.apk | grep package
# Should say: package: name='com.pulse.music'
```
