import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/models/track.dart';
import '../core/services/download_service.dart';
import '../core/services/providers.dart';
import '../core/theme/app_theme.dart';
import '../features/playlists/add_to_playlist_sheet.dart';

class TrackTile extends ConsumerWidget {
  const TrackTile({
    super.key,
    required this.track,
    required this.queue,
    required this.index,
  });

  final Track track;
  final List<Track> queue;
  final int index;

  void _showOptions(BuildContext context, WidgetRef ref, bool isFav) {
    final downloads = ref.read(downloadsProvider).valueOrNull ?? const [];
    final existing = downloads.where((e) => e.track.id == track.id).toList();
    final isDownloaded = existing.isNotEmpty &&
        existing.first.status == DownloadStatus.completed;
    final isDownloading = existing.isNotEmpty &&
        (existing.first.status == DownloadStatus.downloading ||
            existing.first.status == DownloadStatus.queued);

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.surfaceElevated,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (sheetCtx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: SizedBox(
                      width: 44,
                      height: 44,
                      child: track.imageUrl.isEmpty
                          ? Container(color: AppTheme.surface)
                          : CachedNetworkImage(
                              imageUrl: track.imageUrl, fit: BoxFit.cover),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(track.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style:
                                const TextStyle(fontWeight: FontWeight.w600)),
                        Text(track.artist,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: AppTheme.textSecondary, fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const Divider(color: Color(0xFF2A2A2A), height: 1),
            ListTile(
              leading: Icon(
                isFav ? Icons.favorite : Icons.favorite_border,
                color: isFav ? AppTheme.brand : null,
              ),
              title: Text(isFav ? 'Remove from liked' : 'Add to liked'),
              onTap: () {
                Navigator.pop(sheetCtx);
                ref.read(favoritesProvider.notifier).toggle(track);
              },
            ),
            ListTile(
              leading: const Icon(Icons.playlist_add),
              title: const Text('Add to playlist'),
              onTap: () {
                Navigator.pop(sheetCtx);
                showAddToPlaylistSheet(context, ref, track);
              },
            ),
            if (isDownloaded)
              ListTile(
                leading: const Icon(Icons.download_done,
                    color: AppTheme.brand),
                title: const Text('Downloaded'),
                subtitle: const Text('Tap to remove',
                    style: TextStyle(fontSize: 11)),
                onTap: () {
                  Navigator.pop(sheetCtx);
                  ref.read(downloadServiceProvider).remove(track.id);
                },
              )
            else if (isDownloading)
              const ListTile(
                leading: SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: AppTheme.brand),
                ),
                title: Text('Downloading…'),
              )
            else
              ListTile(
                leading: const Icon(Icons.download),
                title: const Text('Download'),
                onTap: () {
                  Navigator.pop(sheetCtx);
                  ref.read(downloadServiceProvider).enqueue(track);
                },
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favorites = ref.watch(favoritesProvider);
    final isFav = favorites.any((t) => t.id == track.id);
    final currentTrack = ref.watch(currentTrackProvider).valueOrNull;
    final isPlayingThis = currentTrack?.id == track.id;
    final downloads = ref.watch(downloadsProvider).valueOrNull ?? const [];
    final downloadedHere = downloads.any((e) =>
        e.track.id == track.id && e.status == DownloadStatus.completed);

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: SizedBox(
          width: 52,
          height: 52,
          child: track.imageUrl.isEmpty
              ? Container(color: AppTheme.surfaceElevated)
              : CachedNetworkImage(
                  imageUrl: track.imageUrl,
                  fit: BoxFit.cover,
                  placeholder: (_, __) =>
                      Container(color: AppTheme.surfaceElevated),
                  errorWidget: (_, __, ___) =>
                      Container(color: AppTheme.surfaceElevated),
                ),
        ),
      ),
      title: Text(
        track.title,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: isPlayingThis ? AppTheme.brand : AppTheme.textPrimary,
          fontWeight: FontWeight.w600,
        ),
      ),
      subtitle: Row(
        children: [
          if (downloadedHere) ...[
            const Icon(Icons.arrow_circle_down,
                color: AppTheme.brand, size: 12),
            const SizedBox(width: 4),
          ],
          Expanded(
            child: Text(
              track.artist,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                  color: AppTheme.textSecondary, fontSize: 13),
            ),
          ),
        ],
      ),
      trailing: IconButton(
        icon: const Icon(Icons.more_vert,
            color: AppTheme.textSecondary, size: 20),
        onPressed: () => _showOptions(context, ref, isFav),
      ),
      onTap: () {
        ref.read(playerServiceProvider).setQueue(queue, startIndex: index);
      },
    );
  }
}
