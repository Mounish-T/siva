class Album {
  const Album({
    required this.id,
    required this.name,
    required this.artistName,
    required this.imageUrl,
    this.releaseDate,
  });

  final String id;
  final String name;
  final String artistName;
  final String imageUrl;
  final String? releaseDate;

  factory Album.fromJamendo(Map<String, dynamic> json) {
    return Album(
      id: json['id']?.toString() ?? '',
      name: (json['name'] as String?) ?? 'Untitled',
      artistName: (json['artist_name'] as String?) ?? 'Unknown',
      imageUrl: (json['image'] as String?) ?? '',
      releaseDate: json['releasedate'] as String?,
    );
  }
}

class Artist {
  const Artist({
    required this.id,
    required this.name,
    required this.imageUrl,
  });

  final String id;
  final String name;
  final String imageUrl;

  factory Artist.fromJamendo(Map<String, dynamic> json) {
    return Artist(
      id: json['id']?.toString() ?? '',
      name: (json['name'] as String?) ?? 'Unknown',
      imageUrl: (json['image'] as String?) ?? '',
    );
  }
}
