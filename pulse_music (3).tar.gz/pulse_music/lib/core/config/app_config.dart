/// App-wide configuration.
///
/// All keys are read from compile-time environment variables passed via
/// `--dart-define`. This keeps secrets out of source control.
///
/// Example release build:
/// ```
/// flutter build apk --release \
///   --dart-define=JAMENDO_CLIENT_ID=xxxxxxxx \
///   --dart-define=SUPABASE_URL=https://xxxx.supabase.co \
///   --dart-define=SUPABASE_ANON_KEY=eyJhbGciOi...
/// ```
class AppConfig {
  AppConfig._();

  /// Get one free at https://devportal.jamendo.com/
  static const String jamendoClientId = String.fromEnvironment(
    'JAMENDO_CLIENT_ID',
    defaultValue: '',
  );

  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: '',
  );

  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: '',
  );

  /// Web OAuth Client ID from Google Cloud Console.
  /// Used as the "server client ID" for Android Google Sign-In.
  static const String googleWebClientId = String.fromEnvironment(
    'GOOGLE_WEB_CLIENT_ID',
    defaultValue: '',
  );

  /// When true, the app captures verbose logs in a ring buffer and exposes
  /// a "Diagnostics" screen under Settings → Developer with a self-check
  /// button. Off by default — pass --dart-define=PULSE_DIAGNOSTICS=true
  /// at build time to enable.
  static const bool diagnosticsEnabled = bool.fromEnvironment(
    'PULSE_DIAGNOSTICS',
    defaultValue: false,
  );

  static const String jamendoBaseUrl = 'https://api.jamendo.com/v3.0';

  /// If true, the app will still run without Supabase configured — auth
  /// screens will be skipped and the home feed will load anonymously.
  /// This makes it easy to demo the player before you set up the backend.
  static bool get supabaseConfigured =>
      supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

  static bool get jamendoConfigured => jamendoClientId.isNotEmpty;

  static bool get googleSignInConfigured => googleWebClientId.isNotEmpty;
}
