import '../models/track.dart';
import 'jamendo_service.dart';
import 'library_service.dart';

/// Builds curated "mix" lists for the home screen.
///
/// We don't have collaborative filtering — instead we use a simple but
/// effective approach: each mix is a Jamendo tag query with a curated
/// vibe. The "Daily Mix" personalizes off the user's recently played
/// genres when available.
class RecommendationService {
  RecommendationService(this._jamendo);
  final JamendoService _jamendo;

  /// Personalized mix — uses recently played artists/themes if any.
  Future<List<Track>> dailyMix() async {
    final recent = await LibraryService.instance.loadRecentlyPlayed();
    if (recent.isEmpty) {
      // No history yet — fall back to popular tracks.
      return _jamendo.trending(limit: 25);
    }
    // Take the most-recently-played artist and find similar tracks by genre.
    // Since we don't have genre on cached tracks, just shuffle recent + add trending.
    final trending = await _jamendo.trending(limit: 25);
    final seen = recent.map((t) => t.id).toSet();
    final blend = [
      ...recent.take(5),
      ...trending.where((t) => !seen.contains(t.id)).take(20),
    ];
    return blend;
  }

  Future<List<Track>> chillMix() =>
      _jamendo.byTag('chillout', limit: 25);

  Future<List<Track>> workoutMix() =>
      _jamendo.byTag('electronic', limit: 25);

  Future<List<Track>> focusMix() =>
      _jamendo.byTag('ambient', limit: 25);

  Future<List<Track>> trendingMix() =>
      _jamendo.trending(limit: 25);
}

/// Static metadata for each mix card.
class MixInfo {
  const MixInfo({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.gradient,
  });

  final String id;
  final String title;
  final String subtitle;
  final List<int> gradient; // hex colors

  static const all = [
    MixInfo(
      id: 'daily',
      title: 'Daily Mix',
      subtitle: 'Made for you, refreshed every day',
      gradient: [0xFF7E22CE, 0xFFC026D3],
    ),
    MixInfo(
      id: 'chill',
      title: 'Chill Mix',
      subtitle: 'Easy listening for unwinding',
      gradient: [0xFF1E3A8A, 0xFF2563EB],
    ),
    MixInfo(
      id: 'workout',
      title: 'Workout Mix',
      subtitle: 'High-energy electronic tracks',
      gradient: [0xFFDC2626, 0xFFEAB308],
    ),
    MixInfo(
      id: 'focus',
      title: 'Focus Mix',
      subtitle: 'Ambient soundscapes',
      gradient: [0xFF065F46, 0xFF10B981],
    ),
    MixInfo(
      id: 'trending',
      title: 'Trending Mix',
      subtitle: "What's hot right now",
      gradient: [0xFFE11D48, 0xFFEC4899],
    ),
  ];
}
