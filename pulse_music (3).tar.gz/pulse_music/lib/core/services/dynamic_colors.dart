import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:palette_generator/palette_generator.dart';

/// Resolves a dominant color from a network image URL.
///
/// Returns a sensible default ([fallback]) on any error and for empty URLs.
class DynamicColors {
  static final Map<String, Color> _cache = {};

  static Future<Color> dominantFrom(
    String imageUrl, {
    Color fallback = const Color(0xFF1F1F1F),
  }) async {
    if (imageUrl.isEmpty) return fallback;
    if (_cache.containsKey(imageUrl)) return _cache[imageUrl]!;
    try {
      final provider = CachedNetworkImageProvider(imageUrl);
      final palette = await PaletteGenerator.fromImageProvider(
        provider,
        size: const Size(120, 120),
        maximumColorCount: 8,
      );
      final color = palette.darkVibrantColor?.color ??
          palette.dominantColor?.color ??
          fallback;
      _cache[imageUrl] = color;
      return color;
    } catch (_) {
      return fallback;
    }
  }
}
