import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';
import 'auth_service.dart';
import 'diagnostics_service.dart';
import 'download_service.dart';
import 'player_service.dart';

enum CheckStatus { pending, running, pass, fail, skip }

class CheckResult {
  CheckResult({
    required this.id,
    required this.label,
    this.status = CheckStatus.pending,
    this.detail,
  });

  final String id;
  final String label;
  CheckStatus status;
  String? detail;
}

/// Runs a series of real probes and reports pass/fail for each.
/// Designed to be called from the diagnostics screen.
class SelfCheckService {
  SelfCheckService._();
  static final SelfCheckService instance = SelfCheckService._();

  final _diag = DiagnosticsService.instance;

  /// Runs all checks and yields results as each completes.
  Stream<List<CheckResult>> run() async* {
    final results = <CheckResult>[
      CheckResult(id: 'config', label: 'App configuration'),
      CheckResult(id: 'network', label: 'Network reachable'),
      CheckResult(id: 'jamendo', label: 'Jamendo API'),
      CheckResult(id: 'supabase', label: 'Supabase backend'),
      CheckResult(id: 'auth', label: 'Authenticated session'),
      CheckResult(id: 'player', label: 'Audio player'),
      CheckResult(id: 'downloads', label: 'Downloads directory writable'),
    ];

    _diag.info('SelfCheck', 'Starting ${results.length} checks');
    yield List.of(results);

    for (final r in results) {
      r.status = CheckStatus.running;
      yield List.of(results);

      try {
        switch (r.id) {
          case 'config':
            _checkConfig(r);
            break;
          case 'network':
            await _checkNetwork(r);
            break;
          case 'jamendo':
            await _checkJamendo(r);
            break;
          case 'supabase':
            await _checkSupabase(r);
            break;
          case 'auth':
            _checkAuth(r);
            break;
          case 'player':
            _checkPlayer(r);
            break;
          case 'downloads':
            await _checkDownloads(r);
            break;
        }
      } catch (e) {
        r.status = CheckStatus.fail;
        r.detail = 'Unexpected error: $e';
        _diag.error('SelfCheck', '${r.label}: $e');
      }

      _diag.info('SelfCheck',
          '${r.label}: ${r.status.name}${r.detail != null ? ' (${r.detail})' : ''}');
      yield List.of(results);
    }

    _diag.info('SelfCheck', 'All checks complete');
  }

  // ---------- Individual checks ----------

  void _checkConfig(CheckResult r) {
    final issues = <String>[];
    if (!AppConfig.jamendoConfigured) {
      issues.add('JAMENDO_CLIENT_ID missing');
    }
    if (!AppConfig.supabaseConfigured) {
      issues.add('Supabase not configured (optional)');
    }
    if (!AppConfig.googleSignInConfigured) {
      issues.add('Google Sign-In not configured (optional)');
    }

    if (AppConfig.jamendoConfigured) {
      r.status = CheckStatus.pass;
      r.detail = issues.isEmpty ? null : issues.join(' • ');
    } else {
      r.status = CheckStatus.fail;
      r.detail = issues.join(' • ');
    }
  }

  Future<void> _checkNetwork(CheckResult r) async {
    try {
      final result = await InternetAddress.lookup('jamendo.com')
          .timeout(const Duration(seconds: 5));
      if (result.isNotEmpty && result.first.rawAddress.isNotEmpty) {
        r.status = CheckStatus.pass;
      } else {
        r.status = CheckStatus.fail;
        r.detail = 'DNS lookup returned no results';
      }
    } on SocketException catch (e) {
      r.status = CheckStatus.fail;
      r.detail = 'No network: ${e.message}';
    } on TimeoutException {
      r.status = CheckStatus.fail;
      r.detail = 'DNS lookup timed out after 5s';
    }
  }

  Future<void> _checkJamendo(CheckResult r) async {
    if (!AppConfig.jamendoConfigured) {
      r.status = CheckStatus.skip;
      r.detail = 'Client ID not configured';
      return;
    }
    try {
      final dio = Dio();
      final res = await dio.get<Map<String, dynamic>>(
        '${AppConfig.jamendoBaseUrl}/tracks/',
        queryParameters: {
          'client_id': AppConfig.jamendoClientId,
          'format': 'json',
          'limit': 1,
        },
        options: Options(
          receiveTimeout: const Duration(seconds: 8),
          sendTimeout: const Duration(seconds: 5),
        ),
      );
      final status = res.data?['headers']?['status']?.toString();
      if (status == 'success') {
        r.status = CheckStatus.pass;
        final count = (res.data?['results'] as List?)?.length ?? 0;
        r.detail = 'Received $count track${count == 1 ? '' : 's'}';
      } else {
        r.status = CheckStatus.fail;
        r.detail = 'API returned status: $status';
      }
    } on DioException catch (e) {
      r.status = CheckStatus.fail;
      r.detail = 'HTTP ${e.response?.statusCode ?? '?'}: ${e.message}';
    }
  }

  Future<void> _checkSupabase(CheckResult r) async {
    if (!AppConfig.supabaseConfigured) {
      r.status = CheckStatus.skip;
      r.detail = 'Supabase not configured';
      return;
    }
    try {
      // Hit the health endpoint — works without auth.
      final dio = Dio();
      final res = await dio.get<dynamic>(
        '${AppConfig.supabaseUrl}/auth/v1/health',
        options: Options(
          receiveTimeout: const Duration(seconds: 8),
          headers: {'apikey': AppConfig.supabaseAnonKey},
        ),
      );
      if (res.statusCode == 200) {
        r.status = CheckStatus.pass;
        r.detail = 'Health endpoint OK';
      } else {
        r.status = CheckStatus.fail;
        r.detail = 'HTTP ${res.statusCode}';
      }
    } on DioException catch (e) {
      r.status = CheckStatus.fail;
      r.detail = 'HTTP ${e.response?.statusCode ?? '?'}: ${e.message}';
    }
  }

  void _checkAuth(CheckResult r) {
    if (!AppConfig.supabaseConfigured) {
      r.status = CheckStatus.skip;
      r.detail = 'Supabase not configured';
      return;
    }
    try {
      final session = Supabase.instance.client.auth.currentSession;
      if (session == null) {
        r.status = CheckStatus.skip;
        r.detail = 'No active session (signed out)';
      } else {
        final email = AuthService.instance.currentUser?.email ?? 'unknown';
        r.status = CheckStatus.pass;
        r.detail = 'Signed in as $email';
      }
    } catch (e) {
      r.status = CheckStatus.fail;
      r.detail = e.toString();
    }
  }

  void _checkPlayer(CheckResult r) {
    try {
      // Accessing the singleton forces lazy init.
      final svc = PlayerService.instance;
      // The fact that we got here without throwing is the check.
      // ignore: unnecessary_null_comparison
      r.status = svc != null ? CheckStatus.pass : CheckStatus.fail;
      r.detail =
          'Queue length: ${svc.queue.length}, current: ${svc.currentTrack?.title ?? "(none)"}';
    } catch (e) {
      r.status = CheckStatus.fail;
      r.detail = e.toString();
    }
  }

  Future<void> _checkDownloads(CheckResult r) async {
    try {
      // Force DownloadService init (it creates the directory on init).
      DownloadService.instance;
      final docs = await getApplicationDocumentsDirectory();
      final dir = Directory('${docs.path}/downloads');
      if (await dir.exists()) {
        // Try a tiny write probe.
        final probe = File('${dir.path}/.probe');
        await probe.writeAsString('ok');
        await probe.delete();
        r.status = CheckStatus.pass;
        r.detail = dir.path;
      } else {
        r.status = CheckStatus.fail;
        r.detail = 'Directory does not exist: ${dir.path}';
      }
    } catch (e) {
      r.status = CheckStatus.fail;
      r.detail = e.toString();
    }
  }
}
