import 'dart:async';

import 'player_service.dart';

class SleepTimer {
  SleepTimer._();
  static final SleepTimer instance = SleepTimer._();

  Timer? _timer;
  DateTime? _endsAt;
  final _stateController = StreamController<Duration?>.broadcast();

  /// Stream of remaining time. Emits null when no timer is active.
  Stream<Duration?> get remainingStream => _stateController.stream;
  Duration? get remaining => _endsAt == null
      ? null
      : _endsAt!.difference(DateTime.now());
  bool get isActive => _timer?.isActive ?? false;

  void start(Duration duration) {
    cancel();
    _endsAt = DateTime.now().add(duration);
    _stateController.add(duration);

    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      final left = remaining;
      if (left == null || left.isNegative || left.inSeconds <= 0) {
        PlayerService.instance.pause();
        cancel();
      } else {
        _stateController.add(left);
      }
    });
  }

  void cancel() {
    _timer?.cancel();
    _timer = null;
    _endsAt = null;
    _stateController.add(null);
  }
}
