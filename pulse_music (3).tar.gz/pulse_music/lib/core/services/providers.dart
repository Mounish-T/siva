import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:just_audio/just_audio.dart';

import '../models/track.dart';
import 'auth_service.dart';
import 'download_service.dart';
import 'jamendo_service.dart';
import 'library_service.dart';
import 'player_service.dart';
import 'recommendation_service.dart';
import 'sleep_timer.dart';

// ---------- Services ----------

final jamendoServiceProvider = Provider<JamendoService>((_) => JamendoService());

final playerServiceProvider =
    Provider<PlayerService>((_) => PlayerService.instance);

final authServiceProvider = Provider<AuthService>((_) => AuthService.instance);

final libraryServiceProvider =
    Provider<LibraryService>((_) => LibraryService.instance);

final recommendationServiceProvider = Provider<RecommendationService>(
    (ref) => RecommendationService(ref.read(jamendoServiceProvider)));

final sleepTimerProvider = Provider<SleepTimer>((_) => SleepTimer.instance);

final downloadServiceProvider =
    Provider<DownloadService>((_) => DownloadService.instance);

final downloadsProvider = StreamProvider<List<DownloadEntry>>((ref) async* {
  final svc = ref.read(downloadServiceProvider);
  // Emit current state immediately so the UI doesn't flash empty.
  yield svc.all;
  yield* svc.stream;
});

final speedProvider = StreamProvider<double>((ref) {
  return ref.read(playerServiceProvider).speedStream;
});

// ---------- Feeds ----------

final trendingTracksProvider = FutureProvider<List<Track>>((ref) async {
  return ref.read(jamendoServiceProvider).trending(limit: 20);
});

final latestTracksProvider = FutureProvider<List<Track>>((ref) async {
  return ref.read(jamendoServiceProvider).latest(limit: 20);
});

final tracksByGenreProvider =
    FutureProvider.family<List<Track>, String>((ref, genre) async {
  return ref.read(jamendoServiceProvider).byTag(genre, limit: 20);
});

final searchQueryProvider = StateProvider<String>((_) => '');

final searchResultsProvider = FutureProvider<List<Track>>((ref) async {
  final q = ref.watch(searchQueryProvider);
  if (q.trim().isEmpty) return const [];
  return ref.read(jamendoServiceProvider).search(q);
});

// ---------- Recommendations ----------

final dailyMixProvider = FutureProvider<List<Track>>(
    (ref) => ref.read(recommendationServiceProvider).dailyMix());
final chillMixProvider = FutureProvider<List<Track>>(
    (ref) => ref.read(recommendationServiceProvider).chillMix());
final workoutMixProvider = FutureProvider<List<Track>>(
    (ref) => ref.read(recommendationServiceProvider).workoutMix());
final focusMixProvider = FutureProvider<List<Track>>(
    (ref) => ref.read(recommendationServiceProvider).focusMix());
final trendingMixProvider = FutureProvider<List<Track>>(
    (ref) => ref.read(recommendationServiceProvider).trendingMix());

// ---------- Album / Artist ----------

final albumTracksProvider =
    FutureProvider.family<List<Track>, String>((ref, albumId) async {
  return ref.read(jamendoServiceProvider).tracksByAlbum(albumId);
});

final artistTracksProvider =
    FutureProvider.family<List<Track>, String>((ref, artistId) async {
  return ref.read(jamendoServiceProvider).tracksByArtist(artistId);
});

// ---------- Player state ----------

final currentTrackProvider = StreamProvider<Track?>((ref) {
  return ref.read(playerServiceProvider).currentTrackStream;
});

final playerStateProvider = StreamProvider<PlayerState>((ref) {
  return ref.read(playerServiceProvider).playerStateStream;
});

final positionProvider = StreamProvider<Duration>((ref) {
  return ref.read(playerServiceProvider).positionStream;
});

final durationProvider = StreamProvider<Duration?>((ref) {
  return ref.read(playerServiceProvider).durationStream;
});

final shuffleProvider = StreamProvider<bool>((ref) {
  return ref.read(playerServiceProvider).shuffleModeEnabledStream;
});

final loopModeProvider = StreamProvider<LoopMode>((ref) {
  return ref.read(playerServiceProvider).loopModeStream;
});

final sleepTimerRemainingProvider = StreamProvider<Duration?>((ref) {
  return ref.read(sleepTimerProvider).remainingStream;
});

// ---------- Library (favorites, persistent) ----------

class FavoritesNotifier extends StateNotifier<List<Track>> {
  FavoritesNotifier(this._library) : super(const []) {
    _hydrate();
  }
  final LibraryService _library;

  Future<void> _hydrate() async {
    state = await _library.loadFavorites();
  }

  bool contains(Track t) => state.any((e) => e.id == t.id);

  Future<void> toggle(Track t) async {
    if (contains(t)) {
      state = state.where((e) => e.id != t.id).toList();
      await _library.removeFavorite(t.id);
    } else {
      state = [t, ...state];
      await _library.addFavorite(t);
    }
  }

  Future<void> refresh() async {
    await _hydrate();
  }
}

final favoritesProvider =
    StateNotifierProvider<FavoritesNotifier, List<Track>>(
        (ref) => FavoritesNotifier(ref.read(libraryServiceProvider)));

// ---------- Recently played ----------

class RecentlyPlayedNotifier extends StateNotifier<List<Track>> {
  RecentlyPlayedNotifier(this._library) : super(const []) {
    _hydrate();
    _sub = _library.recentlyPlayedStream.listen((list) {
      if (mounted) state = list;
    });
  }
  final LibraryService _library;
  StreamSubscription<List<Track>>? _sub;

  Future<void> _hydrate() async {
    state = await _library.loadRecentlyPlayed();
  }

  Future<void> refresh() async => _hydrate();

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}

final recentlyPlayedProvider =
    StateNotifierProvider<RecentlyPlayedNotifier, List<Track>>(
        (ref) => RecentlyPlayedNotifier(ref.read(libraryServiceProvider)));

// ---------- Playlists ----------

class PlaylistsNotifier extends StateNotifier<List<PlaylistData>> {
  PlaylistsNotifier(this._library) : super(const []) {
    refresh();
  }
  final LibraryService _library;

  Future<void> refresh() async {
    state = await _library.loadPlaylists();
  }

  Future<String> create(String name) async {
    final id = await _library.createPlaylist(name);
    await refresh();
    return id;
  }

  Future<void> rename(String id, String name) async {
    await _library.renamePlaylist(id, name);
    await refresh();
  }

  Future<void> delete(String id) async {
    await _library.deletePlaylist(id);
    await refresh();
  }

  Future<void> addTrack(String id, Track t) async {
    await _library.addTrackToPlaylist(id, t);
    await refresh();
  }

  Future<void> removeTrack(String id, String trackId) async {
    await _library.removeTrackFromPlaylist(id, trackId);
    await refresh();
  }
}

final playlistsProvider =
    StateNotifierProvider<PlaylistsNotifier, List<PlaylistData>>(
        (ref) => PlaylistsNotifier(ref.read(libraryServiceProvider)));

@visibleForTesting
typedef PlaylistDataExport = PlaylistData;
