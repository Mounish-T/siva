import 'package:google_sign_in/google_sign_in.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';
import 'diagnostics_service.dart';

/// Thin wrapper around Supabase auth. All methods are safe to call even when
/// Supabase isn't configured — they will throw a descriptive [AuthException].
class AuthService {
  AuthService._();
  static final AuthService instance = AuthService._();

  SupabaseClient? get _client {
    if (!AppConfig.supabaseConfigured) return null;
    return Supabase.instance.client;
  }

  User? get currentUser => _client?.auth.currentUser;

  bool get isSignedIn => currentUser != null;

  Stream<AuthState> get authStateChanges =>
      _client?.auth.onAuthStateChange ?? const Stream.empty();

  void _requireClient() {
    if (_client == null) {
      throw const AuthException(
        'Supabase is not configured. Pass --dart-define=SUPABASE_URL=... '
        'and --dart-define=SUPABASE_ANON_KEY=...',
      );
    }
  }

  Future<void> signUp({required String email, required String password}) async {
    _requireClient();
    DiagnosticsService.instance.info('Auth', 'signUp attempt: $email');
    try {
      await _client!.auth.signUp(email: email, password: password);
      DiagnosticsService.instance.info('Auth', 'signUp success');
    } catch (e) {
      DiagnosticsService.instance.error('Auth', 'signUp failed: $e');
      rethrow;
    }
  }

  Future<void> signIn({required String email, required String password}) async {
    _requireClient();
    DiagnosticsService.instance.info('Auth', 'signIn attempt: $email');
    try {
      await _client!.auth
          .signInWithPassword(email: email, password: password);
      DiagnosticsService.instance.info('Auth', 'signIn success');
    } catch (e) {
      DiagnosticsService.instance.error('Auth', 'signIn failed: $e');
      rethrow;
    }
  }

  /// Triggers the Supabase password-reset email flow.
  Future<void> resetPassword(String email) async {
    _requireClient();
    await _client!.auth.resetPasswordForEmail(email);
  }

  /// Sign in with Google. Requires:
  ///   1. A Google OAuth client (Web type) created in Google Cloud Console.
  ///   2. The Web client's "Client ID" added to Supabase Auth → Providers → Google.
  ///   3. An Android OAuth client (with your APK's SHA-1 fingerprint).
  ///   4. The Android client's Server Client ID (= the Web Client ID) passed below.
  ///
  /// See README for the step-by-step setup.
  Future<void> signInWithGoogle({required String webClientId}) async {
    _requireClient();
    final googleSignIn = GoogleSignIn(serverClientId: webClientId);
    final googleUser = await googleSignIn.signIn();
    if (googleUser == null) {
      throw const AuthException('Google sign-in canceled');
    }
    final googleAuth = await googleUser.authentication;
    final idToken = googleAuth.idToken;
    final accessToken = googleAuth.accessToken;
    if (idToken == null) {
      throw const AuthException('Google sign-in returned no ID token');
    }
    await _client!.auth.signInWithIdToken(
      provider: OAuthProvider.google,
      idToken: idToken,
      accessToken: accessToken,
    );
  }

  Future<void> signOut() async {
    _requireClient();
    await _client!.auth.signOut();
    try {
      await GoogleSignIn().signOut();
    } catch (_) {}
  }
}
