import 'dart:async';
import 'dart:collection';

import 'package:flutter/foundation.dart';

import '../config/app_config.dart';

enum LogLevel { debug, info, warn, error }

class LogEntry {
  LogEntry({
    required this.time,
    required this.level,
    required this.tag,
    required this.message,
  });

  final DateTime time;
  final LogLevel level;
  final String tag;
  final String message;

  String get formatted {
    final t =
        '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:${time.second.toString().padLeft(2, '0')}.${time.millisecond.toString().padLeft(3, '0')}';
    return '[$t] [${level.name.toUpperCase()}] [$tag] $message';
  }
}

/// In-app diagnostics. When [AppConfig.diagnosticsEnabled] is true, log()
/// captures entries in a 500-item ring buffer and emits them on a stream.
/// When false, log() is a no-op so callers don't have to guard every call.
class DiagnosticsService {
  DiagnosticsService._();
  static final DiagnosticsService instance = DiagnosticsService._();

  /// Maximum entries kept in memory.
  static const int _maxEntries = 500;

  final Queue<LogEntry> _buffer = Queue<LogEntry>();
  final StreamController<LogEntry> _controller =
      StreamController.broadcast();

  /// Latest entries, oldest first.
  List<LogEntry> snapshot() => _buffer.toList();

  /// Stream of new entries as they arrive. Useful for the diagnostics
  /// screen which wants live updates.
  Stream<LogEntry> get stream => _controller.stream;

  bool get enabled => AppConfig.diagnosticsEnabled;

  void log(
    String tag,
    String message, {
    LogLevel level = LogLevel.info,
  }) {
    if (!enabled) return;

    final entry = LogEntry(
      time: DateTime.now(),
      level: level,
      tag: tag,
      message: message,
    );

    _buffer.addLast(entry);
    while (_buffer.length > _maxEntries) {
      _buffer.removeFirst();
    }
    _controller.add(entry);

    // Also surface to the Flutter debug console for terminal-side viewing.
    debugPrint(entry.formatted);
  }

  // ---------- Convenience helpers ----------

  void debug(String tag, String message) =>
      log(tag, message, level: LogLevel.debug);
  void info(String tag, String message) =>
      log(tag, message, level: LogLevel.info);
  void warn(String tag, String message) =>
      log(tag, message, level: LogLevel.warn);
  void error(String tag, String message) =>
      log(tag, message, level: LogLevel.error);

  void clear() {
    _buffer.clear();
    // Emit a synthetic "buffer cleared" line so subscribers refresh.
    if (enabled) {
      _controller.add(LogEntry(
        time: DateTime.now(),
        level: LogLevel.info,
        tag: 'Diagnostics',
        message: 'Log buffer cleared',
      ));
    }
  }
}
