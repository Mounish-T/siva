import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/models/track.dart';
import '../../core/services/providers.dart';
import '../../core/services/recommendation_service.dart';
import '../../core/theme/app_theme.dart';
import '../../widgets/skeletons.dart';
import '../../widgets/track_tile.dart';

class MixScreen extends ConsumerWidget {
  const MixScreen({super.key, required this.mix});
  final MixInfo mix;

  FutureProvider<List<Track>> _providerFor(String id) {
    switch (id) {
      case 'daily':
        return dailyMixProvider;
      case 'chill':
        return chillMixProvider;
      case 'workout':
        return workoutMixProvider;
      case 'focus':
        return focusMixProvider;
      case 'trending':
      default:
        return trendingMixProvider;
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tracks = ref.watch(_providerFor(mix.id));
    final gradient = mix.gradient.map((c) => Color(c)).toList();

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 240,
            pinned: true,
            backgroundColor: gradient.first,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(mix.title,
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: gradient,
                  ),
                ),
                child: SafeArea(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(24, 32, 24, 56),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            mix.subtitle,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  tracks.maybeWhen(
                    data: (list) => list.isEmpty
                        ? const SizedBox.shrink()
                        : ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 24, vertical: 12),
                            ),
                            onPressed: () =>
                                ref.read(playerServiceProvider).setQueue(list),
                            icon: const Icon(Icons.play_arrow),
                            label: const Text('Play'),
                          ),
                    orElse: () => const SizedBox.shrink(),
                  ),
                ],
              ),
            ),
          ),
          tracks.when(
            loading: () =>
                const SliverToBoxAdapter(child: TrackTileSkeletonList()),
            error: (e, _) => SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(e.toString(),
                    style: const TextStyle(color: Colors.redAccent)),
              ),
            ),
            data: (list) => list.isEmpty
                ? const SliverToBoxAdapter(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text('No tracks available',
                          style: TextStyle(color: AppTheme.textSecondary)),
                    ),
                  )
                : SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (_, i) => TrackTile(
                          track: list[i], queue: list, index: i),
                      childCount: list.length,
                    ),
                  ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 80)),
        ],
      ),
    );
  }
}
