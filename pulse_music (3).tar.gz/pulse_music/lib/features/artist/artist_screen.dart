import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/services/dynamic_colors.dart';
import '../../core/services/providers.dart';
import '../../core/theme/app_theme.dart';
import '../../widgets/skeletons.dart';
import '../../widgets/track_tile.dart';

class ArtistScreen extends ConsumerStatefulWidget {
  const ArtistScreen({
    super.key,
    required this.artistId,
    required this.artistName,
    required this.imageUrl,
  });

  final String artistId;
  final String artistName;
  final String imageUrl;

  @override
  ConsumerState<ArtistScreen> createState() => _ArtistScreenState();
}

class _ArtistScreenState extends ConsumerState<ArtistScreen> {
  Color _gradient = AppTheme.surface;

  @override
  void initState() {
    super.initState();
    DynamicColors.dominantFrom(widget.imageUrl).then((c) {
      if (mounted) setState(() => _gradient = c);
    });
  }

  @override
  Widget build(BuildContext context) {
    final tracks = ref.watch(artistTracksProvider(widget.artistId));

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 280,
            pinned: true,
            backgroundColor: _gradient,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                widget.artistName,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
              background: Stack(
                fit: StackFit.expand,
                children: [
                  if (widget.imageUrl.isNotEmpty)
                    CachedNetworkImage(
                      imageUrl: widget.imageUrl,
                      fit: BoxFit.cover,
                      errorWidget: (_, __, ___) =>
                          Container(color: _gradient),
                    )
                  else
                    Container(color: _gradient),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          AppTheme.background.withOpacity(0.9),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Row(
                children: [
                  const Text(
                    'Popular',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                  ),
                  const Spacer(),
                  tracks.maybeWhen(
                    data: (list) => list.isEmpty
                        ? const SizedBox.shrink()
                        : ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 18, vertical: 10),
                              textStyle: const TextStyle(fontSize: 13),
                            ),
                            onPressed: () => ref
                                .read(playerServiceProvider)
                                .setQueue(list),
                            icon: const Icon(Icons.play_arrow, size: 18),
                            label: const Text('Play'),
                          ),
                    orElse: () => const SizedBox.shrink(),
                  ),
                ],
              ),
            ),
          ),
          tracks.when(
            loading: () => const SliverToBoxAdapter(
                child: TrackTileSkeletonList(count: 8)),
            error: (e, _) => SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(e.toString(),
                    style: const TextStyle(color: Colors.redAccent)),
              ),
            ),
            data: (list) => SliverList(
              delegate: SliverChildBuilderDelegate(
                (_, i) => TrackTile(track: list[i], queue: list, index: i),
                childCount: list.length,
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 80)),
        ],
      ),
    );
  }
}
