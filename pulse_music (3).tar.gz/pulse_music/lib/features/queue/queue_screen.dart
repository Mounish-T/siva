import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/models/track.dart';
import '../../core/services/providers.dart';
import '../../core/theme/app_theme.dart';

class QueueScreen extends ConsumerWidget {
  const QueueScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final player = ref.read(playerServiceProvider);
    final current = ref.watch(currentTrackProvider).valueOrNull;
    final queue = player.queue;
    final currentIndex = player.currentIndex ?? 0;

    final nowPlaying = current;
    final next = queue.length > currentIndex + 1
        ? queue.sublist(currentIndex + 1)
        : <Track>[];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Queue',
            style: TextStyle(fontWeight: FontWeight.w700)),
      ),
      body: queue.isEmpty
          ? const Center(
              child: Text('Queue is empty',
                  style: TextStyle(color: AppTheme.textSecondary)),
            )
          : ListView(
              padding: const EdgeInsets.only(bottom: 32),
              children: [
                if (nowPlaying != null) ...[
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                    child: Text(
                      'Now playing',
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textSecondary,
                          fontSize: 13),
                    ),
                  ),
                  _Row(
                    title: nowPlaying.title,
                    subtitle: nowPlaying.artist,
                    imageUrl: nowPlaying.imageUrl,
                    isCurrent: true,
                    onTap: () {},
                  ),
                ],
                if (next.isNotEmpty) ...[
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 24, 16, 8),
                    child: Text(
                      'Up next',
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textSecondary,
                          fontSize: 13),
                    ),
                  ),
                  for (int i = 0; i < next.length; i++)
                    _Row(
                      title: next[i].title,
                      subtitle: next[i].artist,
                      imageUrl: next[i].imageUrl,
                      isCurrent: false,
                      onTap: () => player.setQueue(queue,
                          startIndex: currentIndex + 1 + i),
                    ),
                ],
              ],
            ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({
    required this.title,
    required this.subtitle,
    required this.imageUrl,
    required this.isCurrent,
    required this.onTap,
  });
  final String title;
  final String subtitle;
  final String imageUrl;
  final bool isCurrent;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: SizedBox(
          width: 44,
          height: 44,
          child: imageUrl.isEmpty
              ? Container(color: AppTheme.surfaceElevated)
              : CachedNetworkImage(
                  imageUrl: imageUrl,
                  fit: BoxFit.cover,
                  errorWidget: (_, __, ___) =>
                      Container(color: AppTheme.surfaceElevated),
                ),
        ),
      ),
      title: Text(
        title,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: isCurrent ? AppTheme.brand : AppTheme.textPrimary,
          fontWeight: FontWeight.w600,
        ),
      ),
      subtitle: Text(
        subtitle,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
      ),
    );
  }
}
