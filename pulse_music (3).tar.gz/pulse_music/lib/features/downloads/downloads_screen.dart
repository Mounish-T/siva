import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/models/track.dart';
import '../../core/services/download_service.dart';
import '../../core/services/providers.dart';
import '../../core/theme/app_theme.dart';

class DownloadsScreen extends ConsumerWidget {
  const DownloadsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final downloads = ref.watch(downloadsProvider).valueOrNull ?? const [];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Downloads',
            style: TextStyle(fontWeight: FontWeight.w700)),
      ),
      body: downloads.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'No downloads yet.\nTap "Download" on any track\'s menu to save it for offline listening.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppTheme.textSecondary, height: 1.5),
                ),
              ),
            )
          : ListView.builder(
              itemCount: downloads.length,
              itemBuilder: (_, i) => _DownloadRow(entry: downloads[i]),
            ),
    );
  }
}

class _DownloadRow extends ConsumerWidget {
  const _DownloadRow({required this.entry});
  final DownloadEntry entry;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = entry.track;
    final svc = ref.read(downloadServiceProvider);

    Widget trailing;
    switch (entry.status) {
      case DownloadStatus.downloading:
      case DownloadStatus.queued:
        trailing = SizedBox(
          width: 64,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  value: entry.progress == 0 ? null : entry.progress,
                  strokeWidth: 2,
                  color: AppTheme.brand,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close, size: 20),
                onPressed: () => svc.cancel(t.id),
              ),
            ],
          ),
        );
        break;
      case DownloadStatus.failed:
        trailing = Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.refresh, color: Colors.orangeAccent),
              onPressed: () => svc.retry(t.id),
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline, size: 20),
              onPressed: () => svc.remove(t.id),
            ),
          ],
        );
        break;
      case DownloadStatus.completed:
        trailing = Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.download_done,
                color: AppTheme.brand, size: 20),
            IconButton(
              icon: const Icon(Icons.delete_outline, size: 20),
              onPressed: () => svc.remove(t.id),
            ),
          ],
        );
        break;
      case DownloadStatus.canceled:
        trailing = const Icon(Icons.cancel_outlined,
            color: AppTheme.textSecondary);
        break;
    }

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: SizedBox(
          width: 52,
          height: 52,
          child: t.imageUrl.isEmpty
              ? Container(color: AppTheme.surfaceElevated)
              : CachedNetworkImage(
                  imageUrl: t.imageUrl,
                  fit: BoxFit.cover,
                  errorWidget: (_, __, ___) =>
                      Container(color: AppTheme.surfaceElevated),
                ),
        ),
      ),
      title: Text(t.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(
        entry.status == DownloadStatus.failed
            ? 'Failed — ${entry.error ?? "unknown error"}'
            : t.artist,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: entry.status == DownloadStatus.failed
              ? Colors.redAccent
              : AppTheme.textSecondary,
          fontSize: 13,
        ),
      ),
      trailing: trailing,
      onTap: entry.status == DownloadStatus.completed
          ? () {
              final downloaded = ref
                  .read(downloadsProvider)
                  .valueOrNull
                  ?.where((e) => e.status == DownloadStatus.completed)
                  .map((e) => e.track)
                  .toList() ??
                  <Track>[];
              final idx = downloaded.indexWhere((tt) => tt.id == t.id);
              if (idx >= 0) {
                ref
                    .read(playerServiceProvider)
                    .setQueue(downloaded, startIndex: idx);
              }
            }
          : null,
    );
  }
}
