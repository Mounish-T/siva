import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/services/download_service.dart';
import '../../core/services/providers.dart';
import '../../core/theme/app_theme.dart';
import '../../widgets/track_tile.dart';
import '../downloads/downloads_screen.dart';
import '../playlists/playlists_screen.dart';
import '../profile/profile_screen.dart';

class LibraryScreen extends ConsumerWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favorites = ref.watch(favoritesProvider);
    final playlists = ref.watch(playlistsProvider);
    final recent = ref.watch(recentlyPlayedProvider);
    final downloads = ref.watch(downloadsProvider).valueOrNull ?? const [];
    final completedDownloads = downloads
        .where((e) => e.status == DownloadStatus.completed)
        .length;

    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: false,
            floating: true,
            backgroundColor: Colors.transparent,
            elevation: 0,
            title: const Text('Your Library',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
            actions: [
              IconButton(
                icon: const Icon(Icons.account_circle_outlined),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ProfileScreen()),
                ),
              ),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Column(
                children: [
                  _LibraryRow(
                    icon: Icons.favorite,
                    title: 'Liked songs',
                    subtitle:
                        '${favorites.length} track${favorites.length == 1 ? '' : 's'}',
                    gradient: const [Color(0xFF4A60D9), Color(0xFFB3D6FF)],
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const _LikedScreen()),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _LibraryRow(
                    icon: Icons.queue_music,
                    title: 'Your playlists',
                    subtitle:
                        '${playlists.length} playlist${playlists.length == 1 ? '' : 's'}',
                    gradient: const [Color(0xFF7E22CE), Color(0xFFC026D3)],
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const PlaylistsListScreen()),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _LibraryRow(
                    icon: Icons.download_done,
                    title: 'Downloads',
                    subtitle:
                        '$completedDownloads track${completedDownloads == 1 ? '' : 's'}',
                    gradient: const [Color(0xFF065F46), Color(0xFF10B981)],
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const DownloadsScreen()),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (recent.isNotEmpty) ...[
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 24, 16, 12),
                child: Text(
                  'Recently played',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                ),
              ),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (_, i) =>
                    TrackTile(track: recent[i], queue: recent, index: i),
                childCount: recent.length.clamp(0, 20),
              ),
            ),
          ],
          const SliverToBoxAdapter(child: SizedBox(height: 80)),
        ],
      ),
    );
  }
}

class _LibraryRow extends StatelessWidget {
  const _LibraryRow({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });
  final IconData icon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppTheme.surfaceElevated,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: gradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Icon(icon, color: Colors.white, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style:
                          const TextStyle(fontWeight: FontWeight.w600)),
                  Text(
                    subtitle,
                    style: const TextStyle(
                        color: AppTheme.textSecondary, fontSize: 12),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: AppTheme.textSecondary),
          ],
        ),
      ),
    );
  }
}

class _LikedScreen extends ConsumerWidget {
  const _LikedScreen();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favorites = ref.watch(favoritesProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Liked songs',
            style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          if (favorites.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.play_arrow),
              onPressed: () =>
                  ref.read(playerServiceProvider).setQueue(favorites),
            ),
        ],
      ),
      body: favorites.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'No favorites yet.\nTap the heart on any track to save it here.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: AppTheme.textSecondary, height: 1.5),
                ),
              ),
            )
          : ListView.builder(
              itemCount: favorites.length,
              itemBuilder: (_, i) => TrackTile(
                track: favorites[i],
                queue: favorites,
                index: i,
              ),
            ),
    );
  }
}
