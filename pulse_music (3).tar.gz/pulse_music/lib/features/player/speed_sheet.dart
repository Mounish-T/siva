import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/services/providers.dart';
import '../../core/theme/app_theme.dart';

Future<void> showSpeedSheet(BuildContext context, WidgetRef ref) async {
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppTheme.surfaceElevated,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
    ),
    builder: (sheetCtx) => Consumer(builder: (_, sheetRef, __) {
      final current = sheetRef.watch(speedProvider).valueOrNull ?? 1.0;
      const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];

      return SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Playback speed',
                  style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              for (final s in speeds)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(
                    s == current
                        ? Icons.radio_button_checked
                        : Icons.radio_button_unchecked,
                    color: s == current
                        ? AppTheme.brand
                        : AppTheme.textSecondary,
                  ),
                  title: Text(s == 1.0 ? 'Normal (1x)' : '${s}x'),
                  onTap: () {
                    sheetRef.read(playerServiceProvider).setSpeed(s);
                    Navigator.pop(sheetCtx);
                  },
                ),
            ],
          ),
        ),
      );
    }),
  );
}
