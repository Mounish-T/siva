import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/services/providers.dart';
import '../../core/theme/app_theme.dart';

Future<void> showSleepTimerSheet(BuildContext context, WidgetRef ref) async {
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppTheme.surfaceElevated,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
    ),
    builder: (sheetCtx) => Consumer(builder: (_, sheetRef, __) {
      final remaining =
          sheetRef.watch(sleepTimerRemainingProvider).valueOrNull;
      final timer = sheetRef.read(sleepTimerProvider);

      const options = [
        ('5 minutes', Duration(minutes: 5)),
        ('15 minutes', Duration(minutes: 15)),
        ('30 minutes', Duration(minutes: 30)),
        ('45 minutes', Duration(minutes: 45)),
        ('1 hour', Duration(hours: 1)),
      ];

      return SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Sleep timer',
                  style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              if (remaining != null) ...[
                const SizedBox(height: 8),
                Text(
                  'Stops in ${remaining.inMinutes}m ${remaining.inSeconds.remainder(60)}s',
                  style:
                      const TextStyle(color: AppTheme.brand, fontSize: 13),
                ),
              ],
              const SizedBox(height: 12),
              for (final o in options)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.timer_outlined),
                  title: Text(o.$1),
                  onTap: () {
                    timer.start(o.$2);
                    Navigator.pop(sheetCtx);
                  },
                ),
              if (remaining != null)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.close, color: Colors.redAccent),
                  title: const Text('Cancel timer',
                      style: TextStyle(color: Colors.redAccent)),
                  onTap: () {
                    timer.cancel();
                    Navigator.pop(sheetCtx);
                  },
                ),
            ],
          ),
        ),
      );
    }),
  );
}
