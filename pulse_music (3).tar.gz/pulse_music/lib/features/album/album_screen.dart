import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/services/dynamic_colors.dart';
import '../../core/services/providers.dart';
import '../../core/theme/app_theme.dart';
import '../../widgets/skeletons.dart';
import '../../widgets/track_tile.dart';

class AlbumScreen extends ConsumerStatefulWidget {
  const AlbumScreen({
    super.key,
    required this.albumId,
    required this.albumName,
    required this.artistName,
    required this.imageUrl,
  });

  final String albumId;
  final String albumName;
  final String artistName;
  final String imageUrl;

  @override
  ConsumerState<AlbumScreen> createState() => _AlbumScreenState();
}

class _AlbumScreenState extends ConsumerState<AlbumScreen> {
  Color _gradient = AppTheme.surface;

  @override
  void initState() {
    super.initState();
    DynamicColors.dominantFrom(widget.imageUrl).then((c) {
      if (mounted) setState(() => _gradient = c);
    });
  }

  @override
  Widget build(BuildContext context) {
    final tracks = ref.watch(albumTracksProvider(widget.albumId));

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 320,
            pinned: true,
            backgroundColor: _gradient,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                widget.albumName,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [_gradient, AppTheme.background],
                  ),
                ),
                child: SafeArea(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 56, bottom: 56),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: SizedBox(
                              width: 180,
                              height: 180,
                              child: widget.imageUrl.isEmpty
                                  ? Container(color: AppTheme.surfaceElevated)
                                  : CachedNetworkImage(
                                      imageUrl: widget.imageUrl,
                                      fit: BoxFit.cover,
                                      errorWidget: (_, __, ___) => Container(
                                          color: AppTheme.surfaceElevated),
                                    ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            widget.artistName,
                            style: const TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          tracks.when(
            loading: () => const SliverToBoxAdapter(child: TrackTileSkeletonList()),
            error: (e, _) => SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(e.toString(),
                    style: const TextStyle(color: Colors.redAccent)),
              ),
            ),
            data: (list) => SliverList(
              delegate: SliverChildBuilderDelegate(
                (_, i) => TrackTile(track: list[i], queue: list, index: i),
                childCount: list.length,
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 80)),
        ],
      ),
    );
  }
}
