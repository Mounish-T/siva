import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/models/track.dart';
import '../../core/services/providers.dart';
import '../../core/theme/app_theme.dart';

/// Bottom sheet for adding a track to one of the user's playlists.
///
/// Lives in its own file so widgets (like TrackTile) can call it without
/// importing the full playlists_screen.dart, which would create a circular
/// import (playlists_screen needs TrackTile to render its track rows).
Future<void> showAddToPlaylistSheet(
  BuildContext context,
  WidgetRef ref,
  Track track,
) async {
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppTheme.surfaceElevated,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
    ),
    builder: (sheetCtx) {
      return Consumer(builder: (_, sheetRef, __) {
        final lists = sheetRef.watch(playlistsProvider);
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Add to playlist',
                    style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w700)),
                const SizedBox(height: 12),
                if (lists.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Text(
                      'No playlists yet. Create one from the Library tab first.',
                      style: TextStyle(color: AppTheme.textSecondary),
                    ),
                  )
                else
                  ConstrainedBox(
                    constraints: BoxConstraints(
                      maxHeight: MediaQuery.of(sheetCtx).size.height * 0.5,
                    ),
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: lists.length,
                      itemBuilder: (_, i) {
                        final p = lists[i];
                        return ListTile(
                          leading: const Icon(Icons.queue_music),
                          title: Text(p.name),
                          subtitle: Text('${p.tracks.length} tracks',
                              style: const TextStyle(
                                  color: AppTheme.textSecondary,
                                  fontSize: 12)),
                          onTap: () async {
                            await sheetRef
                                .read(playlistsProvider.notifier)
                                .addTrack(p.id, track);
                            if (sheetCtx.mounted) Navigator.pop(sheetCtx);
                          },
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
        );
      });
    },
  );
}
