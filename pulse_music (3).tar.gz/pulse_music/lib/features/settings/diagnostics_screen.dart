import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/services/diagnostics_service.dart';
import '../../core/services/self_check_service.dart';
import '../../core/theme/app_theme.dart';

class DiagnosticsScreen extends ConsumerStatefulWidget {
  const DiagnosticsScreen({super.key});

  @override
  ConsumerState<DiagnosticsScreen> createState() => _DiagnosticsScreenState();
}

class _DiagnosticsScreenState extends ConsumerState<DiagnosticsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Diagnostics',
            style: TextStyle(fontWeight: FontWeight.w700)),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.brand,
          labelColor: AppTheme.brand,
          unselectedLabelColor: AppTheme.textSecondary,
          tabs: const [
            Tab(text: 'Self-check'),
            Tab(text: 'Logs'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          _SelfCheckTab(),
          _LogsTab(),
        ],
      ),
    );
  }
}

// ============================================================
// SELF-CHECK TAB
// ============================================================

class _SelfCheckTab extends StatefulWidget {
  const _SelfCheckTab();

  @override
  State<_SelfCheckTab> createState() => _SelfCheckTabState();
}

class _SelfCheckTabState extends State<_SelfCheckTab> {
  List<CheckResult> _results = const [];
  bool _running = false;

  Future<void> _start() async {
    setState(() {
      _running = true;
      _results = const [];
    });
    await for (final batch in SelfCheckService.instance.run()) {
      if (!mounted) return;
      setState(() => _results = batch);
    }
    if (mounted) setState(() => _running = false);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.surfaceElevated,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Text(
              'Runs real probes against Jamendo, Supabase, the audio player, '
              'and local storage. Use this to confirm a build is working '
              'end-to-end on this device.',
              style:
                  TextStyle(color: AppTheme.textSecondary, fontSize: 13),
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _running ? null : _start,
            icon: _running
                ? const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.black),
                  )
                : const Icon(Icons.play_arrow, size: 18),
            label: Text(_running ? 'Running…' : 'Run self-check'),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: _results.isEmpty
                ? const Center(
                    child: Text(
                      'No results yet. Tap "Run self-check" above.',
                      style: TextStyle(color: AppTheme.textSecondary),
                    ),
                  )
                : ListView.separated(
                    itemCount: _results.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 4),
                    itemBuilder: (_, i) => _CheckRow(result: _results[i]),
                  ),
          ),
        ],
      ),
    );
  }
}

class _CheckRow extends StatelessWidget {
  const _CheckRow({required this.result});
  final CheckResult result;

  ({Color color, IconData icon, String label}) _style() {
    switch (result.status) {
      case CheckStatus.pending:
        return (
          color: AppTheme.textSecondary,
          icon: Icons.radio_button_unchecked,
          label: 'Pending'
        );
      case CheckStatus.running:
        return (
          color: Colors.amberAccent,
          icon: Icons.refresh,
          label: 'Running'
        );
      case CheckStatus.pass:
        return (
          color: AppTheme.brand,
          icon: Icons.check_circle,
          label: 'Pass'
        );
      case CheckStatus.fail:
        return (color: Colors.redAccent, icon: Icons.error, label: 'Fail');
      case CheckStatus.skip:
        return (
          color: AppTheme.textSecondary,
          icon: Icons.remove_circle_outline,
          label: 'Skip'
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = _style();
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.surfaceElevated,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(s.icon, color: s.color, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(result.label,
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                if (result.detail != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    result.detail!,
                    style: const TextStyle(
                        color: AppTheme.textSecondary, fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
          Text(s.label,
              style: TextStyle(
                  color: s.color, fontSize: 12, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

// ============================================================
// LOGS TAB
// ============================================================

class _LogsTab extends StatefulWidget {
  const _LogsTab();

  @override
  State<_LogsTab> createState() => _LogsTabState();
}

class _LogsTabState extends State<_LogsTab> {
  late List<LogEntry> _entries;
  late final Stream<LogEntry> _stream;
  bool _autoScroll = true;
  final ScrollController _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    _entries = DiagnosticsService.instance.snapshot();
    _stream = DiagnosticsService.instance.stream;
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  void _copyAll() {
    final text =
        _entries.map((e) => e.formatted).join('\n');
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Logs copied to clipboard')),
    );
  }

  Color _colorFor(LogLevel level) {
    switch (level) {
      case LogLevel.debug:
        return AppTheme.textSecondary;
      case LogLevel.info:
        return AppTheme.textPrimary;
      case LogLevel.warn:
        return Colors.amberAccent;
      case LogLevel.error:
        return Colors.redAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<LogEntry>(
      stream: _stream,
      builder: (context, snapshot) {
        // Whenever the stream emits, re-read the snapshot so we get
        // the buffer in the right order (including evictions).
        _entries = DiagnosticsService.instance.snapshot();
        if (_autoScroll && _scroll.hasClients) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (_scroll.hasClients) {
              _scroll.jumpTo(_scroll.position.maxScrollExtent);
            }
          });
        }
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Row(
                children: [
                  Text('${_entries.length} entries',
                      style: const TextStyle(
                          color: AppTheme.textSecondary, fontSize: 12)),
                  const Spacer(),
                  IconButton(
                    icon: Icon(
                      _autoScroll
                          ? Icons.vertical_align_bottom
                          : Icons.vertical_align_center,
                      color: _autoScroll
                          ? AppTheme.brand
                          : AppTheme.textSecondary,
                      size: 20,
                    ),
                    tooltip: 'Auto-scroll',
                    onPressed: () =>
                        setState(() => _autoScroll = !_autoScroll),
                  ),
                  IconButton(
                    icon: const Icon(Icons.copy, size: 20),
                    tooltip: 'Copy all',
                    onPressed: _entries.isEmpty ? null : _copyAll,
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, size: 20),
                    tooltip: 'Clear',
                    onPressed: () {
                      DiagnosticsService.instance.clear();
                      setState(() {});
                    },
                  ),
                ],
              ),
            ),
            Expanded(
              child: _entries.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(32),
                        child: Text(
                          'No logs yet. Use the app — playing a track, '
                          'searching, etc. — and entries will appear here.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: AppTheme.textSecondary, height: 1.5),
                        ),
                      ),
                    )
                  : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      itemCount: _entries.length,
                      itemBuilder: (_, i) {
                        final e = _entries[i];
                        return Padding(
                          padding:
                              const EdgeInsets.symmetric(vertical: 2),
                          child: SelectableText(
                            e.formatted,
                            style: TextStyle(
                              fontFamily: 'monospace',
                              fontSize: 11,
                              color: _colorFor(e.level),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        );
      },
    );
  }
}
