import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/config/app_config.dart';
import '../../core/services/providers.dart';
import '../../core/theme/app_theme.dart';
import 'diagnostics_screen.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authServiceProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings',
            style: TextStyle(fontWeight: FontWeight.w700)),
      ),
      body: ListView(
        children: [
          const _SectionHeader('Account'),
          if (auth.isSignedIn) ...[
            ListTile(
              leading: const Icon(Icons.person_outline),
              title: const Text('Signed in as'),
              subtitle: Text(auth.currentUser?.email ?? 'Unknown'),
            ),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.redAccent),
              title: const Text('Sign out',
                  style: TextStyle(color: Colors.redAccent)),
              onTap: () => auth.signOut(),
            ),
          ] else
            const ListTile(
              leading: Icon(Icons.info_outline),
              title: Text('Not signed in'),
              subtitle: Text('Favorites are stored locally only.'),
            ),
          const _SectionHeader('About'),
          const ListTile(
            leading: Icon(Icons.music_note),
            title: Text('Music source'),
            subtitle: Text('Jamendo - Creative Commons indie music'),
          ),
          ListTile(
            leading: const Icon(Icons.code),
            title: const Text('Backend'),
            subtitle: Text(
              AppConfig.supabaseConfigured
                  ? 'Supabase (configured)'
                  : 'Local-only (Supabase not configured)',
            ),
          ),
          const ListTile(
            leading: Icon(Icons.info),
            title: Text('Version'),
            subtitle: Text('Pulse Music 0.1.0'),
          ),
          if (AppConfig.diagnosticsEnabled) ...[
            const _SectionHeader('Developer'),
            ListTile(
              leading:
                  const Icon(Icons.bug_report, color: AppTheme.brand),
              title: const Text('Diagnostics'),
              subtitle: const Text('Logs and self-check probes',
                  style: TextStyle(fontSize: 12)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const DiagnosticsScreen()),
              ),
            ),
            const ListTile(
              leading:
                  Icon(Icons.warning_amber, color: AppTheme.textSecondary),
              title: Text('Diagnostics mode',
                  style: TextStyle(fontSize: 14)),
              subtitle: Text(
                  'This build was compiled with PULSE_DIAGNOSTICS=true. '
                  'Verbose logging is on. Build without the flag for a quiet release.',
                  style: TextStyle(
                      color: AppTheme.textSecondary, fontSize: 11)),
            ),
          ],
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        label.toUpperCase(),
        style: const TextStyle(
          color: AppTheme.brand,
          fontWeight: FontWeight.w700,
          fontSize: 12,
          letterSpacing: 1,
        ),
      ),
    );
  }
}
