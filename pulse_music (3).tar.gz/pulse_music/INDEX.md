# Pulse Music — Project index

This file is a map of the entire project, summarizing what was built across the conversation that produced it. If you're opening this archive fresh, read this first.

---

## What this project is

A free, open-source Android music streaming app built in Flutter. Powered by:
- **Jamendo API** — Creative Commons indie music (legal, free with a client_id)
- **Supabase** (optional) — auth + Postgres for user accounts
- **just_audio + just_audio_background** — gapless playback, lock-screen controls
- **Cloudflare Workers** (optional) — edge caching for resilience

Important: this is **not** a Spotify clone with mainstream music. Jamendo's catalog is independent artists releasing under Creative Commons. Mainstream copyrighted streaming requires licensing deals that cost millions per year and is genuinely not possible on free infrastructure.

---

## Documentation (read in this order)

| File | When to read it |
|---|---|
| **`INDEX.md`** | This file — start here |
| **`GETTING_STARTED.md`** | First time setup — non-technical, step-by-step with checkpoints |
| **`README.md`** | Project overview and setup commands |
| **`BUILD.md`** | Phase-by-phase build walkthrough, every error and fix |
| **`DIAGNOSTICS.md`** | Two build modes (normal vs diagnostic), how to verify your build works |
| **`STATUS.md`** | Final coverage of the original spec, what's in / not in / why |

If you just want to build the APK and run it, read `GETTING_STARTED.md` only.
If something breaks, look in `BUILD.md`.
If you want to verify your build is correct, follow the diagnostic-mode workflow in `DIAGNOSTICS.md`.

---

## How this project was built — conversation summary

The full project was created across multiple turns in a conversation. Here's what happened in each major phase:

### Initial scoping
The original request was an extremely large master prompt asking for a complete production-ready Spotify-style app. The honest scoping response was: a one-shot fake of that scale will produce non-compiling fiction. Instead I committed to ship a real, working foundation that could be extended in batches.

### Batch 1 — Foundation (30 files)
- Project scaffold: Flutter config, Android Gradle setup, manifest with audio permissions, ProGuard rules
- Core services: `JamendoService` (API client), `PlayerService` (just_audio wrapper with queue/shuffle/loop), `AuthService` (Supabase)
- Models: `Track`, with `fromJamendo` factory mapping real API fields
- Riverpod providers for everything
- Screens: Onboarding, Login, Home, Search, Library, Player, Mini-player
- Dark Material 3 theme
- Supabase SQL schema with row-level security

### Batch 1.5 — Library + Discovery additions (47 files)
- `LibraryService` with Supabase + local cache fallback (so the app works offline)
- Persistent favorites
- Full playlist CRUD: create, rename, delete, add/remove tracks
- Recently played tracking
- Recommendation engine: Daily / Chill / Workout / Focus / Trending mix carousels
- Album, Artist, Queue screens
- Sleep timer
- Dynamic color extraction from album art
- Onboarding flow, Settings, Profile screens
- Skeleton loaders

### Batch 2 — Offline + Infrastructure (54 files)
- `DownloadService` — Dio-based downloader (more reliable than `flutter_downloader` for this use case)
- Downloads screen with progress, cancel, retry, delete
- Player automatically prefers local file when track is downloaded → full offline playback
- Google Sign-In via Supabase
- Forgot password flow
- Playback speed control (0.5x – 2x)
- GitHub Actions workflow for auto-building APKs on push
- Cloudflare Worker for caching Jamendo responses (free tier, optional)

### Batch 3 — Audit and wrap-up (57 files)
- Fixed a circular import between `track_tile.dart` and `playlists_screen.dart`
- Fixed a real UX bug: Recently Played wasn't refreshing when tracks played → added a broadcast stream from `LibraryService` that the provider subscribes to
- Fixed `downloadsProvider` flashing empty on first render
- `BUILD.md` and `STATUS.md` written

### Final batch — Diagnostics mode (60 files)
- `DiagnosticsService` — 500-entry ring buffer + broadcast stream + level-aware logging. Zero overhead when disabled.
- `SelfCheckService` — 7 real runtime probes (config, network, Jamendo, Supabase, auth, player, downloads dir)
- `DiagnosticsScreen` — two-tab UI (self-check + live logs) accessible from Settings → Developer
- Instrumented all major services to emit logs when diagnostics flag is on
- Controlled by `--dart-define=PULSE_DIAGNOSTICS=true` at build time

---

## What's in the codebase

```
pulse_music/
├── INDEX.md              # This file
├── README.md             # Overview + build commands
├── GETTING_STARTED.md    # Non-technical step-by-step guide
├── BUILD.md              # Detailed build walkthrough + troubleshooting
├── DIAGNOSTICS.md        # Normal vs diagnostic mode
├── STATUS.md             # Final coverage of original spec
├── pubspec.yaml          # Dart dependencies (16 packages)
├── supabase_schema.sql   # Database schema with RLS policies
├── analysis_options.yaml # Dart linter rules
│
├── android/              # Android Gradle config, manifest, ProGuard rules
│
├── .github/workflows/
│   └── build.yml         # CI: build APK on push, attach to releases on tag
│
├── cloudflare_worker/    # Optional edge cache
│   ├── worker.js
│   ├── wrangler.toml
│   └── README.md
│
└── lib/                  # Flutter source (38 files, ~5,800 lines)
    ├── main.dart
    │
    ├── core/
    │   ├── config/
    │   │   └── app_config.dart           # Compile-time env vars
    │   ├── theme/
    │   │   └── app_theme.dart            # Dark Material 3
    │   ├── models/
    │   │   ├── track.dart
    │   │   └── album.dart                # Album + Artist
    │   └── services/
    │       ├── jamendo_service.dart      # API client
    │       ├── player_service.dart       # just_audio wrapper
    │       ├── auth_service.dart         # Supabase + Google OAuth
    │       ├── library_service.dart      # Favorites + playlists + recents
    │       ├── download_service.dart     # Offline downloads
    │       ├── recommendation_service.dart
    │       ├── sleep_timer.dart
    │       ├── dynamic_colors.dart       # palette_generator wrapper
    │       ├── local_cache.dart          # SharedPreferences
    │       ├── diagnostics_service.dart  # In-app log buffer
    │       ├── self_check_service.dart   # Runtime verification
    │       └── providers.dart            # All Riverpod providers
    │
    ├── features/
    │   ├── auth/login_screen.dart
    │   ├── onboarding/onboarding_screen.dart
    │   ├── home/
    │   │   ├── home_screen.dart
    │   │   └── shell_screen.dart
    │   ├── search/search_screen.dart
    │   ├── library/library_screen.dart
    │   ├── playlists/
    │   │   ├── playlists_screen.dart
    │   │   └── add_to_playlist_sheet.dart
    │   ├── downloads/downloads_screen.dart
    │   ├── recommendations/mix_screen.dart
    │   ├── album/album_screen.dart
    │   ├── artist/artist_screen.dart
    │   ├── queue/queue_screen.dart
    │   ├── player/
    │   │   ├── player_screen.dart
    │   │   ├── sleep_timer_sheet.dart
    │   │   └── speed_sheet.dart
    │   ├── profile/profile_screen.dart
    │   └── settings/
    │       ├── settings_screen.dart
    │       └── diagnostics_screen.dart   # Hidden unless PULSE_DIAGNOSTICS=true
    │
    └── widgets/
        ├── track_tile.dart
        ├── mini_player.dart
        └── skeletons.dart
```

---

## Quick start

```bash
# Extract
tar xzf pulse_music.tar.gz
cd pulse_music

# Regenerate Android boilerplate (gradle wrapper, etc.)
flutter create --org com.pulse --project-name pulse_music --platforms=android .

# Get dependencies
flutter pub get

# Get a free Jamendo client_id from https://devportal.jamendo.com
# Then build with diagnostics so you can verify it works:
flutter build apk --release \
  --dart-define=JAMENDO_CLIENT_ID=your_client_id \
  --dart-define=PULSE_DIAGNOSTICS=true

# Install on phone
adb install build/app/outputs/flutter-apk/app-release.apk

# Open the app → Settings → Developer → Diagnostics → "Run self-check"
# Everything should be green (or skipped for optional services)

# Once verified, rebuild without the diagnostics flag for daily use.
```

If anything breaks, `BUILD.md` has phase-by-phase troubleshooting for every error I could anticipate.

---

## License

The project's own source code can be used however you want. The dependencies have their own licenses:
- **Flutter, Dart** — BSD
- **just_audio family** — MIT
- **Supabase Flutter SDK** — MIT
- **Jamendo content** — varies per track (mostly CC BY, CC BY-SA, CC BY-NC). You're responsible for respecting each track's license if you publish derivative works.

---

## What this archive contains vs the conversation

This archive contains **every file generated** during the project's creation. The text of the conversation itself (the back-and-forth messages, scoping discussions, my honest pushback about what's possible) is **not** in this archive — Claude has no way to export its own chat history. To save the conversation:

- **Claude.ai / Claude app**: Look for the "Share" or "Export" option in the chat menu (usually top-right or "..."). The exact location depends on your version of the interface.
- **Manually**: Scroll up, select all the text in the conversation, paste into a document.

The conversation itself contains useful context — scoping decisions, why certain features were left out, why certain packages were swapped — that the code alone doesn't explain. The docs in this archive (`STATUS.md` especially) capture the most important reasoning, but the live conversation has more nuance if you can save it.
