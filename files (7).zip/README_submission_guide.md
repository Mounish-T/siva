# Submission Package — *Journal of Engineering Design* (Taylor & Francis)

This folder contains the resubmission package for

> **A Self-Adaptive Parallelogram-Linkage Brush Mechanism for Automated Cleaning of Large-Diameter Industrial Cooking Vessels**

after the desk rejection from Elsevier's *Mechanism and Machine Theory*.

The target is now **Journal of Engineering Design (JED)**, Taylor & Francis. JED is hybrid open-access — **publishing on the subscription route costs you nothing** (the paper sits behind a paywall; you can share the accepted manuscript on ResearchGate after acceptance). Only choose the gold open-access route if you want to pay an APC.

---

## 1. What's in this package

```
JED_Submission_Package/
├── README_submission_guide.md          ← this file
├── build/
│   ├── content.js                       ← all editable text
│   └── build_submission.js              ← regenerator
└── out/
    ├── 01_Cover_Letter.docx
    ├── 02_Title_Page.docx              ← author details + anonymised-citation key
    ├── 03_Manuscript.docx              ← FULLY ANONYMISED (double-blind ready)
    ├── 04_Figures_List_and_Naming_Convention.docx
    ├── 05_Statements_and_Disclosures.docx   ← non-anonymous, held aside by editor
    ├── Fig_18.pdf / .png                ← kinematic plots (auto-generated)
    ├── Fig_19.pdf / .png
    └── Graphical_Abstract.pdf / .png    ← optional
```

---

## 2. ⚠ Key things that changed from the MMT package

The MMT package was rejected at desk on scope. The repackage for JED implements JED's structural and formatting requirements, which differ from Elsevier's in important ways:

| Item | MMT (old) | JED (new) |
|---|---|---|
| Peer review | Single-anonymized | **Double-anonymized** — manuscript shows no author info, no acknowledgements, no self-disclosing references |
| References | Numeric `[1]` | **Harvard / author-year** `(Sivaraman et al., 2026)` |
| Body line spacing | 1.5 | **Double** (T&F house style) |
| Self-citation | `[1]` | `[Authors] (2026)` placeholder + full citation given in Title Page only |
| Patent disclosure in manuscript | Yes | **Removed** from manuscript; moved to Statements file |
| CRediT / COI / Funding | In manuscript | **Moved out** to separate Statements file |
| Highlights | Required | **Not required** |
| Acknowledgements | At end of manuscript | **Removed** (would identify authors); moved to Statements file |

The most important change: **the manuscript file you upload as "Manuscript" must contain nothing that identifies the authors**. This package handles that automatically — the `[Authors]` placeholder is used for all self-citations and an "Anonymised citation key (for the Editor only)" at the bottom of the Title Page tells the editor what `[Authors] (2026)` resolves to.

---

## 3. The JED submission portal — step by step

The portal is at:
**https://rp.tandfonline.com/submission/create?journalCode=CJEN**

You'll need a separate Taylor & Francis Submission Portal account (it's not the same as a Taylor & Francis Online account — register one if needed).

### Submission walkthrough

1. **Register / log in** to the T&F Submission Portal.

2. **Start new submission** → select **Journal of Engineering Design**.

3. **Article type** → choose **"Original Article"** (or "Research Article" — whichever appears in the dropdown).

4. **Title and abstract** — paste from the Title Page / Manuscript.

5. **Add all four authors** to the portal. Mark Sivaraman M. as corresponding. Include each author's institutional email — the portal sends them a co-authorship confirmation email which they must click within a week or so.

6. **Keywords** — six keywords (Parallelogram four-bar linkage; Self-adaptive mechanism; Industrial cleaning; Kinematic analysis; Lead-screw lift; Commercial kitchen hygiene).

7. **Upload files**:

   | Portal item type | Upload this file |
   |---|---|
   | Manuscript — with author details | (none — JED uses double-blind, so use only the anonymised file) |
   | Manuscript — anonymised | `03_Manuscript.docx` |
   | Title page | `02_Title_Page.docx` |
   | Cover letter | `01_Cover_Letter.docx` |
   | Disclosure / declarations | `05_Statements_and_Disclosures.docx` |
   | Figure | each of `Fig_01.*` … `Fig_19.*` (separate uploads) |
   | Graphical abstract (optional) | `Graphical_Abstract.png` |

   (If the portal shows different category names, pick the closest match — the underlying content is what matters.)

8. **Declarations checkbox stage** — the portal asks you to confirm:
   - Work is original and not under consideration elsewhere
   - All co-authors have approved
   - Competing interests disclosed (yes — the patent)
   - AI tools disclosed (yes — Claude was used for manuscript prep)

9. **Choose publication route**: when asked "publish open access?", choose **"No — publish on subscription route"**. This makes the article free for you. (You can change your mind later if accepted.)

10. **Review the PDF the portal builds** for the reviewers. Confirm: no author names visible, no acknowledgements visible, no institutional names, no patent disclosure. If anything author-identifying leaks through, fix it before final submission.

11. **Submit**. You'll receive an automated confirmation email with a manuscript number (something like `CJEN-XXXX-2026`). Save it.

### Timeline

- Editor desk review: 1–4 weeks
- Peer review: 8–12 weeks for first decision
- Total to acceptance (if accepted): typically 4–8 months

---

## 4. Pre-submission checklist

- [ ] All 19 figure files created from SolidWorks (only Figs 18 and 19 are provided; Figs 1–17 are on you)
- [ ] Anonymisation verified — open `03_Manuscript.docx` and search for "Sivaraman", "Sairam", "Chennai", "Tamil Nadu", "present authors" — should find ZERO matches
- [ ] Co-authors have seen and approved the package
- [ ] You've checked the T&F Submission Portal account works
- [ ] You've confirmed the Gmail address you registered with is one you check daily
- [ ] The patent disclosure in `05_Statements_and_Disclosures.docx` matches what's in your portal-side disclosure form

---

## 5. After submission

- Add the new manuscript number to your records
- Decline the leftover Elsevier MMT transfer offer (it stops the reminder emails)
- Upload the preprint version to **ResearchGate** so the work is findable while it's in review (T&F's policy allows the submitted manuscript on personal pages and ResearchGate from day one)
- Create an **ORCID iD** for each author if you haven't yet (https://orcid.org, free, 2 min)

---

## 6. How to rebuild

Same as before — everything in `build/content.js` is editable, then:

```bash
cd build
node build_submission.js
```

Needs Node ≥18 and the `docx` package.

---

## 7. If you later want to add a different journal

The `content.js` file separates content from formatting. To target a different journal, you mainly edit:

- `meta.journal` and `meta.journalEditor`
- The reference list format (Harvard vs. numeric vs. Vancouver) — done in `build_submission.js` near the references section

Most of the content (sections, figures, captions, table data) stays the same.

Good luck — JED is a better natural home for this paper than MMT was.
