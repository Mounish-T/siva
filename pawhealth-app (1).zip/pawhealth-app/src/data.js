// src/data.js — pets, pillars, goals, reactions, and the mood engine.
// This is the "soul" of PawHealth: a 0–100 wellness score maps to 7 pet moods,
// and the resilience model means streaks rest, never break.

export const PETS = [
  { key: "cat",   emoji: "🐱", name: "Cat",   archetype: "Elegant & independent — aloof, but loves you fiercely.", hello: "Oh… it's you. *slow blink* I'm glad. Stay a while?" },
  { key: "dog",   emoji: "🐶", name: "Dog",   archetype: "Loyal & sunny — believes in you, unconditionally.",       hello: "YOU'RE HERE!! Best day already. Okay — what first?!" },
  { key: "bunny", emoji: "🐰", name: "Bunny", archetype: "Shy & gentle — quietly blooms with your consistency.",     hello: "*peeks out* …hi. I was hoping you'd come today." },
  { key: "panda", emoji: "🐼", name: "Panda", archetype: "Sleepy foodie — pure, soft comfort energy.",                hello: "*yaaawn* mmm, you're back. Snacks? Naps? …both?" },
  { key: "fox",   emoji: "🦊", name: "Fox",   archetype: "Clever & playful — a little bit mischievous.",              hello: "Knew you'd show up. Ready to outsmart today, together?" },
];

export const PILLARS = {
  hydration: { label: "Hydration",   icon: "💧", tint: "#3FB6E0" },
  movement:  { label: "Movement",    icon: "🏃", tint: "#FF8A5B" },
  mind:      { label: "Mind",        icon: "🧠", tint: "#A78BFA" },
  nourish:   { label: "Nourishment", icon: "🥗", tint: "#34C77B" },
  sleep:     { label: "Sleep",       icon: "🌙", tint: "#7C83FF" },
  cycle:     { label: "Cycle & Body", icon: "🌸", tint: "#FF6B9D" },
};
export const PILLAR_KEYS = Object.keys(PILLARS);

// Built-in starter goals. Custom activities (user-made) are stored separately.
export const BASE_GOALS = [
  { id: "g_water",  pillar: "hydration", title: "Drink 8 glasses of water", diff: "Easy",   coins: 5,  reaction: "drink" },
  { id: "g_yoga",   pillar: "movement",  title: "20-min yoga flow",         diff: "Medium", coins: 10, reaction: "yoga" },
  { id: "g_med",    pillar: "mind",      title: "5-min meditation",         diff: "Easy",   coins: 5,  reaction: "meditate" },
  { id: "g_journal",pillar: "mind",      title: "Journal 3 gratitudes",     diff: "Easy",   coins: 5,  reaction: "journal" },
  { id: "g_rest",   pillar: "cycle",     title: "Rest day — honour your body", diff: "Easy", coins: 10, reaction: "nap", rest: true },
];

export const REACTIONS = {
  drink:    { line: "Slurp slurp — thank you! 💧",            fx: "🥣" },
  yoga:     { line: "Stretchyyy~ I feel so good 🧘",          fx: "🧘" },
  run:      { line: "Zoomies!! Let's gooo 🏃💨",              fx: "💨" },
  cycle:    { line: "Wheee, wind in my fur! 🚲",              fx: "🚲" },
  walk:     { line: "A little stroll together 🐾",            fx: "🐾" },
  meditate: { line: "Breathing in… and out… so peaceful 🌬️", fx: "🕊️" },
  journal:  { line: "Ooh, tell me everything 📖✨",           fx: "📖" },
  nap:      { line: "Resting is caring too 😴 I'm proud of you.", fx: "💤" },
  custom:   { line: "We did the thing! That counts 🌟",       fx: "✨" },
  pet:      { line: "I love spending time with you 💕",        fx: "💕" },
};

export function getMood(w) {
  if (w >= 85) return { key: "radiant", label: "Radiant", badge: "✨",
    lines: ["You're glowing — and honestly, so am I! ✨", "I feel SO alive when we're like this 💫", "Look at us, thriving together."] };
  if (w >= 70) return { key: "happy", label: "Happy", badge: "😊",
    lines: ["Today's been a good day together 💛", "I'm really happy right now.", "Just us, taking care of things. Nice."] };
  if (w >= 55) return { key: "cozy", label: "Cozy", badge: "🙂",
    lines: ["I'm right here with you. How are we feeling?", "No rush today — we've got time.", "Whatever you've got in you is enough."] };
  if (w >= 40) return { key: "sleepy", label: "Sleepy", badge: "😴",
    lines: ["I'm a little tired… want to rest together?", "Mmm, slow morning. That's okay.", "One small thing, then we cuddle?"] };
  if (w >= 25) return { key: "sad", label: "Missing you", badge: "🥺",
    lines: ["I miss our little things… one tiny step?", "No pressure — I just like being near you.", "Even a glass of water would make me smile."] };
  if (w >= 10) return { key: "unwell", label: "Under the weather", badge: "🤒",
    lines: ["Let's just do one small thing today, okay?", "I'm alright — I just need you close.", "Tiny steps count double right now."] };
  return { key: "dormant", label: "Resting", badge: "💤",
    lines: ["I'm resting until you're ready. I'm not going anywhere 💤", "Your space is warm whenever you come back 🌙", "Sleeping, not leaving. Promise."] };
}

export function moodColor(k, t) {
  return ({ radiant: "#FFB23E", happy: t.accent, cozy: t.accent2, sleepy: "#9DB4D6", sad: "#7FA6C9", unwell: "#C99BB0", dormant: "#9AA0B8" })[k] || t.accent;
}

export function stageBadge(days) {
  if (days < 15) return "🐣 Baby";
  if (days < 46) return "🌱 Juvenile";
  if (days < 90) return "🌟 Adult";
  return "💖 Bonded";
}
