// src/theme.js — 5 themes (with a dark "Midnight") and a tiny context.
import React, { createContext, useContext, useState } from "react";

export const THEMES = [
  { key: "sakura",   name: "Sakura Dream",  bg1: "#FFEAF2", bg2: "#FFD9E8", bg3: "#FFC2DD", accent: "#FF5C95", accent2: "#FF9CC2", soft: "#FFE3EE", ink: "#5C2A44", inkSoft: "#A36C86", card: "rgba(255,255,255,0.62)", cardSolid: "#FFFFFF", cardB: "rgba(255,255,255,0.9)", ringTrack: "rgba(255,92,149,0.16)", dark: false },
  { key: "mint",     name: "Mint Calm",     bg1: "#E9FBF2", bg2: "#D2F6E6", bg3: "#BCEFD7", accent: "#1FB873", accent2: "#74D0A5", soft: "#D4F5E9", ink: "#1C4A36", inkSoft: "#5A8C72", card: "rgba(255,255,255,0.6)",  cardSolid: "#FFFFFF", cardB: "rgba(255,255,255,0.9)", ringTrack: "rgba(31,184,115,0.16)", dark: false },
  { key: "sunset",   name: "Sunset Peach",  bg1: "#FFF1E4", bg2: "#FFE0C6", bg3: "#FFD0AB", accent: "#FF6B3D", accent2: "#FFB36B", soft: "#FFD9BC", ink: "#6B3620", inkSoft: "#AA7150", card: "rgba(255,255,255,0.6)",  cardSolid: "#FFFFFF", cardB: "rgba(255,255,255,0.9)", ringTrack: "rgba(255,107,61,0.16)", dark: false },
  { key: "lavender", name: "Lavender Glow", bg1: "#F4EEFF", bg2: "#E7DBFF", bg3: "#D9C7FF", accent: "#7C3AED", accent2: "#B68CFC", soft: "#EDE4FF", ink: "#39245F", inkSoft: "#6E54A0", card: "rgba(255,255,255,0.6)",  cardSolid: "#FFFFFF", cardB: "rgba(255,255,255,0.9)", ringTrack: "rgba(124,58,237,0.16)", dark: false },
  { key: "midnight", name: "Midnight Cozy", bg1: "#171534", bg2: "#221F4D", bg3: "#2E2A66", accent: "#8B95FF", accent2: "#B7BEFF", soft: "#3A3577", ink: "#ECEBFF", inkSoft: "#AFACE0", card: "rgba(255,255,255,0.08)", cardSolid: "#262247", cardB: "rgba(255,255,255,0.18)", ringTrack: "rgba(139,149,255,0.2)", dark: true },
];

export function themeByKey(k) { return THEMES.find((t) => t.key === k) || THEMES[0]; }

const ThemeCtx = createContext({ t: THEMES[0], setThemeKey: () => {} });
export function ThemeProvider({ value, children }) {
  return <ThemeCtx.Provider value={value}>{children}</ThemeCtx.Provider>;
}
export function useTheme() { return useContext(ThemeCtx); }
