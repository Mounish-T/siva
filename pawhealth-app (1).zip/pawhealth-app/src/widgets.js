// src/widgets.js — richer visual building blocks for v2.
import React, { useEffect, useRef } from "react";
import { View, Text, Pressable, Animated, Easing, StyleSheet } from "react-native";
import Svg, { Defs, LinearGradient, Stop, Rect } from "react-native-svg";
import { Pet } from "./components";
import { CHECK_MOODS } from "./content";

function hexA(hex, a) {
  const h = (hex || "#FF5C95").replace("#", "");
  const f = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  const n = parseInt(f, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

// The pet inside a collectible scene, wearing an optional accessory.
export function PetScene({ emoji, scene, accessoryEmoji, size = 112, reactionKey = 0, dim = false, onTapPet }) {
  const gradId = useRef("sc" + Math.random().toString(36).slice(2, 8)).current;
  const decor = (scene && scene.decor) || [];
  return (
    <View style={{ width: "100%", height: 200, borderRadius: 24, overflow: "hidden", justifyContent: "center", alignItems: "center" }}>
      <Svg style={StyleSheet.absoluteFill}>
        <Defs>
          <LinearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor={(scene && scene.c1) || "#FFF4FA"} />
            <Stop offset="1" stopColor={(scene && scene.c2) || "#FFE3F0"} />
          </LinearGradient>
        </Defs>
        <Rect width="100%" height="100%" fill={`url(#${gradId})`} />
      </Svg>
      {/* floating decor */}
      {decor[0] ? <Text style={{ position: "absolute", top: 16, left: 18, fontSize: 26, opacity: 0.85 }}>{decor[0]}</Text> : null}
      {decor[1] ? <Text style={{ position: "absolute", bottom: 14, left: 22, fontSize: 30, opacity: 0.8 }}>{decor[1]}</Text> : null}
      {decor[2] ? <Text style={{ position: "absolute", top: 22, right: 20, fontSize: 24, opacity: 0.85 }}>{decor[2]}</Text> : null}

      <Pressable onPress={onTapPet} style={{ alignItems: "center", justifyContent: "center" }}>
        <View>
          <Pet emoji={emoji} size={size} reactionKey={reactionKey} dim={dim} />
          {accessoryEmoji ? (
            <Text style={{ position: "absolute", top: -size * 0.06, alignSelf: "center", fontSize: size * 0.42 }}>{accessoryEmoji}</Text>
          ) : null}
        </View>
      </Pressable>
    </View>
  );
}

// Celebration: pass an incrementing `fireKey` to trigger a burst.
export function Burst({ fireKey, emojis = ["💖", "✨", "🌟", "🎉", "🌸"], count = 16 }) {
  if (!fireKey) return null;
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <Particles key={fireKey} emojis={emojis} count={count} />
    </View>
  );
}
function Particles({ emojis, count }) {
  const items = useRef(
    Array.from({ length: count }).map(() => ({
      emoji: emojis[Math.floor(Math.random() * emojis.length)],
      dx: (Math.random() * 2 - 1) * 170,
      dy: -(70 + Math.random() * 230),
      delay: Math.random() * 140,
      size: 15 + Math.random() * 18,
      rot: (Math.random() * 2 - 1) * 70,
    }))
  ).current;
  return <>{items.map((it, i) => <Particle key={i} {...it} />)}</>;
}
function Particle({ emoji, dx, dy, delay, size, rot }) {
  const p = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(p, { toValue: 1, duration: 1150, delay, easing: Easing.out(Easing.quad), useNativeDriver: true }).start();
  }, [p, delay]);
  const translateX = p.interpolate({ inputRange: [0, 1], outputRange: [0, dx] });
  const translateY = p.interpolate({ inputRange: [0, 1], outputRange: [0, dy] });
  const opacity = p.interpolate({ inputRange: [0, 0.7, 1], outputRange: [1, 1, 0] });
  const scale = p.interpolate({ inputRange: [0, 0.3, 1], outputRange: [0.4, 1.1, 0.9] });
  const rotate = p.interpolate({ inputRange: [0, 1], outputRange: ["0deg", `${rot}deg`] });
  return (
    <Animated.Text style={{ position: "absolute", left: "50%", top: "44%", fontSize: size, opacity, transform: [{ translateX }, { translateY }, { scale }, { rotate }] }}>
      {emoji}
    </Animated.Text>
  );
}

// GitHub-style wellness heatmap (last `weeks` weeks).
export function Heatmap({ hist, t, weeks = 5 }) {
  const days = weeks * 7;
  const cells = [];
  const today = new Date(); today.setHours(0, 0, 0, 0);
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today); d.setDate(d.getDate() - i);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    cells.push({ key, score: hist?.[key] });
  }
  return (
    <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 5 }}>
      {cells.map((c) => (
        <View key={c.key} style={{
          width: 13, height: 13, borderRadius: 4,
          backgroundColor: c.score != null ? hexA(t.accent, 0.22 + 0.78 * (c.score / 100)) : t.ringTrack,
        }} />
      ))}
    </View>
  );
}

// Recent moods as a strip of emoji.
export function MoodStrip({ moodLog, t }) {
  const last = (moodLog || []).slice(-7);
  if (last.length === 0) return <Text style={{ color: t.inkSoft, fontSize: 12.5, opacity: 0.8 }}>No check-ins yet — say hi on Home 🐾</Text>;
  return (
    <View style={{ flexDirection: "row", gap: 10 }}>
      {last.map((e, i) => {
        const m = CHECK_MOODS.find((x) => x.key === e.m);
        const dd = e.d.slice(5);
        return (
          <View key={i} style={{ alignItems: "center" }}>
            <Text style={{ fontSize: 22 }}>{m ? m.emoji : "🙂"}</Text>
            <Text style={{ fontSize: 9.5, color: t.inkSoft, marginTop: 2 }}>{dd}</Text>
          </View>
        );
      })}
    </View>
  );
}

// Tappable water cups.
export function HydrationCups({ count, goal, onAdd, t }) {
  return (
    <View>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
        {Array.from({ length: goal }).map((_, i) => {
          const filled = i < count;
          return (
            <Pressable key={i} onPress={onAdd}
              style={{ width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center",
                backgroundColor: filled ? t.accent + "22" : "transparent", borderWidth: 1.5, borderColor: filled ? t.accent : t.cardB }}>
              <Text style={{ fontSize: 17, opacity: filled ? 1 : 0.4 }}>{filled ? "💧" : "🥛"}</Text>
            </Pressable>
          );
        })}
      </View>
      <Text style={{ color: t.inkSoft, fontWeight: "700", fontSize: 12.5, marginTop: 8 }}>
        {Math.min(count, goal)}/{goal} cups{count >= goal ? " — lovely! 🌊" : ""}
      </Text>
    </View>
  );
}

// +/- stepper.
export function Stepper({ label, value, min = 1, max = 99, onChange, t }) {
  const btn = (txt, fn) => (
    <Pressable onPress={fn} style={{ width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: t.accent + "1f" }}>
      <Text style={{ fontSize: 20, fontWeight: "800", color: t.accent }}>{txt}</Text>
    </Pressable>
  );
  return (
    <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 8 }}>
      <Text style={{ color: t.ink, fontWeight: "600", fontSize: 14.5 }}>{label}</Text>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
        {btn("−", () => onChange(Math.max(min, value - 1)))}
        <Text style={{ fontSize: 18, fontWeight: "800", color: t.ink, minWidth: 32, textAlign: "center" }}>{value}</Text>
        {btn("+", () => onChange(Math.min(max, value + 1)))}
      </View>
    </View>
  );
}
