// src/notify.js — gentle, opt-in daily reminders from your companion.
// Uses expo-notifications (local notifications). Needs a dev/EAS build, not Expo Go (SDK 53+).
// We keep messages warm and pressure-free — never guilt.
let N = null;
try { N = require("expo-notifications"); } catch (e) {}

const LINES = [
  "is thinking of you today 🌸",
  "left you a little affirmation 💛",
  "is ready for a cozy moment whenever you are 🫶",
  "would love a quick hello 🐾",
  "hopes you're being gentle with yourself 🌿",
];

if (N && N.setNotificationHandler) {
  try {
    N.setNotificationHandler({
      handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: false, shouldSetBadge: false }),
    });
  } catch (e) {}
}

export async function enableDailyReminder(petName = "Your pet", hour = 19, minute = 0) {
  if (!N) return { ok: false, error: "notifications-unavailable" };
  try {
    const perm = await N.requestPermissionsAsync();
    if (!perm.granted && perm.status !== "granted") return { ok: false, error: "denied" };
    await N.cancelAllScheduledNotificationsAsync();
    const line = LINES[Math.floor(Math.random() * LINES.length)];
    await N.scheduleNotificationAsync({
      content: { title: `${petName} ${line}`, body: "Tap to spend a gentle moment together in PawHealth." },
      trigger: { hour, minute, repeats: true },
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String(e?.message || e) };
  }
}

export async function disableReminders() {
  if (!N) return;
  try { await N.cancelAllScheduledNotificationsAsync(); } catch (e) {}
}
