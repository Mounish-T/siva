// src/screens/ShopScreen.js — spend coins on outfits & scenes (collection = long-term fun).
import React, { useState } from "react";
import { View, Text, Pressable, ScrollView, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../store";
import { useTheme } from "../theme";
import { SHOP_ITEMS, itemById } from "../content";
import { Card } from "../components";
import { PetScene, Burst } from "../widgets";
import { haptic } from "../feedback";

export function ShopScreen() {
  const { t } = useTheme();
  const app = useApp();
  const [fire, setFire] = useState(0);

  const accessories = SHOP_ITEMS.filter((i) => i.kind === "accessory");
  const scenes = SHOP_ITEMS.filter((i) => i.kind === "scene");
  const scene = itemById(app.equippedScene) || scenes[0];
  const acc = app.equippedAccessory ? itemById(app.equippedAccessory) : null;

  function onBuy(item) {
    const ok = app.buyItem(item);
    if (ok) { haptic.success(); setFire((f) => f + 1); }
  }

  function ItemCard({ item }) {
    const owned = app.ownedItems.includes(item.id);
    const equipped = item.kind === "accessory" ? app.equippedAccessory === item.id : app.equippedScene === item.id;
    const canAfford = app.coins >= item.price;
    return (
      <View style={{ width: "48%", marginBottom: 12 }}>
        <Card t={t} style={{ alignItems: "center", paddingVertical: 14 }}>
          {item.kind === "accessory" ? (
            <Text style={{ fontSize: 40 }}>{item.emoji}</Text>
          ) : (
            <View style={{ flexDirection: "row", gap: 3 }}>
              <View style={{ width: 26, height: 38, borderRadius: 8, backgroundColor: item.c1 }} />
              <View style={{ width: 26, height: 38, borderRadius: 8, backgroundColor: item.c2 }} />
            </View>
          )}
          <Text style={{ fontSize: 14, fontWeight: "700", color: t.ink, marginTop: 8 }}>{item.name}</Text>

          {owned ? (
            <Pressable onPress={() => { haptic.select(); item.kind === "accessory" ? app.equipAccessory(item.id) : app.equipScene(item.id); }}
              style={{ marginTop: 8, paddingHorizontal: 16, paddingVertical: 7, borderRadius: 14, backgroundColor: equipped ? t.accent : t.accent + "22" }}>
              <Text style={{ color: equipped ? "#fff" : t.accent, fontWeight: "800", fontSize: 12.5 }}>
                {equipped ? "Equipped ✓" : (item.kind === "accessory" ? "Wear" : "Use")}
              </Text>
            </Pressable>
          ) : (
            <Pressable onPress={() => onBuy(item)} disabled={!canAfford}
              style={{ marginTop: 8, paddingHorizontal: 16, paddingVertical: 7, borderRadius: 14, backgroundColor: t.accent, opacity: canAfford ? 1 : 0.4 }}>
              <Text style={{ color: "#fff", fontWeight: "800", fontSize: 12.5 }}>🪙 {item.price}</Text>
            </Pressable>
          )}
        </Card>
      </View>
    );
  }

  return (
    <SafeAreaView style={[s.fill, { backgroundColor: t.bg1 }]} edges={["top"]}>
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingTop: 6 }}>
        <Text style={{ fontSize: 22, fontWeight: "800", color: t.ink }}>Pet Shop 🛍️</Text>
        <View style={{ paddingHorizontal: 12, paddingVertical: 7, borderRadius: 16, backgroundColor: t.cardSolid, borderWidth: 1, borderColor: t.cardB }}>
          <Text style={{ fontWeight: "800", color: t.ink }}>🪙 {app.coins}</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 28 }}>
        {/* live preview */}
        <View style={{ borderRadius: 24, overflow: "hidden", marginBottom: 6 }}>
          <PetScene emoji={app.pet?.emoji} scene={scene} accessoryEmoji={acc?.emoji} size={108} />
        </View>
        <Text style={{ textAlign: "center", color: t.inkSoft, fontSize: 12, marginBottom: 12 }}>
          Earn coins by caring for yourself, then dress up {app.petName || "your pet"} 💕
        </Text>

        <Text style={s.head(t)}>ACCESSORIES</Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" }}>
          {accessories.map((i) => <ItemCard key={i.id} item={i} />)}
        </View>

        <Text style={s.head(t)}>SCENES</Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" }}>
          {scenes.map((i) => <ItemCard key={i.id} item={i} />)}
        </View>
      </ScrollView>

      <Burst fireKey={fire} emojis={["🪙", "✨", "💖", "🎉"]} />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({ fill: { flex: 1 } });
s.head = (t) => ({ fontSize: 11, fontWeight: "800", letterSpacing: 1.1, color: t.inkSoft, marginTop: 8, marginBottom: 10 });
