// src/screens/OnboardingScreens.js — pick an egg → name your companion.
import React, { useState } from "react";
import { View, Text, Pressable, ScrollView, TextInput, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../store";
import { useTheme } from "../theme";
import { PETS } from "../data";
import { Pet, Card } from "../components";

export function ChooseScreen() {
  const { t } = useTheme();
  const { choosePet } = useApp();
  return (
    <SafeAreaView style={[s.fill, { backgroundColor: t.bg1 }]}>
      <ScrollView contentContainerStyle={{ padding: 22, paddingBottom: 40 }}>
        <Text style={{ textAlign: "center", color: t.inkSoft, fontWeight: "700", letterSpacing: 1, marginTop: 8 }}>✦ PAWHEALTH ✦</Text>
        <Text style={{ textAlign: "center", fontSize: 27, fontWeight: "800", color: t.ink, marginTop: 10, lineHeight: 33 }}>
          Something is waiting{"\n"}for you…
        </Text>
        <Text style={{ textAlign: "center", color: t.inkSoft, marginTop: 6, fontSize: 14 }}>
          Pick a companion. They'll grow as you care for yourself.
        </Text>

        <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", marginTop: 24 }}>
          {PETS.map((p) => (
            <Pressable key={p.key} onPress={() => choosePet(p)}
              style={({ pressed }) => [{ width: "48%", marginBottom: 14, transform: [{ scale: pressed ? 0.97 : 1 }] }]}>
              <Card t={t} style={{ alignItems: "center", paddingVertical: 18 }}>
                <Text style={{ fontSize: 60 }}>{p.emoji}</Text>
                <Text style={{ fontSize: 16, fontWeight: "700", color: t.ink, marginTop: 6 }}>{p.name}</Text>
                <Text style={{ fontSize: 11.5, color: t.inkSoft, textAlign: "center", marginTop: 4, lineHeight: 15 }}>{p.archetype}</Text>
              </Card>
            </Pressable>
          ))}
        </View>
        <Text style={{ textAlign: "center", color: t.inkSoft, opacity: 0.8, fontSize: 12, marginTop: 8 }}>
          🔒 Your data stays on your device.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

export function MeetScreen() {
  const { t } = useTheme();
  const { pet, setName } = useApp();
  const [name, setLocal] = useState("");
  if (!pet) return null;
  return (
    <SafeAreaView style={[s.fill, { backgroundColor: t.bg1 }]}>
      <ScrollView contentContainerStyle={{ padding: 24, alignItems: "center", paddingBottom: 40 }}>
        <View style={{ marginTop: 18, marginBottom: 4 }}><Pet emoji={pet.emoji} size={104} /></View>
        <Text style={{ fontSize: 23, fontWeight: "800", color: t.ink }}>A {pet.name} hatched!</Text>
        <Text style={{ color: t.inkSoft, textAlign: "center", marginTop: 6, marginBottom: 18, fontSize: 14, lineHeight: 20 }}>
          {pet.hello}
        </Text>

        <Card t={t} style={{ width: "100%" }}>
          <Text style={{ fontSize: 12, fontWeight: "700", color: t.inkSoft, letterSpacing: 0.4 }}>WHAT WILL YOU CALL THEM?</Text>
          <TextInput
            value={name} onChangeText={setLocal} maxLength={16} placeholder="Type a name…"
            placeholderTextColor={t.inkSoft}
            style={{ marginTop: 8, padding: 12, fontSize: 17, fontWeight: "600", color: t.ink, borderWidth: 1.5, borderColor: t.accent + "66", borderRadius: 14 }}
          />
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 10 }}>
            {["Mochi", "Cookie", "Pumpkin", "Biscuit", "Luna"].map((n) => (
              <Pressable key={n} onPress={() => setLocal(n)}
                style={{ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: t.cardB }}>
                <Text style={{ color: t.inkSoft, fontWeight: "600", fontSize: 13 }}>{n}</Text>
              </Pressable>
            ))}
          </View>
        </Card>

        <Pressable disabled={!name.trim()} onPress={() => setName(name.trim())}
          style={({ pressed }) => [{
            marginTop: 18, width: "100%", padding: 15, borderRadius: 18, alignItems: "center",
            backgroundColor: t.accent, opacity: !name.trim() ? 0.45 : pressed ? 0.9 : 1,
          }]}>
          <Text style={{ color: "#fff", fontWeight: "800", fontSize: 16 }}>I choose you 💖</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({ fill: { flex: 1 } });
