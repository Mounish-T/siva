// src/screens/PaywallScreen.js — PawHealth+ (one-time ₹30 unlock).
import React, { useState } from "react";
import { View, Text, Pressable, ScrollView, StyleSheet, ActivityIndicator, Alert } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../store";
import { useTheme } from "../theme";
import { buyPremium, restorePremium, PURCHASE_MODE } from "../premium";

const PERKS = [
  { icon: "🚫", text: "No ads, ever" },
  { icon: "✍️", text: "Unlimited custom activities" },
  { icon: "🎨", text: "All themes, including Midnight" },
  { icon: "🐾", text: "Support a tiny indie app 💕" },
];

export function PaywallScreen({ navigation }) {
  const { t } = useTheme();
  const app = useApp();
  const [busy, setBusy] = useState(false);

  async function buy() {
    setBusy(true);
    const res = await buyPremium();
    setBusy(false);
    if (res.ok) {
      app.setPurchased(true);
      Alert.alert("Welcome to PawHealth+ 💖", "Ads are off and everything's unlocked. Thank you!");
      navigation.goBack();
    } else {
      Alert.alert("Couldn't complete", res.error || "Purchase was cancelled or unavailable.");
    }
  }
  async function restore() {
    setBusy(true);
    const res = await restorePremium();
    setBusy(false);
    if (res.ok) { app.setPurchased(true); Alert.alert("Restored ✅", "Your PawHealth+ unlock is active again."); navigation.goBack(); }
    else Alert.alert("Nothing to restore", res.error || "No previous purchase was found for this account.");
  }

  return (
    <SafeAreaView style={[s.fill, { backgroundColor: t.bg1 }]}>
      <ScrollView contentContainerStyle={{ padding: 22, paddingBottom: 30 }}>
        <Pressable onPress={() => navigation.goBack()} style={{ alignSelf: "flex-start", paddingVertical: 6 }}>
          <Text style={{ color: t.inkSoft, fontWeight: "700", fontSize: 22 }}>✕</Text>
        </Pressable>

        <View style={{ alignItems: "center", marginTop: 6 }}>
          <Text style={{ fontSize: 54 }}>{app.pet?.emoji || "🐾"}</Text>
          <Text style={{ fontSize: 26, fontWeight: "800", color: t.ink, marginTop: 6 }}>PawHealth+</Text>
          {app.inTrial ? (
            <Text style={{ color: t.inkSoft, fontWeight: "700", marginTop: 4 }}>You're in your free trial — {app.trialDaysLeft} day{app.trialDaysLeft === 1 ? "" : "s"} left ✦</Text>
          ) : (
            <Text style={{ color: t.inkSoft, fontWeight: "700", marginTop: 4 }}>Your free 15 days have ended 🌷</Text>
          )}
        </View>

        <View style={{ marginTop: 22 }}>
          {PERKS.map((p, i) => (
            <View key={i} style={{ flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 11, borderBottomWidth: i < PERKS.length - 1 ? 1 : 0, borderColor: t.cardB }}>
              <Text style={{ fontSize: 22 }}>{p.icon}</Text>
              <Text style={{ fontSize: 15, fontWeight: "600", color: t.ink }}>{p.text}</Text>
            </View>
          ))}
        </View>

        <View style={{ alignItems: "center", marginTop: 22 }}>
          <Text style={{ fontSize: 13, color: t.inkSoft, fontWeight: "700" }}>One-time payment · yours forever</Text>
          <Text style={{ fontSize: 40, fontWeight: "800", color: t.ink, marginTop: 2 }}>₹30</Text>
        </View>

        <Pressable onPress={buy} disabled={busy || app.purchased}
          style={({ pressed }) => [{ marginTop: 16, paddingVertical: 16, borderRadius: 18, alignItems: "center",
            backgroundColor: t.accent, opacity: busy || app.purchased ? 0.6 : pressed ? 0.9 : 1 }]}>
          {busy ? <ActivityIndicator color="#fff" /> :
            <Text style={{ color: "#fff", fontWeight: "800", fontSize: 16 }}>{app.purchased ? "Already unlocked 💖" : "Unlock PawHealth+ · ₹30"}</Text>}
        </Pressable>

        <Pressable onPress={restore} disabled={busy} style={{ paddingVertical: 14, alignItems: "center" }}>
          <Text style={{ color: t.inkSoft, fontWeight: "700", fontSize: 13.5 }}>Restore purchase</Text>
        </Pressable>

        {PURCHASE_MODE === "simulated" && (
          <Text style={{ textAlign: "center", color: t.inkSoft, opacity: 0.7, fontSize: 11.5, marginTop: 4, lineHeight: 17 }}>
            (Developer note: billing is in "simulated" mode — the button unlocks instantly for testing.
            Switch PURCHASE_MODE to "expo-iap" in src/premium.js for real Google Play billing.)
          </Text>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({ fill: { flex: 1 } });
