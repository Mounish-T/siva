// src/screens/TrackerScreen.js — live GPS odometer + step counter.
//
// • Distance/speed/pace use expo-location (foreground GPS, Haversine between fixes).
// • Steps use expo-sensors Pedometer (live, foreground). Solid on iOS; on Android it
//   depends on the device's hardware step-counter and only counts while the app is open
//   (see README — Health Connect is the robust Android path for all-day steps).
import React, { useEffect, useRef, useState } from "react";
import { View, Text, Pressable, ScrollView, StyleSheet, Alert } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../store";
import { useTheme } from "../theme";
import { Card } from "../components";
import { AdBanner, useInterstitial } from "../ads";

let Location = null, Sensors = null;
try { Location = require("expo-location"); } catch (e) {}
try { Sensors = require("expo-sensors"); } catch (e) {}

const MODES = [
  { key: "walk",  label: "Walk",  emoji: "🚶", steps: true },
  { key: "run",   label: "Run",   emoji: "🏃", steps: true },
  { key: "cycle", label: "Cycle", emoji: "🚴", steps: false },
];

function haversineKm(a, b) {
  const R = 6371;
  const dLat = ((b.latitude - a.latitude) * Math.PI) / 180;
  const dLon = ((b.longitude - a.longitude) * Math.PI) / 180;
  const la1 = (a.latitude * Math.PI) / 180, la2 = (b.latitude * Math.PI) / 180;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}
function fmtClock(sec) {
  const m = Math.floor(sec / 60), s = Math.floor(sec % 60);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function TrackerScreen() {
  const { t } = useTheme();
  const app = useApp();
  const showInterstitial = useInterstitial(app.isPremium);

  const [mode, setMode] = useState(MODES[1]);
  const [active, setActive] = useState(false);
  const [dist, setDist] = useState(0);     // km
  const [secs, setSecs] = useState(0);
  const [speed, setSpeed] = useState(0);   // km/h
  const [steps, setSteps] = useState(0);
  const [pedAvail, setPedAvail] = useState(null);

  const locSub = useRef(null);
  const pedSub = useRef(null);
  const tick = useRef(null);
  const lastFix = useRef(null);
  const lastT = useRef(0);

  useEffect(() => {
    if (Sensors?.Pedometer) Sensors.Pedometer.isAvailableAsync().then(setPedAvail).catch(() => setPedAvail(false));
    else setPedAvail(false);
    return () => cleanup();
  }, []);

  function cleanup() {
    try { locSub.current && locSub.current.remove(); } catch (e) {}
    try { pedSub.current && pedSub.current.remove(); } catch (e) {}
    clearInterval(tick.current);
    locSub.current = pedSub.current = null;
  }

  async function start() {
    setDist(0); setSecs(0); setSpeed(0); setSteps(0);
    lastFix.current = null; lastT.current = Date.now();

    // GPS
    if (!Location) { Alert.alert("GPS unavailable", "expo-location isn't installed in this build."); return; }
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== "granted") { Alert.alert("Location needed", "Allow location to track distance and speed."); return; }

    setActive(true);
    tick.current = setInterval(() => setSecs((x) => x + 1), 1000);

    locSub.current = await Location.watchPositionAsync(
      { accuracy: Location.Accuracy.BestForNavigation, distanceInterval: 4, timeInterval: 1000 },
      (loc) => {
        const c = loc.coords;
        const now = Date.now();
        if (lastFix.current) {
          const dKm = haversineKm(lastFix.current, c);
          if (dKm > 0.0008 && dKm < 0.5) setDist((d) => d + dKm); // ignore jitter & teleports
          const dt = (now - lastT.current) / 1000;
          const v = c.speed != null && c.speed >= 0 ? c.speed * 3.6 : dt > 0 ? (dKm / dt) * 3600 : 0;
          setSpeed(Math.max(0, Math.min(80, v)));
        }
        lastFix.current = c; lastT.current = now;
      }
    );

    // Steps (walk/run only)
    if (mode.steps && Sensors?.Pedometer && pedAvail) {
      try { await Sensors.Pedometer.requestPermissionsAsync(); } catch (e) {}
      pedSub.current = Sensors.Pedometer.watchStepCount((r) => setSteps(r.steps || 0));
    }
  }

  function stop() {
    cleanup();
    setActive(false);
    if (dist > 0 || steps > 0) {
      app.recordSession({ distanceKm: dist, steps, reaction: mode.key });
      showInterstitial();
      Alert.alert(
        "Nice work! 🎉",
        `${mode.label} logged: ${dist.toFixed(2)} km${mode.steps ? `, ${steps} steps` : ""}. +12 🪙 and your companion is happier.`
      );
    }
  }

  const pace = dist > 0 ? secs / 60 / dist : 0; // min/km
  const Big = ({ value, unit, label }) => (
    <View style={{ flex: 1, alignItems: "center" }}>
      <Text style={{ fontSize: 13, color: t.inkSoft, fontWeight: "700" }}>{label}</Text>
      <Text style={{ fontSize: 30, fontWeight: "800", color: t.ink, marginTop: 2 }}>{value}</Text>
      <Text style={{ fontSize: 11, color: t.inkSoft, fontWeight: "700" }}>{unit}</Text>
    </View>
  );

  return (
    <SafeAreaView style={[s.fill, { backgroundColor: t.bg1 }]} edges={["top"]}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 24 }}>
        <Text style={{ fontSize: 22, fontWeight: "800", color: t.ink, marginBottom: 12 }}>Move with {app.petName || "your pet"} 🐾</Text>

        {/* mode selector */}
        <View style={{ flexDirection: "row", gap: 10, marginBottom: 14 }}>
          {MODES.map((m) => {
            const on = m.key === mode.key;
            return (
              <Pressable key={m.key} disabled={active} onPress={() => setMode(m)}
                style={{ flex: 1, alignItems: "center", paddingVertical: 14, borderRadius: 18, borderWidth: 1.5,
                  backgroundColor: on ? t.accent : t.cardSolid, borderColor: on ? t.accent : t.cardB, opacity: active && !on ? 0.5 : 1 }}>
                <Text style={{ fontSize: 24 }}>{m.emoji}</Text>
                <Text style={{ marginTop: 4, fontWeight: "800", fontSize: 13, color: on ? "#fff" : t.ink }}>{m.label}</Text>
              </Pressable>
            );
          })}
        </View>

        {/* odometer */}
        <Card t={t} style={{ paddingVertical: 22 }}>
          <View style={{ alignItems: "center" }}>
            <Text style={{ fontSize: 56, fontWeight: "800", color: t.accent, letterSpacing: -1 }}>{dist.toFixed(2)}</Text>
            <Text style={{ fontSize: 13, fontWeight: "800", color: t.inkSoft, letterSpacing: 1 }}>KILOMETRES</Text>
          </View>
          <View style={{ flexDirection: "row", marginTop: 18 }}>
            <Big label="Time" value={fmtClock(secs)} unit="mm:ss" />
            <Big label="Speed" value={speed.toFixed(1)} unit="km/h" />
            <Big label="Pace" value={pace > 0 && isFinite(pace) ? pace.toFixed(1) : "—"} unit="min/km" />
          </View>
        </Card>

        {/* steps */}
        {mode.steps && (
          <Card t={t} style={{ marginTop: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <View>
              <Text style={{ fontSize: 13, color: t.inkSoft, fontWeight: "700" }}>STEPS (this session)</Text>
              <Text style={{ fontSize: 34, fontWeight: "800", color: t.ink }}>{steps}</Text>
              {pedAvail === false && (
                <Text style={{ fontSize: 11, color: t.inkSoft, opacity: 0.8, marginTop: 2, maxWidth: 220 }}>
                  Step sensor not available on this device. Distance still tracks via GPS.
                </Text>
              )}
            </View>
            <Text style={{ fontSize: 40 }}>👟</Text>
          </Card>
        )}

        <AdBanner premium={app.isPremium} />

        <Pressable onPress={active ? stop : start}
          style={({ pressed }) => [{
            marginTop: 8, paddingVertical: 17, borderRadius: 20, alignItems: "center",
            backgroundColor: active ? "#E5484D" : t.accent, opacity: pressed ? 0.9 : 1,
          }]}>
          <Text style={{ color: "#fff", fontWeight: "800", fontSize: 17 }}>{active ? "Finish ■" : "Start ▶"}</Text>
        </Pressable>

        <Text style={{ textAlign: "center", color: t.inkSoft, opacity: 0.8, fontSize: 12, marginTop: 10, lineHeight: 18 }}>
          Lifetime: {app.totalDistance.toFixed(1)} km · {app.totalSteps} steps · {app.totalSessions} sessions
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({ fill: { flex: 1 } });
