// src/screens/ActivitiesScreen.js — user-created custom activities (CRUD).
import React, { useState } from "react";
import { View, Text, Pressable, ScrollView, TextInput, StyleSheet, Alert } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../store";
import { useTheme } from "../theme";
import { PILLARS, PILLAR_KEYS } from "../data";
import { Card, Row } from "../components";

const FREE_LIMIT = 3;
const DIFFS = [
  { key: "Easy", coins: 5 },
  { key: "Medium", coins: 10 },
  { key: "Hard", coins: 15 },
];
const EMOJIS = ["🌟", "📚", "🚿", "🧹", "🎨", "🎧", "🌿", "🍵", "💪", "🛌", "📵", "🙏"];

export function ActivitiesScreen({ navigation }) {
  const { t } = useTheme();
  const app = useApp();

  const [title, setTitle] = useState("");
  const [pillar, setPillar] = useState("mind");
  const [diff, setDiff] = useState(DIFFS[0]);
  const [emoji, setEmoji] = useState("🌟");

  const atLimit = !app.isPremium && app.customActivities.length >= FREE_LIMIT;

  function add() {
    if (!title.trim()) return;
    if (atLimit) {
      Alert.alert("Unlock more", `Free includes ${FREE_LIMIT} custom activities. PawHealth+ unlocks unlimited.`,
        [{ text: "Not now" }, { text: "See PawHealth+", onPress: () => navigation.navigate("Paywall") }]);
      return;
    }
    app.addActivity({
      id: "c_" + Date.now(),
      title: title.trim(),
      pillar,
      diff: diff.key,
      coins: diff.coins,
      emoji,
    });
    setTitle(""); setEmoji("🌟"); setDiff(DIFFS[0]); setPillar("mind");
  }

  function remove(a) {
    Alert.alert("Remove activity", `Delete "${a.title}"?`, [
      { text: "Cancel" },
      { text: "Delete", style: "destructive", onPress: () => app.deleteActivity(a.id) },
    ]);
  }

  return (
    <SafeAreaView style={[s.fill, { backgroundColor: t.bg1 }]} edges={["top"]}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 28 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 12 }}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10} style={{ width: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: t.cardSolid, borderWidth: 1, borderColor: t.cardB }}>
            <Text style={{ fontSize: 18, color: t.ink, fontWeight: "800" }}>‹</Text>
          </Pressable>
          <Text style={{ fontSize: 22, fontWeight: "800", color: t.ink }}>Your Activities ✍️</Text>
        </View>

        <Card t={t}>
          <Text style={{ fontSize: 12, fontWeight: "700", color: t.inkSoft, letterSpacing: 0.4 }}>NEW ACTIVITY</Text>
          <TextInput value={title} onChangeText={setTitle} maxLength={40} placeholder="e.g. Read 10 pages"
            placeholderTextColor={t.inkSoft}
            style={{ marginTop: 8, padding: 12, fontSize: 16, fontWeight: "600", color: t.ink, borderWidth: 1.5, borderColor: t.accent + "55", borderRadius: 14 }} />

          {/* pillar */}
          <Text style={s.lbl(t)}>PILLAR</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {PILLAR_KEYS.map((k) => {
              const on = k === pillar; const P = PILLARS[k];
              return (
                <Pressable key={k} onPress={() => setPillar(k)}
                  style={{ flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 11, paddingVertical: 8, borderRadius: 14,
                    backgroundColor: on ? P.tint + "22" : "transparent", borderWidth: 1.5, borderColor: on ? P.tint : t.cardB }}>
                  <Text>{P.icon}</Text>
                  <Text style={{ color: on ? t.ink : t.inkSoft, fontWeight: "700", fontSize: 12.5 }}>{P.label}</Text>
                </Pressable>
              );
            })}
          </View>

          {/* difficulty */}
          <Text style={s.lbl(t)}>DIFFICULTY · REWARD</Text>
          <View style={{ flexDirection: "row", gap: 8 }}>
            {DIFFS.map((d) => {
              const on = d.key === diff.key;
              return (
                <Pressable key={d.key} onPress={() => setDiff(d)}
                  style={{ flex: 1, alignItems: "center", paddingVertical: 10, borderRadius: 14,
                    backgroundColor: on ? t.accent : "transparent", borderWidth: 1.5, borderColor: on ? t.accent : t.cardB }}>
                  <Text style={{ color: on ? "#fff" : t.ink, fontWeight: "800", fontSize: 13 }}>{d.key}</Text>
                  <Text style={{ color: on ? "#fff" : t.inkSoft, fontWeight: "700", fontSize: 11 }}>🪙 {d.coins}</Text>
                </Pressable>
              );
            })}
          </View>

          {/* emoji */}
          <Text style={s.lbl(t)}>ICON</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {EMOJIS.map((e) => (
              <Pressable key={e} onPress={() => setEmoji(e)}
                style={{ width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center",
                  backgroundColor: e === emoji ? t.accent + "22" : "transparent", borderWidth: 1.5, borderColor: e === emoji ? t.accent : t.cardB }}>
                <Text style={{ fontSize: 20 }}>{e}</Text>
              </Pressable>
            ))}
          </View>

          <Pressable onPress={add} disabled={!title.trim()}
            style={({ pressed }) => [{ marginTop: 16, paddingVertical: 14, borderRadius: 16, alignItems: "center",
              backgroundColor: t.accent, opacity: !title.trim() ? 0.45 : pressed ? 0.9 : 1 }]}>
            <Text style={{ color: "#fff", fontWeight: "800", fontSize: 15 }}>Add activity +</Text>
          </Pressable>
          {atLimit && (
            <Text style={{ textAlign: "center", color: t.inkSoft, fontSize: 12, marginTop: 8 }}>
              Free includes {FREE_LIMIT}. Unlock unlimited with PawHealth+.
            </Text>
          )}
        </Card>

        <Text style={{ fontSize: 11, fontWeight: "800", letterSpacing: 1.1, color: t.inkSoft, marginTop: 18, marginBottom: 8 }}>
          SAVED ({app.customActivities.length})
        </Text>
        {app.customActivities.length === 0 ? (
          <Text style={{ color: t.inkSoft, opacity: 0.8, fontSize: 13 }}>Nothing yet — add an activity above. Long-press a saved one to remove it.</Text>
        ) : (
          app.customActivities.map((a) => {
            const P = PILLARS[a.pillar] || PILLARS.mind;
            return (
              <Row key={a.id} t={t} icon={a.emoji || P.icon} tint={P.tint} title={a.title}
                subtitle={`${P.label} · ${a.diff} · 🪙 ${a.coins}`}
                done={false} onPress={() => remove(a)} onLongPress={() => remove(a)} />
            );
          })
        )}
        <Text style={{ textAlign: "center", color: t.inkSoft, opacity: 0.7, fontSize: 11.5, marginTop: 10 }}>
          Saved activities appear in today's list on Home. Tap one here to remove it.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({ fill: { flex: 1 } });
s.lbl = (t) => ({ fontSize: 12, fontWeight: "700", color: t.inkSoft, letterSpacing: 0.4, marginTop: 14, marginBottom: 8 });
