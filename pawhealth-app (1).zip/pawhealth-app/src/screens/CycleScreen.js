// src/screens/CycleScreen.js — private, on-device cycle tracking with phase-aware care.
import React, { useState } from "react";
import { View, Text, Pressable, ScrollView, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../store";
import { useTheme } from "../theme";
import { cycleStatus, isoDay, prettyDate, PHASES } from "../content";
import { Card } from "../components";
import { Stepper } from "../widgets";
import { haptic } from "../feedback";

export function CycleScreen() {
  const { t } = useTheme();
  const app = useApp();
  const [editing, setEditing] = useState(false);
  const [cl, setCl] = useState(app.cycle.cycleLen || 28);
  const [pl, setPl] = useState(app.cycle.periodLen || 5);

  const st = cycleStatus(app.cycle);

  function logToday() { haptic.success(); app.logPeriodStart(isoDay()); }
  function saveSettings() { app.setCycle({ cycleLen: cl, periodLen: pl }); setEditing(false); haptic.select(); }

  const phaseOrder = ["menstrual", "follicular", "ovulation", "luteal"];

  return (
    <SafeAreaView style={[s.fill, { backgroundColor: t.bg1 }]} edges={["top"]}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 28 }}>
        <Text style={{ fontSize: 22, fontWeight: "800", color: t.ink }}>Cycle & Body 🌸</Text>
        <Text style={{ color: t.inkSoft, fontSize: 12.5, marginTop: 4, marginBottom: 14 }}>🔒 Private & stored only on this device.</Text>

        {!st.hasData ? (
          <Card t={t} style={{ alignItems: "center", paddingVertical: 22 }}>
            <Text style={{ fontSize: 40 }}>🌙</Text>
            <Text style={{ fontSize: 16, fontWeight: "700", color: t.ink, marginTop: 8, textAlign: "center" }}>Let's start gently</Text>
            <Text style={{ color: t.inkSoft, fontSize: 13, textAlign: "center", marginTop: 6, lineHeight: 19 }}>
              Log the first day of your period and PawHealth will track your phases and gently adapt — no pressure, ever.
            </Text>
            <Pressable onPress={logToday} style={{ marginTop: 16, paddingHorizontal: 22, paddingVertical: 13, borderRadius: 16, backgroundColor: t.accent }}>
              <Text style={{ color: "#fff", fontWeight: "800", fontSize: 15 }}>My period started today</Text>
            </Pressable>
          </Card>
        ) : (
          <>
            {/* current phase */}
            <Card t={t} style={{ alignItems: "center", paddingVertical: 20 }}>
              <Text style={{ fontSize: 44 }}>{st.info.emoji}</Text>
              <Text style={{ fontSize: 20, fontWeight: "800", color: t.ink, marginTop: 6 }}>{st.info.name} phase</Text>
              <Text style={{ color: t.inkSoft, fontWeight: "700", marginTop: 2 }}>Day {st.dayInCycle} of your cycle</Text>
              <View style={{ backgroundColor: t.card, borderRadius: 16, padding: 12, marginTop: 12, borderWidth: 1, borderColor: t.cardB }}>
                <Text style={{ color: t.ink, fontSize: 13.5, textAlign: "center", lineHeight: 19 }}>{st.info.tip}</Text>
              </View>
              <Text style={{ color: t.accent, fontWeight: "700", fontSize: 13, marginTop: 12 }}>
                {app.petName || "Your pet"}: “{st.info.pet}”
              </Text>
            </Card>

            {/* prediction */}
            <Card t={t} style={{ marginTop: 12, flexDirection: "row", justifyContent: "space-around" }}>
              <View style={{ alignItems: "center" }}>
                <Text style={{ fontSize: 22, fontWeight: "800", color: t.ink }}>{st.daysToNext}</Text>
                <Text style={{ fontSize: 11, color: t.inkSoft, fontWeight: "700" }}>days to next</Text>
              </View>
              <View style={{ alignItems: "center" }}>
                <Text style={{ fontSize: 22, fontWeight: "800", color: t.ink }}>{prettyDate(st.nextStart)}</Text>
                <Text style={{ fontSize: 11, color: t.inkSoft, fontWeight: "700" }}>est. next period</Text>
              </View>
              <View style={{ alignItems: "center" }}>
                <Text style={{ fontSize: 22, fontWeight: "800", color: t.ink }}>{st.cycleLen}</Text>
                <Text style={{ fontSize: 11, color: t.inkSoft, fontWeight: "700" }}>cycle length</Text>
              </View>
            </Card>

            {/* phase legend */}
            <Text style={s.head(t)}>YOUR PHASES</Text>
            {phaseOrder.map((p) => {
              const ph = PHASES[p]; const on = st.phase === p;
              return (
                <View key={p} style={{ flexDirection: "row", alignItems: "center", gap: 12, padding: 12, borderRadius: 16, marginBottom: 8,
                  backgroundColor: t.cardSolid, borderWidth: 1.5, borderColor: on ? t.accent : t.cardB }}>
                  <Text style={{ fontSize: 22 }}>{ph.emoji}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontWeight: "700", color: t.ink, fontSize: 14 }}>{ph.name}{on ? "  · now" : ""}</Text>
                    <Text style={{ color: t.inkSoft, fontSize: 12, marginTop: 1 }}>{ph.tip}</Text>
                  </View>
                </View>
              );
            })}

            <Pressable onPress={logToday} style={{ marginTop: 6, paddingVertical: 14, borderRadius: 16, alignItems: "center", backgroundColor: t.accent }}>
              <Text style={{ color: "#fff", fontWeight: "800", fontSize: 15 }}>Log a new period start (today)</Text>
            </Pressable>
            {!!app.cycle.lastStart && (
              <Text style={{ textAlign: "center", color: t.inkSoft, fontSize: 12, marginTop: 8 }}>Last logged: {prettyDate(app.cycle.lastStart)}</Text>
            )}
          </>
        )}

        {/* settings */}
        <Pressable onPress={() => setEditing((e) => !e)} style={{ marginTop: 16, paddingVertical: 12, borderRadius: 14, borderWidth: 1.5, borderColor: t.cardB, alignItems: "center" }}>
          <Text style={{ color: t.inkSoft, fontWeight: "700", fontSize: 13.5 }}>{editing ? "Close settings" : "⚙️ Adjust cycle & period length"}</Text>
        </Pressable>
        {editing && (
          <Card t={t} style={{ marginTop: 10 }}>
            <Stepper t={t} label="Average cycle length (days)" value={cl} min={20} max={45} onChange={setCl} />
            <Stepper t={t} label="Period length (days)" value={pl} min={2} max={10} onChange={setPl} />
            <Pressable onPress={saveSettings} style={{ marginTop: 10, paddingVertical: 12, borderRadius: 14, alignItems: "center", backgroundColor: t.accent }}>
              <Text style={{ color: "#fff", fontWeight: "800" }}>Save</Text>
            </Pressable>
          </Card>
        )}

        <Text style={{ textAlign: "center", color: t.inkSoft, opacity: 0.75, fontSize: 11.5, marginTop: 14, lineHeight: 17 }}>
          Predictions are estimates to help you prepare — every body is different. This isn't medical advice.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({ fill: { flex: 1 } });
s.head = (t) => ({ fontSize: 11, fontWeight: "800", letterSpacing: 1.1, color: t.inkSoft, marginTop: 16, marginBottom: 10 });
