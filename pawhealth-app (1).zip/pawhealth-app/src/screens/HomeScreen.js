// src/screens/HomeScreen.js — the daily care loop, now with bonding, check-ins, feeding & more.
import React, { useEffect, useMemo, useRef, useState } from "react";
import { View, Text, Pressable, ScrollView, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../store";
import { useTheme } from "../theme";
import { BASE_GOALS, PILLARS, REACTIONS, getMood, moodColor, stageBadge } from "../data";
import { Ring, Card, Row, Pill } from "../components";
import { PetScene, Burst, HydrationCups } from "../widgets";
import { bondInfo, itemById, affirmationFor, CHECK_MOODS, moodByKey } from "../content";
import { AdBanner } from "../ads";
import { haptic } from "../feedback";

export function HomeScreen({ navigation }) {
  const { t } = useTheme();
  const app = useApp();
  const [reactionKey, setReactionKey] = useState(0);
  const [bubble, setBubble] = useState(null);
  const [fire, setFire] = useState(0);

  const mood = getMood(app.wellness);
  const mColor = moodColor(mood.key, t);
  const b = bondInfo(app.bond);
  const scene = itemById(app.equippedScene);
  const acc = app.equippedAccessory ? itemById(app.equippedAccessory) : null;

  const builtin = BASE_GOALS;
  const customs = app.customActivities;
  const doneCount = builtin.filter((g) => app.builtinDone[g.id]).length + customs.filter((a) => app.customDone[a.id]).length;
  const total = builtin.length + customs.length;
  const allDone = total > 0 && doneCount === total;

  const wasAll = useRef(false);
  useEffect(() => {
    if (allDone && !wasAll.current) { setFire((f) => f + 1); haptic.success(); setBubble("We did it all today! I'm so proud of us 🎉"); setTimeout(() => setBubble(null), 2600); }
    wasAll.current = allDone;
  }, [allDone]);

  const seed = useMemo(() => { const d = new Date(); return d.getFullYear() * 366 + Math.floor((d - new Date(d.getFullYear(), 0, 0)) / 86400000); }, []);
  const todaysAffirmation = affirmationFor(seed);

  const line = bubble || mood.lines[seed % mood.lines.length];

  function react(reaction) { setReactionKey((k) => k + 1); setBubble(REACTIONS[reaction]?.line || null); setTimeout(() => setBubble(null), 2200); }
  function doPetTap() { app.petTap(); haptic.tap(); react("pet"); }
  function doBuiltin(g) { app.completeBuiltin(g, builtin); haptic.press(); react(g.reaction); }
  function doCustom(a) { app.completeCustom(a, builtin); haptic.press(); react("custom"); }
  function doCheckIn(m) { app.checkIn(m); haptic.select(); setReactionKey((k) => k + 1); setBubble(m.line); setTimeout(() => setBubble(null), 2600); }
  function doFeed() { const ok = app.feed(); if (ok) { haptic.press(); setReactionKey((k) => k + 1); setBubble("Nom nom… thank you! 🍓"); setTimeout(() => setBubble(null), 2200); } }
  function doBuyTreat() { if (app.buyTreat()) haptic.select(); }
  function doHydrate() { app.addHydration(); haptic.tap(); }

  const todayMood = app.checkedInToday ? moodByKey(app.moodLog[app.moodLog.length - 1]?.m) : null;

  return (
    <SafeAreaView style={[s.fill, { backgroundColor: t.bg1 }]} edges={["top"]}>
      {/* app bar */}
      <View style={s.bar}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <View style={[s.avatar, { backgroundColor: t.cardSolid, borderColor: t.cardB }]}><Text style={{ fontSize: 24 }}>{app.pet?.emoji}</Text></View>
          <View>
            <Text style={{ fontSize: 17, fontWeight: "700", color: t.ink }}>{app.petName || app.pet?.name}</Text>
            <Text style={{ fontSize: 11, fontWeight: "700", color: t.inkSoft }}>💞 {b.title} · {stageBadge(app.streakDays)}</Text>
          </View>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
          {!app.isPremium ? (
            <Pressable onPress={() => navigation.navigate("Paywall")} style={[s.chip, { backgroundColor: t.accent }]}><Text style={{ color: "#fff", fontWeight: "800", fontSize: 12 }}>Go+ ✦</Text></Pressable>
          ) : app.inTrial ? (
            <Pressable onPress={() => navigation.navigate("Paywall")} style={[s.chip, { backgroundColor: t.accent + "22" }]}><Text style={{ color: t.accent, fontWeight: "800", fontSize: 12 }}>Trial · {app.trialDaysLeft}d</Text></Pressable>
          ) : (
            <View style={[s.chip, { backgroundColor: t.accent + "22" }]}><Text style={{ color: t.accent, fontWeight: "800", fontSize: 12 }}>+ ✦</Text></View>
          )}
          <View style={[s.chip, { backgroundColor: t.cardSolid, borderWidth: 1, borderColor: t.cardB }]}><Text style={{ fontWeight: "800", color: t.ink, fontSize: 14 }}>🪙 {app.coins}</Text></View>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 24 }}>
        {/* pet scene */}
        <Card t={t} style={{ alignItems: "center", paddingVertical: 14, overflow: "hidden" }}>
          <View style={{ backgroundColor: t.card, borderRadius: 18, paddingHorizontal: 15, paddingVertical: 10, maxWidth: "90%", borderWidth: 1, borderColor: t.cardB, marginBottom: 6, zIndex: 2 }}>
            <Text style={{ color: t.ink, fontWeight: "600", fontSize: 14.5, textAlign: "center", lineHeight: 20 }}>{line}</Text>
          </View>
          <PetScene emoji={app.pet?.emoji} scene={scene} accessoryEmoji={acc?.emoji} size={108} reactionKey={reactionKey}
            dim={mood.key === "dormant" || mood.key === "unwell"} onTapPet={doPetTap} />
          <Text style={{ fontSize: 11.5, color: t.inkSoft, opacity: 0.75, marginTop: 6 }}>tap {app.petName || "them"} to say hi 💕</Text>
        </Card>

        {/* daily check-in */}
        {!app.checkedInToday ? (
          <Card t={t} style={{ marginTop: 14 }}>
            <Text style={{ fontSize: 15, fontWeight: "700", color: t.ink }}>How are you feeling today?</Text>
            <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 12 }}>
              {CHECK_MOODS.map((m) => (
                <Pressable key={m.key} onPress={() => doCheckIn(m)} style={({ pressed }) => [{ alignItems: "center", flex: 1, transform: [{ scale: pressed ? 0.92 : 1 }] }]}>
                  <Text style={{ fontSize: 30 }}>{m.emoji}</Text>
                  <Text style={{ fontSize: 11, color: t.inkSoft, fontWeight: "700", marginTop: 3 }}>{m.label}</Text>
                </Pressable>
              ))}
            </View>
          </Card>
        ) : (
          <Card t={t} style={{ marginTop: 14, flexDirection: "row", alignItems: "center", gap: 10 }}>
            <Text style={{ fontSize: 26 }}>{todayMood?.emoji || "🙂"}</Text>
            <Text style={{ color: t.ink, fontWeight: "600", fontSize: 13.5, flex: 1 }}>Checked in today — thank you for sharing 💛</Text>
          </Card>
        )}

        {/* bond + wellness */}
        <Card t={t} style={{ flexDirection: "row", alignItems: "center", gap: 14, marginTop: 14 }}>
          <Ring value={app.wellness} color={mColor} badge={mood.badge} label={mood.label} t={t} />
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 12, fontWeight: "800", color: t.inkSoft, letterSpacing: 0.4 }}>💞 BOND · LV {b.level}</Text>
            <Text style={{ fontSize: 14.5, color: t.ink, fontWeight: "700", marginVertical: 3 }}>{b.title}</Text>
            <View style={{ height: 8, borderRadius: 8, backgroundColor: t.ringTrack, overflow: "hidden" }}>
              <View style={{ height: "100%", width: `${b.pct}%`, backgroundColor: t.accent, borderRadius: 8 }} />
            </View>
            <Text style={{ fontSize: 11, color: t.inkSoft, marginTop: 4 }}>{b.maxed ? "Soulmates forever 💖" : `${b.toNext} care points to Lv ${b.level + 1}`}</Text>
            <View style={{ marginTop: 9 }}>
              {app.streakState === "active" && <Pill t={t}>🔥 {app.streakDays}-day streak</Pill>}
              {app.streakState === "resting" && <Pill t={t} tone="soft">😴 Resting · never breaks</Pill>}
              {app.streakState === "recovering" && <Pill t={t} tone="soft">🌱 Recovering · welcome back</Pill>}
            </View>
          </View>
        </Card>

        {/* feed + hydration */}
        <View style={{ flexDirection: "row", gap: 12, marginTop: 14 }}>
          <Card t={t} style={{ flex: 1, alignItems: "center", paddingVertical: 16 }}>
            <Text style={{ fontSize: 30 }}>🍓</Text>
            <Text style={{ fontSize: 12.5, fontWeight: "700", color: t.ink, marginTop: 4 }}>Treats: {app.treats}</Text>
            {app.treats > 0 ? (
              <Pressable onPress={doFeed} style={{ marginTop: 8, paddingHorizontal: 18, paddingVertical: 8, borderRadius: 14, backgroundColor: t.accent }}>
                <Text style={{ color: "#fff", fontWeight: "800", fontSize: 12.5 }}>Feed 🐾</Text>
              </Pressable>
            ) : (
              <Pressable onPress={doBuyTreat} style={{ marginTop: 8, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 14, backgroundColor: t.accent + "22" }}>
                <Text style={{ color: t.accent, fontWeight: "800", fontSize: 12 }}>Buy 🪙10</Text>
              </Pressable>
            )}
            <Text style={{ fontSize: 10.5, color: t.inkSoft, marginTop: 6, textAlign: "center" }}>earn treats by{"\n"}completing goals</Text>
          </Card>
          <Card t={t} style={{ flex: 1.4 }}>
            <Text style={{ fontSize: 12.5, fontWeight: "700", color: t.ink, marginBottom: 8 }}>💧 Hydration</Text>
            <HydrationCups count={app.hydration} goal={app.hydrationGoal} onAdd={doHydrate} t={t} />
          </Card>
        </View>

        {/* affirmation */}
        <Card t={t} style={{ marginTop: 14, flexDirection: "row", alignItems: "center", gap: 12 }}>
          <Text style={{ fontSize: 26 }}>🌷</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 10.5, fontWeight: "800", letterSpacing: 1, color: t.inkSoft }}>TODAY'S NOTE FROM {(app.petName || "ME").toUpperCase()}</Text>
            <Text style={{ fontSize: 14, color: t.ink, fontWeight: "600", marginTop: 3, lineHeight: 19 }}>{todaysAffirmation}</Text>
          </View>
        </Card>

        <AdBanner premium={app.isPremium} />

        {/* today */}
        <Text style={{ fontSize: 11, fontWeight: "800", letterSpacing: 1.2, color: t.inkSoft, marginTop: 10, marginBottom: 4 }}>TODAY, GENTLY</Text>
        <Text style={{ fontSize: 19, fontWeight: "700", color: t.ink, marginBottom: 10 }}>A small step is still a step 🌱</Text>

        {builtin.map((g) => { const P = PILLARS[g.pillar]; return (
          <Row key={g.id} t={t} icon={P.icon} tint={P.tint} title={g.title} subtitle={`${g.diff} · 🪙 ${g.coins}${g.rest ? " · self-care 🌸" : ""}`} done={!!app.builtinDone[g.id]} onPress={() => doBuiltin(g)} />
        ); })}

        {customs.length > 0 && <Text style={{ fontSize: 11, fontWeight: "800", letterSpacing: 1.1, color: t.inkSoft, marginTop: 6, marginBottom: 8 }}>YOUR ACTIVITIES</Text>}
        {customs.map((a) => { const P = PILLARS[a.pillar] || PILLARS.mind; return (
          <Row key={a.id} t={t} icon={a.emoji || P.icon} tint={P.tint} title={a.title} subtitle={`${a.diff || "Easy"} · 🪙 ${a.coins || 5}`} done={!!app.customDone[a.id]} onPress={() => doCustom(a)} />
        ); })}

        <Pressable onPress={() => navigation.navigate("Activities")} style={{ paddingVertical: 13, borderRadius: 16, borderWidth: 1.5, borderColor: t.accent + "66", borderStyle: "dashed", alignItems: "center", marginTop: 2 }}>
          <Text style={{ color: t.accent, fontWeight: "700", fontSize: 13.5 }}>+ Add your own activity</Text>
        </Pressable>

        <Pressable onPress={() => { app.skipDay(); haptic.tap(); }} style={{ paddingVertical: 13, borderRadius: 16, borderWidth: 1.5, borderColor: t.inkSoft + "55", borderStyle: "dashed", alignItems: "center", marginTop: 12 }}>
          <Text style={{ color: t.inkSoft, fontWeight: "700", fontSize: 13.5 }}>🌗 Try it: skip a day</Text>
        </Pressable>
        <Text style={{ textAlign: "center", color: t.inkSoft, opacity: 0.8, fontSize: 12, marginTop: 9, lineHeight: 18 }}>
          Resilience model: your streak rests instead of breaking, and {app.petName || "your pet"} simply gets sleepy — never punishing.
        </Text>
      </ScrollView>

      <Burst fireKey={fire} />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  fill: { flex: 1 },
  bar: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingTop: 6, paddingBottom: 8 },
  avatar: { width: 42, height: 42, borderRadius: 21, alignItems: "center", justifyContent: "center", borderWidth: 1 },
  chip: { paddingHorizontal: 11, paddingVertical: 7, borderRadius: 16 },
});
