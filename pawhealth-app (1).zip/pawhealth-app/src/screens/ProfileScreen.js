// src/screens/ProfileScreen.js — bond, insights, achievements, sharing, themes, reminders, premium.
import React, { useRef, useState } from "react";
import { View, Text, Pressable, ScrollView, StyleSheet, Share, Switch } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../store";
import { useTheme, THEMES } from "../theme";
import { getMood, moodColor, stageBadge } from "../data";
import { bondInfo, isoDay } from "../content";
import { Pet, Card } from "../components";
import { Heatmap, MoodStrip } from "../widgets";
import { enableDailyReminder, disableReminders } from "../notify";
import { haptic } from "../feedback";

let ViewShot = null, Sharing = null;
try { ViewShot = require("react-native-view-shot"); } catch (e) {}
try { Sharing = require("expo-sharing"); } catch (e) {}

export function ProfileScreen() {
  const { t, setThemeKey } = useTheme();
  const app = useApp();
  const shotRef = useRef(null);
  const [notify, setNotify] = useState(!!app.notifyOptIn);

  const mood = getMood(app.wellness);
  const name = app.petName || app.pet?.name || "your pet";
  const b = bondInfo(app.bond);

  // last 7 days insight counts
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const last7 = [];
  for (let i = 0; i < 7; i++) { const d = new Date(today); d.setDate(d.getDate() - i); last7.push(isoDay(d)); }
  const activeDays = last7.filter((k) => app.wellnessHist[k] != null).length;
  const checkinsWeek = (app.moodLog || []).filter((e) => last7.includes(e.d)).length;

  const ach = [
    { icon: "🐣", label: "Hatched a companion", got: true },
    { icon: "💬", label: "First daily check-in", got: (app.moodLog || []).length > 0 },
    { icon: "✍️", label: "Made an activity", got: app.customActivities.length > 0 },
    { icon: "🏃", label: "Tracked a session", got: app.totalSessions > 0 },
    { icon: "🛍️", label: "Visited the shop", got: app.ownedItems.length > 1 },
    { icon: "🌸", label: "Logged your cycle", got: !!app.cycle.lastStart },
    { icon: "📤", label: "Shared progress", got: app.shared },
    { icon: "💞", label: "Reached Bond Lv 3", got: b.level >= 3 },
    { icon: "✨", label: "Reached Radiant", got: app.wellness >= 85 },
    { icon: "💖", label: "PawHealth+ member", got: !!app.purchased },
  ];
  const got = ach.filter((a) => a.got).length;

  async function share() {
    const caption = `${name} is thriving on PawHealth! 🌸 We're at "${b.title}" — building gentle, healthy habits and keeping my little companion happy & well-fed. #PawHealth`;
    try {
      if (ViewShot && Sharing && shotRef.current) {
        const uri = await ViewShot.captureRef(shotRef, { format: "png", quality: 1 });
        if (await Sharing.isAvailableAsync()) { await Sharing.shareAsync(uri, { mimeType: "image/png", dialogTitle: "Share your progress" }); app.markShared(); haptic.success(); return; }
      }
      await Share.share({ message: caption }); app.markShared(); haptic.success();
    } catch (e) { try { await Share.share({ message: caption }); app.markShared(); } catch (e2) {} }
  }

  async function toggleNotify(v) {
    setNotify(v); app.setNotifyOptIn(v); haptic.select();
    if (v) { const r = await enableDailyReminder(name); if (!r.ok) { /* keep toggle; will work on a real dev build */ } }
    else { await disableReminders(); }
  }

  return (
    <SafeAreaView style={[s.fill, { backgroundColor: t.bg1 }]} edges={["top"]}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 28 }}>
        <Text style={{ fontSize: 22, fontWeight: "800", color: t.ink, marginBottom: 12 }}>You & {name} 👤</Text>

        {/* shareable card */}
        <View ref={shotRef} collapsable={false} style={{ borderRadius: 26, overflow: "hidden" }}>
          <View style={{ backgroundColor: t.bg2, padding: 22, alignItems: "center" }}>
            <Pet emoji={app.pet?.emoji} size={86} />
            <Text style={{ fontSize: 22, fontWeight: "800", color: t.ink, marginTop: 6 }}>{name}</Text>
            <Text style={{ fontSize: 13, color: t.inkSoft, fontWeight: "700", marginTop: 2 }}>💞 {b.title} · {stageBadge(app.streakDays)}</Text>
            <View style={{ flexDirection: "row", gap: 18, marginTop: 14 }}>
              <Mini t={t} v={app.streakDays + "d"} l="streak" />
              <Mini t={t} v={Math.round(app.wellness)} l="wellness" />
              <Mini t={t} v={app.totalSessions} l="sessions" />
            </View>
            <Text style={{ marginTop: 14, fontSize: 12, fontWeight: "800", color: t.accent, letterSpacing: 1 }}>✦ PAWHEALTH ✦</Text>
          </View>
        </View>
        <Pressable onPress={share} style={({ pressed }) => [{ marginTop: 12, paddingVertical: 14, borderRadius: 16, alignItems: "center", backgroundColor: t.accent, opacity: pressed ? 0.9 : 1 }]}>
          <Text style={{ color: "#fff", fontWeight: "800", fontSize: 15 }}>📤 Share my progress</Text>
        </Pressable>

        {/* bond */}
        <Card t={t} style={{ marginTop: 16 }}>
          <Text style={{ fontSize: 12, fontWeight: "800", color: t.inkSoft, letterSpacing: 0.4 }}>💞 BOND WITH {name.toUpperCase()}</Text>
          <Text style={{ fontSize: 17, fontWeight: "800", color: t.ink, marginTop: 4 }}>{b.title} · Level {b.level}</Text>
          <View style={{ height: 10, borderRadius: 8, backgroundColor: t.ringTrack, overflow: "hidden", marginTop: 8 }}>
            <View style={{ height: "100%", width: `${b.pct}%`, backgroundColor: t.accent, borderRadius: 8 }} />
          </View>
          <Text style={{ fontSize: 12, color: t.inkSoft, marginTop: 6 }}>{b.maxed ? "You two are inseparable 💖" : `Care a little each day — ${b.toNext} points to the next level.`}</Text>
        </Card>

        {/* insights */}
        <Card t={t} style={{ marginTop: 14 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 12 }}>
            <Insight t={t} v={activeDays} l="active days / wk" />
            <Insight t={t} v={checkinsWeek} l="check-ins / wk" />
            <Insight t={t} v={`${app.totalDistance.toFixed(1)}`} l="km total" />
          </View>
          <Text style={{ fontSize: 11, fontWeight: "800", letterSpacing: 0.6, color: t.inkSoft, marginBottom: 8 }}>WELLNESS · LAST 5 WEEKS</Text>
          <Heatmap hist={app.wellnessHist} t={t} weeks={5} />
          <Text style={{ fontSize: 11, fontWeight: "800", letterSpacing: 0.6, color: t.inkSoft, marginTop: 14, marginBottom: 8 }}>RECENT MOODS</Text>
          <MoodStrip moodLog={app.moodLog} t={t} />
        </Card>

        {/* stats */}
        <View style={{ flexDirection: "row", gap: 10, marginTop: 14 }}>
          <Stat t={t} icon="🪙" v={app.coins} l="coins" />
          <Stat t={t} icon="🍓" v={app.treats} l="treats" />
          <Stat t={t} icon="🔥" v={`${app.streakDays}d`} l="streak" />
        </View>

        {/* achievements */}
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 18, marginBottom: 8 }}>
          <Text style={{ fontSize: 11, fontWeight: "800", letterSpacing: 1.1, color: t.inkSoft }}>ACHIEVEMENTS</Text>
          <Text style={{ fontSize: 12, fontWeight: "800", color: t.accent }}>{got}/{ach.length}</Text>
        </View>
        <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" }}>
          {ach.map((a, i) => (
            <View key={i} style={{ width: "48%", marginBottom: 10, flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: t.cardSolid, borderRadius: 16, borderWidth: 1, borderColor: t.cardB, padding: 12, opacity: a.got ? 1 : 0.5 }}>
              <View style={{ width: 36, height: 36, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: a.got ? t.accent + "1f" : "transparent", borderWidth: a.got ? 0 : 1.5, borderColor: t.inkSoft + "55", borderStyle: "dashed" }}>
                <Text style={{ fontSize: 18 }}>{a.got ? a.icon : "🔒"}</Text>
              </View>
              <Text style={{ flex: 1, fontSize: 12, fontWeight: "700", color: t.ink }}>{a.label}</Text>
            </View>
          ))}
        </View>

        {/* reminder toggle */}
        <Card t={t} style={{ marginTop: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <View style={{ flex: 1, paddingRight: 10 }}>
            <Text style={{ color: t.ink, fontWeight: "700", fontSize: 14.5 }}>Gentle daily reminder</Text>
            <Text style={{ color: t.inkSoft, fontSize: 12, marginTop: 3, lineHeight: 17 }}>A warm hello from {name} each evening — never guilt, just a nudge.</Text>
          </View>
          <Switch value={notify} onValueChange={toggleNotify} trackColor={{ true: t.accent }} thumbColor="#fff" />
        </Card>

        {/* themes */}
        <Text style={{ fontSize: 11, fontWeight: "800", letterSpacing: 1.1, color: t.inkSoft, marginTop: 16, marginBottom: 8 }}>THEME</Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
          {THEMES.map((th) => (
            <Pressable key={th.key} onPress={() => { setThemeKey(th.key); haptic.select(); }} style={{ flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 11, paddingVertical: 8, borderRadius: 14, borderWidth: 1.5, borderColor: th.key === t.key ? t.accent : t.cardB, backgroundColor: t.cardSolid }}>
              <View style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: th.accent }} />
              <Text style={{ color: t.ink, fontWeight: "700", fontSize: 12.5 }}>{th.name}</Text>
            </Pressable>
          ))}
        </View>

        {/* premium */}
        <Card t={t} style={{ marginTop: 18 }}>
          {app.purchased ? (
            <Text style={{ color: t.ink, fontWeight: "700" }}>💖 PawHealth+ active — thank you! Ad-free, unlimited activities.</Text>
          ) : app.inTrial ? (
            <Text style={{ color: t.ink, fontWeight: "700" }}>✦ Free trial: {app.trialDaysLeft} day{app.trialDaysLeft === 1 ? "" : "s"} of PawHealth+ left.</Text>
          ) : (
            <Text style={{ color: t.ink, fontWeight: "700" }}>You're on the free plan (with ads).</Text>
          )}
          <Text style={{ color: t.inkSoft, fontSize: 12, marginTop: 6, lineHeight: 18 }}>🔒 Your wellness & cycle data stay on this device. No ads in Premium, and we never sell your data.</Text>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

function Mini({ t, v, l }) { return (<View style={{ alignItems: "center" }}><Text style={{ fontSize: 20, fontWeight: "800", color: t.ink }}>{v}</Text><Text style={{ fontSize: 10.5, fontWeight: "700", color: t.inkSoft, textTransform: "uppercase" }}>{l}</Text></View>); }
function Insight({ t, v, l }) { return (<View style={{ alignItems: "center", flex: 1 }}><Text style={{ fontSize: 22, fontWeight: "800", color: t.accent }}>{v}</Text><Text style={{ fontSize: 10.5, fontWeight: "700", color: t.inkSoft, textAlign: "center" }}>{l}</Text></View>); }
function Stat({ t, icon, v, l }) { return (<View style={{ flex: 1, alignItems: "center", backgroundColor: t.cardSolid, borderRadius: 18, borderWidth: 1, borderColor: t.cardB, paddingVertical: 13 }}><Text style={{ fontSize: 18 }}>{icon}</Text><Text style={{ fontSize: 19, fontWeight: "800", color: t.ink, marginTop: 2 }}>{v}</Text><Text style={{ fontSize: 10.5, fontWeight: "700", color: t.inkSoft, textTransform: "uppercase" }}>{l}</Text></View>); }

const s = StyleSheet.create({ fill: { flex: 1 } });
