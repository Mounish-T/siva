// src/premium.js — PawHealth+ one-time unlock (₹30) + restore.
//
// HOW PRICING WORKS in this app:
//   • Every new user gets the first 15 days of Premium FREE (handled in store.js).
//   • After day 15, the app shows ads + locks Premium-only extras until they buy
//     the one-time "PawHealth+" unlock (set its price to ₹30 in Google Play Console).
//
// PURCHASE_MODE controls how the "Unlock" button behaves:
//   "simulated"  -> no native store needed; the button just flips premium ON so you
//                   can test the whole flow in Expo Go / before configuring billing.
//   "expo-iap"   -> real Google Play Billing via the expo-iap package (see README).
//
// Start in "simulated", then switch to "expo-iap" once your product is live.

export const PURCHASE_MODE = "simulated"; // "simulated" | "expo-iap"

// The product ID you create in Google Play Console (Monetize > In-app products).
// Make it a one-time (non-consumable) product priced at ₹30.
export const PRODUCT_ID = "pawhealth_plus_lifetime";

// ---- SIMULATED ----
async function simBuy() { await wait(700); return { ok: true }; }
async function simRestore() { return { ok: false }; } // nothing to restore in sim
function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }

// ---- EXPO-IAP (real billing) ----
// Uncomment after `npx expo install expo-iap` and building a dev/EAS build.
// The exact surface can shift between versions — check the expo-iap README and
// adjust the imported function names if needed. This is the typical shape:
/*
import {
  initConnection, endConnection,
  fetchProducts, requestPurchase, finishTransaction, getAvailablePurchases,
} from "expo-iap";

async function iapBuy() {
  try {
    await initConnection();
    await fetchProducts({ skus: [PRODUCT_ID], type: "inapp" });
    const purchase = await requestPurchase({
      request: { android: { skus: [PRODUCT_ID] }, ios: { sku: PRODUCT_ID } },
      type: "inapp",
    });
    const p = Array.isArray(purchase) ? purchase[0] : purchase;
    if (p) { await finishTransaction({ purchase: p, isConsumable: false }); return { ok: true }; }
    return { ok: false };
  } catch (e) {
    return { ok: false, error: String(e?.message || e) };
  }
}

async function iapRestore() {
  try {
    await initConnection();
    const purchases = await getAvailablePurchases();
    const owned = (purchases || []).some((p) => p.productId === PRODUCT_ID || (p.ids || []).includes(PRODUCT_ID));
    return { ok: owned };
  } catch (e) {
    return { ok: false, error: String(e?.message || e) };
  }
}
*/

export async function buyPremium() {
  if (PURCHASE_MODE === "expo-iap") {
    // return iapBuy();      // <- enable with the import block above
    return { ok: false, error: "Enable the expo-iap block in premium.js" };
  }
  return simBuy();
}

export async function restorePremium() {
  if (PURCHASE_MODE === "expo-iap") {
    // return iapRestore();  // <- enable with the import block above
    return { ok: false, error: "Enable the expo-iap block in premium.js" };
  }
  return simRestore();
}
