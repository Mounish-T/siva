// src/content.js — data + helpers for the v2 features (shop, bond, check-in, cycle).

// ---------- Bond (relationship that grows over weeks → long-term reason to return) ----------
export const BOND_TITLES = ["New Friend", "Buddy", "Close Pal", "Best Friend", "Kindred Spirit", "Soulmate"];
const BOND_PER = 100;
export function bondInfo(bond) {
  const lvl = Math.min(BOND_TITLES.length, Math.floor(bond / BOND_PER) + 1);
  const into = bond % BOND_PER;
  const maxed = lvl >= BOND_TITLES.length;
  return { level: lvl, title: BOND_TITLES[lvl - 1], pct: maxed ? 100 : (into / BOND_PER) * 100, toNext: maxed ? 0 : BOND_PER - into, maxed };
}

// ---------- Daily check-in moods ----------
export const CHECK_MOODS = [
  { key: "great", emoji: "🥰", label: "Great",  line: "Yay — your good days are my good days! 💕", w: 5 },
  { key: "good",  emoji: "😊", label: "Good",   line: "Love to hear it. Let's keep today gentle.", w: 3 },
  { key: "okay",  emoji: "🙂", label: "Okay",   line: "Okay is perfectly okay. I'm right here.", w: 1 },
  { key: "low",   emoji: "🥺", label: "Low",    line: "Thank you for telling me. We'll go slow, together.", w: 0 },
  { key: "tired", emoji: "😴", label: "Tired",  line: "Rest is allowed. Maybe a cozy day today?", w: 0 },
];
export function moodByKey(k) { return CHECK_MOODS.find((m) => m.key === k); }

// ---------- Daily affirmations (the pet "gives" you one) ----------
export const AFFIRMATIONS = [
  "You don't have to earn rest. 🌙",
  "Small steps still move you forward. 🐾",
  "Your body is doing its best for you. 💗",
  "Gentle is a kind of strong. 🌿",
  "You showed up today. That matters. ✨",
  "Progress isn't a straight line, and that's okay.",
  "You're allowed to take up space. 🌸",
  "Tending to yourself is not selfish.",
  "Some days, surviving is thriving. 🫶",
  "You are worthy of softness today.",
  "Breathe. You're exactly where you need to be. 🌬️",
  "Be as kind to yourself as you are to me. 💛",
  "Your pace is the right pace.",
  "Rest now; bloom later. 🌷",
  "You and I — one gentle day at a time.",
];
export function affirmationFor(seed) { return AFFIRMATIONS[seed % AFFIRMATIONS.length]; }

// ---------- Coin shop: accessories (worn on the pet) + scenes (the pet's backdrop) ----------
export const SHOP_ITEMS = [
  // accessories
  { id: "acc_flower",  kind: "accessory", name: "Flower",     emoji: "🌸", price: 50 },
  { id: "acc_bow",     kind: "accessory", name: "Cute Bow",   emoji: "🎀", price: 70 },
  { id: "acc_glasses", kind: "accessory", name: "Cool Shades",emoji: "🕶️", price: 110 },
  { id: "acc_scarf",   kind: "accessory", name: "Cozy Scarf", emoji: "🧣", price: 90 },
  { id: "acc_hat",     kind: "accessory", name: "Party Hat",  emoji: "🎉", price: 100 },
  { id: "acc_crown",   kind: "accessory", name: "Tiny Crown", emoji: "👑", price: 180 },
  // scenes  (c1→c2 = background gradient; decor = floating emoji)
  { id: "scene_home",   kind: "scene", name: "Cozy Room",    price: 0,   c1: "#FFF4FA", c2: "#FFE3F0", decor: ["🪴", "🛋️", "🖼️"], dark: false },
  { id: "scene_sakura", kind: "scene", name: "Sakura Grove", price: 130, c1: "#FFE5F0", c2: "#FFCFE3", decor: ["🌸", "🌸", "🦋"], dark: false },
  { id: "scene_beach",  kind: "scene", name: "Sunny Beach",  price: 150, c1: "#FFF0CC", c2: "#FFD98A", decor: ["🌊", "🏖️", "🐚"], dark: false },
  { id: "scene_forest", kind: "scene", name: "Quiet Forest", price: 160, c1: "#DDF3DD", c2: "#B9E4B9", decor: ["🌲", "🍄", "🦋"], dark: false },
  { id: "scene_night",  kind: "scene", name: "Starry Night", price: 220, c1: "#2A2A55", c2: "#3C3C7A", decor: ["⭐", "🌙", "✨"], dark: true },
];
export function itemById(id) { return SHOP_ITEMS.find((x) => x.id === id); }

// ---------- Cycle & Body (private, on-device) ----------
export const PHASES = {
  menstrual:  { name: "Menstrual",  emoji: "🌙", tip: "Be gentle — warmth, rest, and iron-rich foods help.", pet: "Let's curl up cozy today 🫂" },
  follicular: { name: "Follicular", emoji: "🌱", tip: "Energy is rising — a lovely time to try something new.", pet: "I can feel your spark today! ✨" },
  ovulation:  { name: "Ovulation",  emoji: "☀️", tip: "Peak energy — hydrate well and move if it feels good.", pet: "Let's make the most of today! 🌟" },
  luteal:     { name: "Luteal",     emoji: "🍂", tip: "Wind down — magnesium, sleep, and extra self-kindness.", pet: "Slow and soft is just right 🍵" },
};

export function isoDay(d = new Date()) {
  const x = new Date(d); x.setHours(0, 0, 0, 0);
  return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}-${String(x.getDate()).padStart(2, "0")}`;
}
function parseISO(s) { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); }
function daysBetween(a, b) { return Math.round((parseISO(b) - parseISO(a)) / 86400000); }
function addDays(iso, n) { const d = parseISO(iso); d.setDate(d.getDate() + n); return isoDay(d); }

export function cycleStatus(cycle) {
  const { lastStart, cycleLen = 28, periodLen = 5 } = cycle || {};
  if (!lastStart) return { hasData: false };
  const today = isoDay();
  let elapsed = daysBetween(lastStart, today);
  if (elapsed < 0) elapsed = 0;
  const dayInCycle = (elapsed % cycleLen) + 1; // 1-based
  let phase;
  if (dayInCycle <= periodLen) phase = "menstrual";
  else if (dayInCycle <= 13) phase = "follicular";
  else if (dayInCycle <= 16) phase = "ovulation";
  else phase = "luteal";
  const cyclesPassed = Math.floor(elapsed / cycleLen);
  const nextStart = addDays(lastStart, (cyclesPassed + 1) * cycleLen);
  const daysToNext = daysBetween(today, nextStart);
  return { hasData: true, phase, dayInCycle, cycleLen, periodLen, nextStart, daysToNext, info: PHASES[phase] };
}

export function prettyDate(iso) {
  const d = parseISO(iso);
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}
