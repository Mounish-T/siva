// src/ads.js — Google AdMob via react-native-google-mobile-ads.
// Ads only show on the FREE tier. Premium (purchased OR in the 15-day trial) is ad-free.
//
// IMPORTANT: this needs a dev build or production build (NOT Expo Go), because it ships
// native code. In development (__DEV__) it always uses Google's official TEST ad units,
// so you never risk your AdMob account by clicking your own real ads.
//
// Put your REAL ad unit IDs below once you've created them in AdMob, and your AdMob
// APP IDs go in app.config.js (the react-native-google-mobile-ads plugin block).

import React, { useEffect, useRef, useState } from "react";
import { View } from "react-native";

let Ads = null;
try {
  // Wrapped so the JS bundle still loads in environments where the native module
  // isn't present (e.g. Expo Go) — ads simply won't render there.
  Ads = require("react-native-google-mobile-ads");
} catch (e) {
  Ads = null;
}

// ---- your real unit IDs (replace the right-hand strings) ----
const REAL_BANNER = "ca-app-pub-0000000000000000/0000000000";
const REAL_INTERSTITIAL = "ca-app-pub-0000000000000000/1111111111";

const TestIds = Ads?.TestIds;
const BANNER_UNIT = __DEV__ ? TestIds?.BANNER : REAL_BANNER;
const INTERSTITIAL_UNIT = __DEV__ ? TestIds?.INTERSTITIAL : REAL_INTERSTITIAL;

export async function initAds() {
  if (!Ads) return;
  try {
    if (Ads.default && Ads.MaxAdContentRating) {
      await Ads.default().setRequestConfiguration({
        maxAdContentRating: Ads.MaxAdContentRating.PG, // family-friendly wellness app
        tagForChildDirectedTreatment: false,
      });
      await Ads.default().initialize();
    }
  } catch (e) {}
}

// Banner that auto-hides for premium users.
export function AdBanner({ premium, style }) {
  if (premium || !Ads || !Ads.BannerAd || !BANNER_UNIT) return null;
  const { BannerAd, BannerAdSize } = Ads;
  return (
    <View style={[{ alignItems: "center", marginVertical: 6 }, style]}>
      <BannerAd unitId={BANNER_UNIT} size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER} />
    </View>
  );
}

// Optional interstitial (e.g. after finishing a tracker session) — skipped for premium.
export function useInterstitial(premium) {
  const ref = useRef(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (premium || !Ads || !Ads.InterstitialAd || !INTERSTITIAL_UNIT) return;
    const { InterstitialAd, AdEventType } = Ads;
    const ad = InterstitialAd.createForAdRequest(INTERSTITIAL_UNIT);
    ref.current = ad;
    const onLoad = ad.addAdEventListener(AdEventType.LOADED, () => setLoaded(true));
    const onClose = ad.addAdEventListener(AdEventType.CLOSED, () => { setLoaded(false); ad.load(); });
    ad.load();
    return () => { onLoad(); onClose(); };
  }, [premium]);

  return () => {
    if (premium) return;
    try { if (loaded && ref.current) ref.current.show(); } catch (e) {}
  };
}
