// src/store.js — single source of truth, persisted to the device with AsyncStorage.
// Privacy-first: everything (including cycle data) lives locally on the phone.
import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { isoDay, itemById } from "./content";

const KEY = "pawhealth.state.v2";
const DAY = 24 * 60 * 60 * 1000;
export const TRIAL_DAYS = 15; // first 15 days of Premium are free for everyone

const clamp = (n) => Math.max(0, Math.min(100, n));

const DEFAULT = {
  pet: null, petName: "", themeKey: "sakura",
  coins: 120, wellness: 58,
  streakDays: 3, streakState: "active",
  builtinDone: {}, customActivities: [], customDone: {},
  firstLaunch: 0, purchased: false, shared: false,
  totalDistance: 0, totalSteps: 0, totalSessions: 0,
  lastDay: 0,
  // --- v2 ---
  bond: 40,                       // grows slowly; level derived in content.bondInfo
  treats: 2,                      // feeding currency
  moodLog: [],                    // [{ d:'YYYY-MM-DD', m:'good' }]
  checkinDay: 0,                  // dayStamp of last check-in
  hydration: 0, hydrationGoal: 8, // cups today
  ownedItems: ["scene_home"],     // shop items owned
  equippedAccessory: null,        // accessory item id worn on the pet
  equippedScene: "scene_home",    // background scene id
  wellnessHist: {},               // { 'YYYY-MM-DD': score } for the heatmap
  feedsToday: 0, petTapsToday: 0,
  cycle: { lastStart: null, cycleLen: 28, periodLen: 5, starts: [] },
  notifyOptIn: false,
};

const Ctx = createContext(null);
function dayStamp(ms) { const d = new Date(ms); d.setHours(0, 0, 0, 0); return d.getTime(); }

export function AppProvider({ children }) {
  const [state, setState] = useState(DEFAULT);
  const [hydrated, setHydrated] = useState(false);
  const saveTimer = useRef(null);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(KEY);
        let next = raw ? { ...DEFAULT, ...JSON.parse(raw) } : { ...DEFAULT };
        if (!next.firstLaunch) next.firstLaunch = Date.now();
        next.cycle = { ...DEFAULT.cycle, ...(next.cycle || {}) };
        const today = dayStamp(Date.now());
        if (next.lastDay && next.lastDay !== today) {
          next.builtinDone = {}; next.customDone = {};
          next.hydration = 0; next.feedsToday = 0; next.petTapsToday = 0;
        }
        next.lastDay = today;
        setState(next);
      } catch (e) {
        setState({ ...DEFAULT, firstLaunch: Date.now(), lastDay: dayStamp(Date.now()) });
      } finally { setHydrated(true); }
    })();
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => { AsyncStorage.setItem(KEY, JSON.stringify(state)).catch(() => {}); }, 250);
  }, [state, hydrated]);

  const patch = useCallback((p) => setState((s) => ({ ...s, ...(typeof p === "function" ? p(s) : p) })), []);

  // records today's wellness into the history map alongside a new value
  function withWell(s, val) {
    const w = clamp(val);
    return { wellness: w, wellnessHist: { ...s.wellnessHist, [isoDay()]: w } };
  }

  // derived premium / trial
  const trialMsLeft = Math.max(0, state.firstLaunch + TRIAL_DAYS * DAY - Date.now());
  const trialDaysLeft = Math.ceil(trialMsLeft / DAY);
  const inTrial = trialMsLeft > 0;
  const isPremium = !!state.purchased || inTrial;
  const checkedInToday = state.checkinDay === dayStamp(Date.now());

  // ---- basics ----
  const choosePet = (pet) => patch({ pet });
  const setName = (petName) => patch({ petName });
  const setThemeKey = (themeKey) => patch({ themeKey });
  const setPurchased = (v) => patch({ purchased: !!v });
  const markShared = () => patch({ shared: true });
  const addCoins = (n) => patch((s) => ({ coins: s.coins + n }));
  const bumpWellness = (n) => patch((s) => withWell(s, s.wellness + n));

  function _afterComplete(s, allDoneNow) {
    const extra = {};
    if (s.streakState === "resting") extra.streakState = "recovering";
    return extra;
  }

  const completeBuiltin = (goal, builtinGoals) => setState((s) => {
    if (s.builtinDone[goal.id]) return s;
    const builtinDone = { ...s.builtinDone, [goal.id]: true };
    const allDoneNow = builtinGoals.every((g) => builtinDone[g.id]) &&
      s.customActivities.every((a) => s.customDone[a.id]) &&
      (builtinGoals.length + s.customActivities.length) > 0;
    return {
      ...s, builtinDone,
      coins: s.coins + goal.coins + (allDoneNow ? 30 : 0),
      treats: s.treats + 1, bond: s.bond + 3,
      ...withWell(s, Math.max(s.wellness + 9, allDoneNow ? 92 : 0)),
      ..._afterComplete(s, allDoneNow),
    };
  });

  const completeCustom = (act, builtinGoals) => setState((s) => {
    if (s.customDone[act.id]) return s;
    const customDone = { ...s.customDone, [act.id]: true };
    const allDoneNow = builtinGoals.every((g) => s.builtinDone[g.id]) &&
      s.customActivities.every((a) => customDone[a.id]) &&
      (builtinGoals.length + s.customActivities.length) > 0;
    return {
      ...s, customDone,
      coins: s.coins + (act.coins || 5) + (allDoneNow ? 30 : 0),
      treats: s.treats + 1, bond: s.bond + 3,
      ...withWell(s, Math.max(s.wellness + 9, allDoneNow ? 92 : 0)),
      ..._afterComplete(s, allDoneNow),
    };
  });

  const addActivity = (a) => patch((s) => ({ customActivities: [...s.customActivities, a] }));
  const deleteActivity = (id) => patch((s) => {
    const customActivities = s.customActivities.filter((x) => x.id !== id);
    const customDone = { ...s.customDone }; delete customDone[id];
    return { customActivities, customDone };
  });

  const skipDay = () => patch((s) => ({
    builtinDone: {}, customDone: {},
    ...withWell(s, Math.max(6, s.wellness - 18)),
    streakState: "resting",
  }));

  const recordSession = ({ distanceKm = 0, steps = 0 }) => patch((s) => ({
    totalDistance: +(s.totalDistance + distanceKm).toFixed(2),
    totalSteps: s.totalSteps + Math.round(steps),
    totalSessions: s.totalSessions + 1,
    coins: s.coins + 12, treats: s.treats + 1, bond: s.bond + 6,
    ...withWell(s, s.wellness + 8),
    streakState: s.streakState === "resting" ? "recovering" : s.streakState,
  }));

  // ---- v2 actions ----
  const checkIn = (mood) => setState((s) => {
    if (s.checkinDay === dayStamp(Date.now())) return s;
    const moodLog = [...s.moodLog, { d: isoDay(), m: mood.key }].slice(-31);
    return { ...s, checkinDay: dayStamp(Date.now()), moodLog, bond: s.bond + 6, ...withWell(s, s.wellness + (mood.w || 0)) };
  });

  const petTap = () => patch((s) => (s.petTapsToday >= 6 ? {} : { bond: s.bond + 1, petTapsToday: s.petTapsToday + 1 }));

  const feed = () => {
    let ok = false;
    setState((s) => {
      if (s.treats <= 0) return s;
      ok = true;
      const gentle = s.feedsToday < 6;
      return { ...s, treats: s.treats - 1, feedsToday: s.feedsToday + 1, bond: s.bond + 5, ...withWell(s, s.wellness + (gentle ? 3 : 0)) };
    });
    return ok;
  };
  const buyTreat = () => { let ok = false; setState((s) => { if (s.coins < 10) return s; ok = true; return { ...s, coins: s.coins - 10, treats: s.treats + 1 }; }); return ok; };

  const addHydration = () => patch((s) => {
    const hydration = Math.min(s.hydrationGoal * 2, s.hydration + 1);
    const reached = hydration === s.hydrationGoal;
    return { hydration, bond: s.bond + (reached ? 2 : 0), ...withWell(s, s.wellness + (hydration <= s.hydrationGoal ? 1 : 0)) };
  });

  const buyItem = (item) => { let ok = false; setState((s) => {
    if (s.ownedItems.includes(item.id) || s.coins < item.price) return s;
    ok = true; return { ...s, coins: s.coins - item.price, ownedItems: [...s.ownedItems, item.id] };
  }); return ok; };

  const equipAccessory = (id) => patch((s) => ({ equippedAccessory: s.equippedAccessory === id ? null : id }));
  const equipScene = (id) => patch({ equippedScene: id });

  const setCycle = (partial) => patch((s) => ({ cycle: { ...s.cycle, ...partial } }));
  const logPeriodStart = (iso) => patch((s) => ({ cycle: { ...s.cycle, lastStart: iso, starts: [...(s.cycle.starts || []), iso].slice(-24) } }));
  const setNotifyOptIn = (v) => patch({ notifyOptIn: !!v });

  const value = {
    ...state, hydrated,
    isPremium, inTrial, trialDaysLeft, checkedInToday,
    choosePet, setName, setThemeKey, setPurchased, markShared,
    addCoins, bumpWellness, completeBuiltin, completeCustom, addActivity, deleteActivity,
    skipDay, recordSession,
    checkIn, petTap, feed, buyTreat, addHydration,
    buyItem, equipAccessory, equipScene,
    setCycle, logPeriodStart, setNotifyOptIn,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useApp must be used inside <AppProvider>");
  return v;
}
