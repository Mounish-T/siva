// src/feedback.js — tiny haptics helper. Safe no-op if the module/device can't do it.
let H = null;
try { H = require("expo-haptics"); } catch (e) {}

export const haptic = {
  tap() { try { H && H.impactAsync(H.ImpactFeedbackStyle.Light); } catch (e) {} },
  press() { try { H && H.impactAsync(H.ImpactFeedbackStyle.Medium); } catch (e) {} },
  success() { try { H && H.notificationAsync(H.NotificationFeedbackType.Success); } catch (e) {} },
  select() { try { H && H.selectionAsync(); } catch (e) {} },
};
