// src/components.js — shared UI building blocks.
import React, { useEffect, useRef } from "react";
import { View, Text, Pressable, Animated, Easing, StyleSheet } from "react-native";
import Svg, { Circle } from "react-native-svg";

// Gentle breathing + floating emoji pet, with a quick pop when `reactionKey` changes.
export function Pet({ emoji, size = 104, dim = false, reactionKey = 0 }) {
  const breathe = useRef(new Animated.Value(0)).current;
  const pop = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(breathe, { toValue: 1, duration: 1900, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(breathe, { toValue: 0, duration: 1900, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [breathe]);

  useEffect(() => {
    if (!reactionKey) return;
    pop.setValue(0.8);
    Animated.spring(pop, { toValue: 1, friction: 3, tension: 120, useNativeDriver: true }).start();
  }, [reactionKey, pop]);

  const translateY = breathe.interpolate({ inputRange: [0, 1], outputRange: [4, -6] });
  const scale = Animated.multiply(breathe.interpolate({ inputRange: [0, 1], outputRange: [1, 1.04] }), pop);

  return (
    <Animated.Text style={{ fontSize: size, transform: [{ translateY }, { scale }], opacity: dim ? 0.85 : 1 }}>
      {emoji}
    </Animated.Text>
  );
}

// Circular wellness ring.
export function Ring({ value, color, badge, label, t, size = 104 }) {
  const r = (size - 24) / 2;
  const c = 2 * Math.PI * r;
  const off = c * (1 - Math.max(0, Math.min(100, value)) / 100);
  const cx = size / 2;
  return (
    <View style={{ width: size, height: size }}>
      <Svg width={size} height={size}>
        <Circle cx={cx} cy={cx} r={r} stroke={t.ringTrack} strokeWidth={10} fill="none" />
        <Circle
          cx={cx} cy={cx} r={r} stroke={color} strokeWidth={10} fill="none"
          strokeLinecap="round" strokeDasharray={`${c} ${c}`} strokeDashoffset={off}
          transform={`rotate(-90 ${cx} ${cx})`}
        />
      </Svg>
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <Text style={{ fontSize: 15 }}>{badge}</Text>
          <Text style={{ fontSize: 26, fontWeight: "800", color: t.ink }}>{Math.round(value)}</Text>
          <Text style={{ fontSize: 9.5, fontWeight: "700", color: t.inkSoft, textTransform: "uppercase" }}>{label}</Text>
        </View>
      </View>
    </View>
  );
}

export function Card({ t, style, children }) {
  return (
    <View style={[{
      backgroundColor: t.cardSolid, borderRadius: 22, padding: 16,
      borderWidth: 1, borderColor: t.cardB,
      shadowColor: t.dark ? "#000" : "#8a546e", shadowOpacity: t.dark ? 0.35 : 0.12,
      shadowRadius: 16, shadowOffset: { width: 0, height: 8 }, elevation: 3,
    }, style]}>
      {children}
    </View>
  );
}

export function Pill({ t, tone = "accent", children, style }) {
  const bg = tone === "accent" ? t.accent + "22" : t.ringTrack;
  const col = tone === "accent" ? t.accent : t.inkSoft;
  return (
    <View style={[{ alignSelf: "flex-start", backgroundColor: bg, borderRadius: 16, paddingHorizontal: 11, paddingVertical: 5 }, style]}>
      <Text style={{ color: col, fontWeight: "800", fontSize: 12.5 }}>{children}</Text>
    </View>
  );
}

// A tappable goal / activity row with a check toggle.
export function Row({ t, icon, tint, title, subtitle, done, onPress, onLongPress }) {
  return (
    <Pressable onPress={done ? undefined : onPress} onLongPress={onLongPress}
      style={({ pressed }) => [{
        flexDirection: "row", alignItems: "center", gap: 12, padding: 13,
        backgroundColor: t.cardSolid, borderRadius: 18, borderWidth: 1, borderColor: t.cardB,
        opacity: done ? 0.6 : pressed ? 0.9 : 1, transform: [{ scale: pressed && !done ? 0.98 : 1 }],
        marginBottom: 10,
      }]}>
      <View style={{ width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: (tint || t.accent) + "22" }}>
        <Text style={{ fontSize: 21 }}>{icon}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 14.5, fontWeight: "600", color: t.ink }}>{title}</Text>
        {!!subtitle && <Text style={{ fontSize: 12, color: t.inkSoft, marginTop: 2, fontWeight: "600" }}>{subtitle}</Text>}
      </View>
      <View style={{
        width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center",
        backgroundColor: done ? t.accent : "transparent", borderWidth: done ? 0 : 2, borderColor: t.accent + "88",
      }}>
        <Text style={{ color: "#fff", fontWeight: "800", fontSize: 15 }}>{done ? "✓" : ""}</Text>
      </View>
    </Pressable>
  );
}
